"""
文本编码器

将自然语言文本转化为256维证据向量，用于第一层的贝叶斯坍缩。
采用轻量级设计：无外部依赖，基于确定性哈希生成词向量，
支持在线学习新词汇。
"""

import re
import numpy as np
import hashlib

class TextEncoder:
    """文本到证据向量的编码器"""
    
    def __init__(self, dimension=256, lexicon_initializer=None):
        """
        参数:
            dimension: 向量维度，需与词元概率云维度一致
            lexicon_initializer: 第一层的词元初始化器（用于创建新词元）
        """
        self.dimension = dimension
        self.lexicon_initializer = lexicon_initializer
        
        # 词到词元名称的映射（自然语言词汇 -> 内部词元ID）
        self.word_to_lexion = {}
        
        # 中文分词正则（简化版：按汉字、字母数字切分）
        self.token_pattern = re.compile(r'[\u4e00-\u9fff]|[a-zA-Z]+|[0-9]+')
    
    def _hash_to_vector(self, word):
        """
        将词确定性哈希为256维单位向量
        使用SHA256保证同一词总是映射到相同向量
        """
        hash_bytes = hashlib.sha256(word.encode('utf-8')).digest()
        # 将哈希值转换为浮点数序列
        seed = int.from_bytes(hash_bytes[:8], 'big')
        np.random.seed(seed)
        vec = np.random.randn(self.dimension)
        # 归一化
        vec = vec / (np.linalg.norm(vec) + 1e-12)
        return vec
    
    def tokenize(self, text):
        """将文本切分为词元列表"""
        return self.token_pattern.findall(text)
    
    def get_or_create_lexion(self, word):
        """
        获取或创建词对应的词元名称
        
        如果该词首次出现，且lexicon_initializer可用，
        则创建新词元并以哈希向量初始化其概率云。
        """
        if word in self.word_to_lexion:
            return self.word_to_lexion[word]
        
        # 生成词元名称（加上前缀避免与语义原子冲突）
        lexion_name = f"W:{word}"
        
        if self.lexicon_initializer is not None:
            # 创建新词元
            if lexion_name not in self.lexicon_initializer.get_all_lexions():
                new_lex = self.lexicon_initializer.create_new_lexion(lexion_name)
                # 用确定性哈希向量作为其初始概率云
                hash_vec = self._hash_to_vector(word)
                new_lex.p = hash_vec
                # 新词元初始离散度中等偏高
                new_lex.sigma = 0.6
        
        self.word_to_lexion[word] = lexion_name
        return lexion_name
    
    def encode_text(self, text, lexicon):
        """
        将文本编码为证据向量
        
        策略：取文本中所有词元的概率云的加权平均。
        权重由词频决定。
        
        参数:
            text: 输入文本
            lexicon: 当前词元词典 {name: Lexion}
        
        返回:
            evidence_vector: 256维归一化向量
            affected_lexions: 受影响的词元名称列表
        """
        tokens = self.tokenize(text)
        if not tokens:
            return np.ones(self.dimension) / self.dimension, []
        
        # 统计词频
        word_counts = {}
        for token in tokens:
            word_counts[token] = word_counts.get(token, 0) + 1
        
        # 收集参与的词元及其权重
        lexion_weights = {}
        for word, count in word_counts.items():
            lex_name = self.get_or_create_lexion(word)
            if lex_name in lexicon:
                lex = lexicon[lex_name]
                # 权重 = 词频 × (1 - sigma) （确定性越高权重越大）
                weight = count * (1 - lex.sigma + 0.1)
                lexion_weights[lex_name] = weight
        
        if not lexion_weights:
            return np.ones(self.dimension) / self.dimension, []
        
        # 加权平均
        total_weight = sum(lexion_weights.values())
        evidence = np.zeros(self.dimension)
        for lex_name, weight in lexion_weights.items():
            lex = lexicon[lex_name]
            evidence += weight * lex.p
        
        evidence = evidence / total_weight
        
        # 添加微小噪声避免除零
        evidence = evidence + np.random.randn(self.dimension) * 0.001
        evidence = np.maximum(evidence, 1e-12)
        evidence = evidence / np.sum(evidence)
        
        affected_lexions = list(lexion_weights.keys())
        return evidence, affected_lexions
    
    def encode_word(self, word):
        """直接获取单个词的哈希向量（用于创建新词元）"""
        return self._hash_to_vector(word)