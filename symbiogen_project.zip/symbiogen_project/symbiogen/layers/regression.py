from symbiogen.layers.base import Layer
from symbiogen.primitives.regress import regress

class RegressionLayer(Layer):
    """回归层：向蓝图场 R₀ 回归，维持结构稳态"""
    
    def __init__(self, field, config=None):
        if config is None: config = {}
        super().__init__(field, config)
        self.gamma = config.get("gamma", 0.01)
        self.blueprint_update_interval = config.get("blueprint_update_interval", 1000)
        self.step_counter = 0
    
    def run(self, **kwargs):
        regress(self.field, gamma=self.gamma)
        self.step_counter += 1
        
        # 定期更新蓝图（拉马克式遗传）
        if self.step_counter % self.blueprint_update_interval == 0:
            self._update_blueprint()
    
    def _update_blueprint(self):
        """将稳定成功的模式写入蓝图场"""
        for pid, p in self.field.particles.items():
            # 标准：高资源、低方差、长寿命
            if (p.resource > 1.5 and 
                p.activation_var < 0.1 and 
                p.age > 100):
                self.field.blueprint.add_anchor(
                    p.coordinate, 
                    p.curvature, 
                    strength=0.1
                )