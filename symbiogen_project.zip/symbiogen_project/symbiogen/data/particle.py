import numpy as np
import uuid

class Particle:
    """高维流形上的基本生命单元"""
    
    def __init__(self, coordinate, dimension=None):
        self.particle_id = str(uuid.uuid4())[:8]
        
        # 如果只传入维度，则白噪声初始化坐标
        if isinstance(coordinate, int) and dimension is None:
            dimension = coordinate
            coordinate = np.random.randn(dimension) * 0.01
        
        self.coordinate = np.array(coordinate, dtype=np.float32)
        self.dimension = len(self.coordinate)
        
        # 曲率（简化为标量，后续可扩展为张量）
        self.curvature = 0.0
        
        # 状态变量
        self.activation = 0.0
        self.resource = 1.0
        self.age = 0
        
        # 统计量（用于局部曲率估计）
        self.activation_mean = 0.0
        self.activation_var = 0.0
        
        # 类型标记（用于意象注入）
        self.particle_type = "normal"  # normal / stem / mother_tree / neural_crest
        self.stemness = 0.0  # 0=完全分化，1=全能干细胞
        
        # 极性轴投影（涡虫机制）
        self.developmental_coordinate = 0.0
        
    def to_dict(self):
        return {
            "particle_id": self.particle_id,
            "coordinate": self.coordinate.tolist(),
            "curvature": self.curvature,
            "activation": self.activation,
            "resource": self.resource,
            "age": self.age,
            "activation_mean": self.activation_mean,
            "activation_var": self.activation_var,
            "particle_type": self.particle_type,
            "stemness": self.stemness,
            "developmental_coordinate": self.developmental_coordinate
        }
    
    @classmethod
    def from_dict(cls, data):
        p = cls(coordinate=data["coordinate"])
        p.particle_id = data["particle_id"]
        p.curvature = data["curvature"]
        p.activation = data["activation"]
        p.resource = data["resource"]
        p.age = data["age"]
        p.activation_mean = data["activation_mean"]
        p.activation_var = data["activation_var"]
        p.particle_type = data["particle_type"]
        p.stemness = data["stemness"]
        p.developmental_coordinate = data["developmental_coordinate"]
        return p