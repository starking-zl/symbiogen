"""配置管理（简化）"""
import json
import os

def load_config(filepath):
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def save_config(config, filepath):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2)