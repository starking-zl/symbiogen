#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
交互对话窗口

提供命令行交互界面，用于手动喂养文本、观察基因群状态、保存/加载存档。
支持简单的联想输出（基于当前最高激活词元）。

使用方法：
    python scripts/interactive.py

命令列表（可省略冒号）：
    d          -> 显示完整仪表盘
    save 名称  -> 保存当前状态
    load 名称  -> 加载已保存状态
    q          -> 退出（自动保存）
    直接输入文本 -> 喂养给基因群，并显示联想到的概念
"""

import sys
import os
import re
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symbiogen import SymbiogenColony


def print_dashboard(colony):
    """打印完整的生命体征仪表盘"""
    status = colony.get_status()
    vital = colony.export_vital_signs()

    print("\n" + "=" * 50)
    print(f"共生基因群 · {colony.step_counter}步")
    print(f"词元: {status['lexicon_size']} | 连接: {status['connection_count']} | 资源: {status['total_resource']:.2f}")
    print(f"离散度: {status['avg_sigma']:.3f} | 阈值: {status['current_threshold']:.3f}")
    print(f"信息熵: {vital['info_entropy']:.3f} | 结构熵: {vital['structural_entropy']:.3f}")
    print(f"适应度: {vital.get('fitness', 0):.4f} | 顺应: {status['stats']['total_adaptations']}")
    edge = "✓ 混沌边缘" if vital['in_chaos_edge'] else "○ 偏离"
    print(f"状态: {edge} | 解码器: {status['decoder_mode']}")
    print("=" * 50 + "\n")


# 概念缓存（仅内存，用于联想）
_concept_cache = []

def _update_concept_cache(text):
    """将输入文本中的词汇缓存下来"""
    global _concept_cache
    words = re.split(r'[，。、；：！？\s]+', text)
    for w in words:
        if 2 <= len(w) <= 10 and w not in _concept_cache:
            _concept_cache.append(w)
    if len(_concept_cache) > 100:
        _concept_cache = _concept_cache[-50:]


def get_association(colony):
    """基于当前最高激活词元，从缓存中返回最相关的概念"""
    if not colony.lexicon:
        return None

    # 找到激活值最高的词元
    max_lex = None
    max_act = -1
    for lex in colony.lexicon.values():
        if hasattr(lex, 'activation') and lex.activation > max_act:
            max_act = lex.activation
            max_lex = lex

    if max_lex is None or max_act < 0.01:
        return None

    best_word = None
    best_sim = -1
    for word in _concept_cache:
        vec = colony.encoder.encode_word(word)
        sim = np.dot(vec, max_lex.p) / (np.linalg.norm(vec) * np.linalg.norm(max_lex.p) + 1e-12)
        if sim > best_sim:
            best_sim = sim
            best_word = word

    if best_word and best_sim > 0.15:
        return best_word
    return None


def main():
    # 配置（可调整初始参数）
    config = {
        "dimension": 256,
        "alpha": 0.01,
        "beta": 0.005,
        "gamma": 0.001
    }

    live_path = "data/colonies/live_state.sym"
    colony = SymbiogenColony(config=config)

    # 尝试加载已有状态
    if os.path.exists(live_path):
        print(f"加载现有状态 {live_path}...")
        colony.load(live_path)
        print("加载成功！")
        print_dashboard(colony)
    else:
        print("未发现存档，初始化全新基因群。")
        os.makedirs("data/colonies", exist_ok=True)

    print("=" * 50)
    print("共生基因群 · 交互对话窗口")
    print("=" * 50)
    print("命令列表（可省略冒号）：")
    print("  d          -> 显示完整仪表盘")
    print("  save 名称  -> 保存当前状态")
    print("  load 名称  -> 加载已保存状态")
    print("  q          -> 退出（自动保存）")
    print("  直接输入文本 -> 喂养给基因群，并显示联想到的概念")
    print("=" * 50 + "\n")

    while True:
        try:
            user_input = input(">> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n中断退出...")
            break

        if not user_input:
            continue

        # 命令解析
        raw_cmd = user_input
        if raw_cmd.startswith(":"):
            raw_cmd = raw_cmd[1:]
        cmd_parts = raw_cmd.lower().split(maxsplit=1)
        cmd = cmd_parts[0]

        if cmd in ("q", "quit", "exit"):
            print("保存当前状态到 live_state.sym ...")
            colony.save(live_path)
            print("已保存。再见！")
            break

        if cmd in ("d", "dashboard", "status"):
            print_dashboard(colony)
            continue

        if cmd == "save":
            path = cmd_parts[1].strip() if len(cmd_parts) > 1 else "data/colonies/manual_save.sym"
            colony.save(path)
            print(f"✓ 已保存到 {path}")
            continue

        if cmd == "load":
            if len(cmd_parts) == 1:
                print("请指定文件名，例如 load my_colony")
                continue
            path = cmd_parts[1].strip()
            if os.path.exists(path):
                colony.load(path)
                print(f"✓ 已从 {path} 加载")
                print_dashboard(colony)
            else:
                print(f"✗ 文件 {path} 不存在")
            continue

        if cmd in ("h", "help", "?"):
            print("\n可用命令：")
            print("  d, :d         查看仪表盘")
            print("  save <名称>   保存状态")
            print("  load <名称>   加载状态")
            print("  q, :q         退出并保存")
            print("  其他文本       喂养给基因群，并显示联想到的概念\n")
            continue

        # 喂养文本
        result = colony.observe(user_input)
        _update_concept_cache(user_input)

        # 联想输出
        assoc = get_association(colony)
        if assoc:
            print(f"  🗣️ 联想到：{assoc}")
        else:
            print("  🗣️ (沉默)")

        # 简要状态
        status = colony.get_status()
        print(f"  -> 步数 {status['step_counter']} | 词元 {status['lexicon_size']} | 资源 {status['total_resource']:.2f}")


if __name__ == "__main__":
    main()