#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import re
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symbiogen import SymbiogenColony


def print_dashboard(colony):
    """打印完整的生命体征仪表盘"""
    signs = colony.get_status()
    summary = signs["field_summary"]
    vital = signs.get("latest_vital_signs", {})

    print("\n" + "=" * 40)
    print(f"共生基因群 · {colony.colony_id[:8]}")
    print(f"世代: {colony.generation} | 步数: {colony.step_counter}")
    print(f"适应度: {colony.fitness_score:.4f}")
    print("-" * 40)
    print(f"粒子数: {summary['particle_count']}")
    print(f"连接数: {summary['synapse_count']}")
    print(f"总资源: {summary['total_resource']:.2f}")
    if vital:
        print(f"蓝图吻合度: {vital.get('blueprint_fidelity', 0):.3f}")
        print(f"模块数: {vital.get('module_count', 0)}")
        print(f"曲率方差: {vital.get('curvature_variance', 0):.4f}")
        print(f"新奇响应度: {vital.get('novelty_responsiveness', 0):.4f}")
    print("=" * 40 + "\n")


# 简易概念缓存（仅内存，不持久化）
_concept_cache = []

def _update_concept_cache(text):
    """将用户输入的文本中的名词缓存下来，作为概念标签库"""
    global _concept_cache
    words = re.split(r'[，。、；：！？\s]+', text)
    for w in words:
        if 2 <= len(w) <= 10 and w not in _concept_cache:
            _concept_cache.append(w)
    if len(_concept_cache) > 100:
        _concept_cache = _concept_cache[-50:]


def generate_response(colony, input_text):
    """基于最高激活粒子，从缓存中找最相似概念作为回应"""
    global _concept_cache
    colony.observe(input_text)
    
    if not colony.field.particles:
        return "（内部尚无粒子）"
    
    max_p = max(colony.field.particles.values(), key=lambda p: p.activation)
    if max_p.activation < 0.01:
        return "（没有明显的概念共振）"
    
    best_word = None
    best_sim = -1
    for word in _concept_cache:
        vec = colony.encoder.encode(word)
        sim = np.dot(vec, max_p.coordinate) / (np.linalg.norm(vec) * np.linalg.norm(max_p.coordinate) + 1e-8)
        if sim > best_sim:
            best_sim = sim
            best_word = word
    
    if best_word and best_sim > 0.3:
        return f"「{best_word}」"
    else:
        return "（共振模糊，无法聚焦）"


def main():
    config = {
        "initial_particles": 200,
        "layers": {
            "time_layer": {
                "epsilon": 0.0005,
                "prune_threshold": 0.05
            }
        }
    }

    auto_load_path = "interactive_exit.sym"
    colony = SymbiogenColony(dimension=128, config=config)

    if os.path.exists(auto_load_path):
        print(f"发现上次退出存档 {auto_load_path}，正在加载...")
        colony.load(auto_load_path)
        colony.evaluate_fitness()
        print("加载成功！")
        print_dashboard(colony)
    else:
        print("未发现存档，初始化全新基因群。")

    print("\n" + "=" * 50)
    print("共生基因群 · 交互对话窗口")
    print("=" * 50)
    print("命令列表（可省略冒号）：")
    print("  d          -> 显示完整仪表盘")
    print("  save 名称  -> 保存当前状态")
    print("  load 名称  -> 加载已保存状态")
    print("  q          -> 保存并退出")
    print("  直接输入文本 -> 喂养给基因群")
    print("  ?你的问题   -> 向基因群提问（临时回响）")
    print("=" * 50 + "\n")

    while True:
        try:
            user_input = input(">> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n中断退出...")
            break

        if not user_input:
            continue

        raw_cmd = user_input
        if raw_cmd.startswith(":"):
            raw_cmd = raw_cmd[1:]
        cmd_parts = raw_cmd.lower().split(maxsplit=1)
        cmd = cmd_parts[0]

        if cmd in ("q", "quit", "exit"):
            print("保存当前状态到 interactive_exit.sym ...")
            colony.save("interactive_exit.sym")
            print("已保存。再见！")
            break

        if cmd in ("d", "dashboard", "status"):
            print_dashboard(colony)
            continue

        if cmd == "save":
            path = cmd_parts[1].strip() if len(cmd_parts) > 1 else "manual_save.sym"
            colony.save(path)
            print(f"✓ 已保存到 {path}")
            continue

        if cmd == "load":
            if len(cmd_parts) == 1:
                print("请指定文件名，例如 load my_colony")
                continue
            path = cmd_parts[1].strip()
            if os.path.exists(path):
                colony.load(path)
                colony.evaluate_fitness()
                print(f"✓ 已从 {path} 加载")
                print_dashboard(colony)
            else:
                print(f"✗ 文件 {path} 不存在")
            continue

        if cmd in ("h", "help", "?"):
            print("\n可用命令：")
            print("  d, :d         查看仪表盘")
            print("  save <名称>   保存状态")
            print("  load <名称>   加载状态")
            print("  q, :q         保存并退出")
            print("  ?<问题>       向基因群提问（临时回响）")
            print("  其他文本       喂养给基因群\n")
            continue

        # 提问模式（以 ? 开头）
        if user_input.startswith("？"):
            question = user_input[1:].strip()
            if not question:
                print("请在 ? 后输入想问的内容。")
                continue
            _update_concept_cache(question)
            response = generate_response(colony, question)
            print(f"  🗣️ 基因群回响: {response}")
            summary = colony.field.get_field_summary()
            print(f"  -> 步数 {colony.step_counter:4d} | 资源 {summary['total_resource']:7.2f} | 粒子 {summary['particle_count']:3d}")
            continue

        # 普通喂养
        colony.observe(user_input)
        _update_concept_cache(user_input)
        summary = colony.field.get_field_summary()
        print(f"  -> 步数 {colony.step_counter:4d} | 资源 {summary['total_resource']:7.2f} | 粒子 {summary['particle_count']:3d}")


if __name__ == "__main__":
    main()