import numpy as np
class Synapse:
    """粒子间的有向连接"""
    
    def __init__(self, pre_id, post_id, weight=None):
        self.pre_id = pre_id
        self.post_id = post_id
        self.weight = weight if weight is not None else np.random.randn() * 0.01
        self.resource = 0.1
        
        # STDP 时序记录
        self.last_pre_spike = 0.0
        self.last_post_spike = 0.0
        
        # 连接类型
        self.synapse_type = "normal"  # normal / shortcut / mother_child
        
    def to_dict(self):
        return {
            "pre_id": self.pre_id,
            "post_id": self.post_id,
            "weight": self.weight,
            "resource": self.resource,
            "last_pre_spike": self.last_pre_spike,
            "last_post_spike": self.last_post_spike,
            "synapse_type": self.synapse_type
        }
    
    @classmethod
    def from_dict(cls, data):
        s = cls(data["pre_id"], data["post_id"], data["weight"])
        s.resource = data["resource"]
        s.last_pre_spike = data["last_pre_spike"]
        s.last_post_spike = data["last_post_spike"]
        s.synapse_type = data["synapse_type"]
        return s