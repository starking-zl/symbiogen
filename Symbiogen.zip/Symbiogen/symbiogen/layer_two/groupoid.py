"""
群胚结构

管理所有词元及其连接，维持组合的封闭性。
群胚 = 对象(词元) + 态射(连接)，态射组合满足结合律。
"""

import numpy as np

class Groupoid:
    """词元群胚管理器"""
    
    def __init__(self):
        # 连接存储: source_id -> {target_id: Connection}
        self._connections = {}
        
        # 反向索引: target_id -> set of source_ids (用于快速查询入向连接)
        self._reverse_index = {}
        
        # 词元引用 (由外部设置)
        self.lexicon = None
    
    def set_lexicon(self, lexicon):
        """设置词元词典引用"""
        self.lexicon = lexicon
    
    def add_connection(self, source_id, target_id, conn_type=Connection.TYPE_ASSOCIATION):
        """添加连接"""
        if source_id not in self._connections:
            self._connections[source_id] = {}
        
        if target_id in self._connections[source_id]:
            # 连接已存在，返回现有连接
            return self._connections[source_id][target_id]
        
        conn = Connection(source_id, target_id, conn_type)
        self._connections[source_id][target_id] = conn
        
        # 更新反向索引
        if target_id not in self._reverse_index:
            self._reverse_index[target_id] = set()
        self._reverse_index[target_id].add(source_id)
        
        return conn
    
    def get_connection(self, source_id, target_id):
        """获取指定连接"""
        if source_id in self._connections:
            return self._connections[source_id].get(target_id, None)
        return None
    
    def get_outgoing(self, source_id, include_dormant=False):
        """获取词元的所有出向连接"""
        if source_id not in self._connections:
            return []
        conns = list(self._connections[source_id].values())
        if not include_dormant:
            conns = [c for c in conns if not c.dormant]
        return conns
    
    def get_incoming(self, target_id, include_dormant=False):
        """获取词元的所有入向连接"""
        if target_id not in self._reverse_index:
            return []
        sources = self._reverse_index[target_id]
        conns = []
        for src in sources:
            conn = self._connections.get(src, {}).get(target_id)
            if conn and (include_dormant or not conn.dormant):
                conns.append(conn)
        return conns
    
    def remove_connection(self, source_id, target_id):
        """删除连接"""
        if source_id in self._connections and target_id in self._connections[source_id]:
            del self._connections[source_id][target_id]
            if not self._connections[source_id]:
                del self._connections[source_id]
        
        if target_id in self._reverse_index:
            self._reverse_index[target_id].discard(source_id)
            if not self._reverse_index[target_id]:
                del self._reverse_index[target_id]
    
    def connection_exists(self, source_id, target_id):
        """检查连接是否存在"""
        return (source_id in self._connections and 
                target_id in self._connections[source_id])
    
    def get_all_connections(self, include_dormant=False):
        """获取所有连接列表"""
        all_conns = []
        for source, targets in self._connections.items():
            for target, conn in targets.items():
                if include_dormant or not conn.dormant:
                    all_conns.append(conn)
        return all_conns
    
    def total_connections(self, include_dormant=False):
        """连接总数"""
        if include_dormant:
            return sum(len(targets) for targets in self._connections.values())
        else:
            return sum(1 for conn in self.get_all_connections(include_dormant=False))
    
    def get_subgroupoid(self, center_id, radius=2):
        """
        获取以某个词元为中心的子群胚 (用于局部组合)
        
        参数:
            center_id: 中心词元
            radius: 跳数
        
        返回:
            (lexicon_subset, connections_subset)
        """
        visited = set()
        queue = [(center_id, 0)]
        lexicon_ids = set()
        
        while queue:
            curr, dist = queue.pop(0)
            if curr in visited or dist > radius:
                continue
            visited.add(curr)
            lexicon_ids.add(curr)
            
            # 出向
            for conn in self.get_outgoing(curr, include_dormant=False):
                if conn.target_id not in visited:
                    queue.append((conn.target_id, dist + 1))
            # 入向
            for conn in self.get_incoming(curr, include_dormant=False):
                if conn.source_id not in visited:
                    queue.append((conn.source_id, dist + 1))
        
        # 提取子集内的连接
        sub_conns = []
        for src in lexicon_ids:
            for conn in self.get_outgoing(src, include_dormant=False):
                if conn.target_id in lexicon_ids:
                    sub_conns.append(conn)
        
        return lexicon_ids, sub_conns
    
    def is_closed(self, lexicon_ids=None):
        """
        检查当前群胚是否封闭
        
        封闭性：任意两个可组合的词元，其组合结果仍在词元集内。
        由于组合结果可能产生新词元，群胚在动态扩张中保持“生成封闭性”。
        """
        # 简化：只要所有连接的源和目标都在已知词元内，则当前快照封闭
        if lexicon_ids is None:
            lexicon_ids = set(self.lexicon.keys()) if self.lexicon else set()
        
        for conn in self.get_all_connections(include_dormant=False):
            if conn.source_id not in lexicon_ids or conn.target_id not in lexicon_ids:
                return False
        return True
    
    def to_dict(self):
        """序列化"""
        return {
            "connections": {
                src: {tgt: conn.to_dict() for tgt, conn in targets.items()}
                for src, targets in self._connections.items()
            }
        }
    
    @classmethod
    def from_dict(cls, data):
        """反序列化"""
        g = cls()
        for src, targets in data["connections"].items():
            for tgt, conn_data in targets.items():
                conn = Connection.from_dict(conn_data)
                if src not in g._connections:
                    g._connections[src] = {}
                g._connections[src][tgt] = conn
                if tgt not in g._reverse_index:
                    g._reverse_index[tgt] = set()
                g._reverse_index[tgt].add(src)
        return g