"""
变异固化器

将评估通过的变异固化为系统的永久结构：
- 新词元：添加到词元词典
- 新连接：添加到群胚
- 连接调整：更新连接的倾向区间
"""

import numpy as np

class VariationSolidifier:
    """变异固化引擎"""
    
    def __init__(self):
        self.solidified_count = 0
        self.solidification_history = []
    
    def solidify(self, evaluated_variation, lexicon, groupoid, lexicon_initializer):
        """
        固化单个变异
        
        参数:
            evaluated_variation: 评估后的变异字典（包含 variation 和 score）
            lexicon: 词元词典
            groupoid: 群胚管理器
            lexicon_initializer: 词元初始化器
        
        返回:
            result: 固化结果信息
        """
        var = evaluated_variation["variation"]
        score = evaluated_variation["score"]
        var_type = var.get("type")
        
        result = {
            "type": var_type,
            "success": False,
            "details": None
        }
        
        if var_type == "new_lexion":
            result = self._solidify_new_lexion(var, score, lexicon, lexicon_initializer)
        elif var_type == "new_connection":
            result = self._solidify_new_connection(var, score, lexicon, groupoid)
        elif var_type == "adjust_connection":
            result = self._solidify_connection_adjustment(var, score)
        else:
            result["details"] = f"Unknown variation type: {var_type}"
        
        if result["success"]:
            self.solidified_count += 1
            self.solidification_history.append({
                "type": var_type,
                "score": score,
                "result": result
            })
            if len(self.solidification_history) > 100:
                self.solidification_history = self.solidification_history[-50:]
        
        return result
    
    def _solidify_new_lexion(self, variation, score, lexicon, lexicon_initializer):
        """固化新词元"""
        parent_name = variation["parent_name"]
        new_p = variation["new_p"]
        initial_sigma = variation.get("initial_sigma", 0.6)
        
        # 生成新词元名称
        new_name = f"{parent_name}_var_{self.solidified_count}"
        
        try:
            # 创建新词元
            new_lex = lexicon_initializer.create_new_lexion(new_name)
            new_lex.p = new_p
            new_lex.sigma = initial_sigma
            
            lexicon[new_name] = new_lex
            
            return {
                "type": "new_lexion",
                "success": True,
                "details": f"Created new lexion '{new_name}' from '{parent_name}'",
                "new_name": new_name,
                "score": score
            }
        except Exception as e:
            return {
                "type": "new_lexion",
                "success": False,
                "details": str(e)
            }
    
    def _solidify_new_connection(self, variation, score, lexicon, groupoid):
        """固化新连接"""
        source_name = variation["source_name"]
        target_name = variation["target_name"]
        initial_mu = variation.get("initial_mu", 0.1)
        initial_sigma = variation.get("initial_sigma", 0.5)
        conn_type = variation.get("connection_type", "association")
        
        if source_name not in lexicon or target_name not in lexicon:
            return {
                "type": "new_connection",
                "success": False,
                "details": f"Source or target lexion not found"
            }
        
        try:
            # 映射连接类型
            from symbiogen.layer_two.connection import Connection
            type_map = {
                "application": Connection.TYPE_APPLICATION,
                "modification": Connection.TYPE_MODIFICATION,
                "association": Connection.TYPE_ASSOCIATION
            }
            conn_type_enum = type_map.get(conn_type, Connection.TYPE_ASSOCIATION)
            
            # 创建连接
            conn = groupoid.add_connection(source_name, target_name, conn_type_enum)
            conn.mu = initial_mu
            conn.sigma = initial_sigma
            
            return {
                "type": "new_connection",
                "success": True,
                "details": f"Created connection {source_name} -> {target_name}",
                "connection": conn,
                "score": score
            }
        except Exception as e:
            return {
                "type": "new_connection",
                "success": False,
                "details": str(e)
            }
    
    def _solidify_connection_adjustment(self, variation, score):
        """固化连接调整"""
        conn = variation.get("connection")
        delta_mu = variation.get("delta_mu", 0)
        delta_sigma = variation.get("delta_sigma", 0)
        
        if conn is None:
            return {
                "type": "adjust_connection",
                "success": False,
                "details": "Connection is None"
            }
        
        try:
            conn.mu += delta_mu
            conn.sigma = max(0.05, min(0.95, conn.sigma + delta_sigma))
            
            return {
                "type": "adjust_connection",
                "success": True,
                "details": f"Adjusted connection {conn.source_id} -> {conn.target_id}",
                "new_mu": conn.mu,
                "new_sigma": conn.sigma,
                "score": score
            }
        except Exception as e:
            return {
                "type": "adjust_connection",
                "success": False,
                "details": str(e)
            }
    
    def solidify_batch(self, evaluated_variations, lexicon, groupoid, lexicon_initializer,
                       max_to_solidify=3):
        """
        批量固化变异，只固化分数最高的几个
        """
        results = []
        for ev in evaluated_variations[:max_to_solidify]:
            if ev["should_keep"]:
                result = self.solidify(ev, lexicon, groupoid, lexicon_initializer)
                results.append(result)
        return results
    
    def get_statistics(self):
        """获取固化统计"""
        return {
            "total_solidified": self.solidified_count,
            "history_length": len(self.solidification_history)
        }