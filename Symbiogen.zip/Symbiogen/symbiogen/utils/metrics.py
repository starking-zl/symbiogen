"""生命体征计算（简化版）"""
import numpy as np

def total_resource(colony_or_field):
    """总资源（词元活跃度之和）"""
    lexicon = colony_or_field.lexicon if hasattr(colony_or_field, 'lexicon') else colony_or_field
    return sum(lex.resource if hasattr(lex, 'resource') else 1.0 for lex in lexicon.values())

def particle_count(colony_or_field):
    """词元数量"""
    lexicon = colony_or_field.lexicon if hasattr(colony_or_field, 'lexicon') else colony_or_field
    return len(lexicon)

def module_count(colony_or_field):
    """模块数（连通分量数）"""
    groupoid = colony_or_field.groupoid if hasattr(colony_or_field, 'groupoid') else None
    if groupoid is None:
        return 0
    connections = groupoid.get_all_connections(include_dormant=False)
    if not connections:
        return 0
    graph = {}
    for conn in connections:
        graph.setdefault(conn.source_id, []).append(conn.target_id)
    visited = set()
    modules = 0
    def dfs(node):
        stack = [node]
        while stack:
            cur = stack.pop()
            if cur in visited:
                continue
            visited.add(cur)
            for nxt in graph.get(cur, []):
                if nxt not in visited:
                    stack.append(nxt)
    for node in graph:
        if node not in visited:
            dfs(node)
            modules += 1
    return modules

def curvature_variance(colony):
    """平均离散度的方差（近似曲率方差）"""
    lexicon = colony.lexicon
    if not lexicon:
        return 0.0
    sigmas = [lex.sigma for lex in lexicon.values()]
    return np.var(sigmas)

def blueprint_fidelity(colony):
    """蓝图吻合度（简化：平均确定性）"""
    lexicon = colony.lexicon
    if not lexicon:
        return 1.0
    return np.mean([1.0 - lex.sigma for lex in lexicon.values()])

def novelty_responsiveness(colony):
    """新奇响应度（基于近期失谐度）"""
    buf = colony.scheduler.dissonance_buffer
    if not buf:
        return 0.5
    return np.mean(buf)

def compute_fitness(vital_signs):
    """适应度综合评分"""
    weights = {"blueprint_fidelity": 0.35, "module_count": 0.25,
               "curvature_variance": 0.20, "novelty_responsiveness": 0.20}
    normalized = {
        "blueprint_fidelity": vital_signs.get("blueprint_fidelity", 0.5),
        "module_count": min(vital_signs.get("module_count", 5) / 20.0, 1.0),
        "curvature_variance": min(vital_signs.get("curvature_variance", 0.1) / 0.5, 1.0),
        "novelty_responsiveness": min(vital_signs.get("novelty_responsiveness", 0.1) / 0.3, 1.0)
    }
    fitness = sum(weights[k] * normalized[k] for k in weights)
    return min(max(fitness, 0.0), 1.0)

def get_vital_signs(colony):
    """获取完整生命体征"""
    signs = colony.export_vital_signs()
    signs.update({
        "total_resource": total_resource(colony),
        "particle_count": particle_count(colony),
        "module_count": module_count(colony),
        "curvature_variance": curvature_variance(colony),
        "blueprint_fidelity": blueprint_fidelity(colony),
        "novelty_responsiveness": novelty_responsiveness(colony)
    })
    return signs