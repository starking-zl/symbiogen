"""
失谐度计算器

使用KL散度 (Kullback-Leibler Divergence) 度量词元当前概率分布
与环境输入期望分布之间的差异。
"""

import numpy as np

class DissonanceCalculator:
    """失谐度计算引擎"""
    
    def __init__(self, epsilon=1e-12):
        """
        参数:
            epsilon: 数值稳定性的小量，防止log(0)
        """
        self.epsilon = epsilon
    
    def compute_kl_divergence(self, p, q):
        """
        计算两个概率分布之间的KL散度 D_KL(p || q)
        
        参数:
            p: 第一个概率分布 (通常是环境证据)
            q: 第二个概率分布 (通常是词元当前状态)
        
        返回:
            kl: KL散度值
        """
        # 确保是归一化的概率分布
        p = p / (np.sum(p) + self.epsilon)
        q = q / (np.sum(q) + self.epsilon)
        
        kl = 0.0
        for i in range(len(p)):
            if p[i] > self.epsilon and q[i] > self.epsilon:
                kl += p[i] * np.log(p[i] / q[i])
        
        return kl
    
    def compute_dissonance(self, lexion, evidence_vector, use_symmetric=False):
        """
        计算词元与环境证据之间的失谐度
        
        参数:
            lexion: 词元对象 (具有 p 属性)
            evidence_vector: 环境提供的证据向量
            use_symmetric: 是否使用对称KL散度 (Jensen-Shannon)
        
        返回:
            dissonance: 失谐度值
        """
        # 确保证据向量归一化
        ev = evidence_vector / (np.sum(evidence_vector) + self.epsilon)
        
        if use_symmetric:
            # Jensen-Shannon散度: (KL(P||M) + KL(Q||M)) / 2
            m = (lexion.p + ev) / 2.0
            kl_pm = self.compute_kl_divergence(lexion.p, m)
            kl_qm = self.compute_kl_divergence(ev, m)
            return (kl_pm + kl_qm) / 2.0
        else:
            # 非对称KL散度: D_KL(evidence || lexion)
            return self.compute_kl_divergence(ev, lexion.p)
    
    def compute_batch_dissonance(self, lexicon, evidence_dict):
        """
        批量计算多个词元的失谐度
        
        参数:
            lexicon: 词元词典 {name: Lexion}
            evidence_dict: {lexion_name: evidence_vector}
        
        返回:
            dissonances: {lexion_name: dissonance}
        """
        results = {}
        for name, lex in lexicon.items():
            if name in evidence_dict:
                results[name] = self.compute_dissonance(lex, evidence_dict[name])
        return results
    
    def compute_weighted_dissonance(self, lexicon, evidence_dict, attention_weights):
        """
        计算加权平均失谐度 (用于评估整体失谐程度)
        
        参数:
            lexicon: 词元词典
            evidence_dict: 证据词典
            attention_weights: 各词元的注意力权重
        
        返回:
            weighted_dissonance: 加权平均失谐度
        """
        total_weight = 0.0
        weighted_sum = 0.0
        
        for name, weight in attention_weights.items():
            if name in lexicon and name in evidence_dict:
                lex = lexicon[name]
                diss = self.compute_dissonance(lex, evidence_dict[name])
                weighted_sum += weight * diss
                total_weight += weight
        
        if total_weight == 0:
            return 0.0
        return weighted_sum / total_weight