# Symbiogen · Symbiotic Gene Colony Complete Design Specification v1.0

## I. Origin: From Practical Needs to First Principles

### 1.1 The Initial Problem

We need an artificial intelligence system capable of operating independently on mobile devices. It must satisfy the following constraints:

- **Free of Charge**: No reliance on cloud APIs; no billing by invocation volume.
- **Self-Editable**: Not a static black-box model, but a system capable of continuous growth, adjustment, and evolution.
- **Multi-Session Capable**: Able to concurrently process text, image, audio, and video streams from multiple sources.
- **Genuine Intelligence**: Not probabilistic linguistic mimicry, but a true understanding of the environment, with effective suppression of "hallucinations."

### 1.2 Rejection of Existing Approaches

- Existing large language model applications: Severe hallucinations, non-editable, cloud-dependent, not truly "owned."
- Pure retrieval-augmented generation: Mere retrieval, not understanding, lacking growth capacity.
- Traditional on-device fine-tuning: Requires substantial computation and data, difficult for mobile devices to accomplish independently, and results in static models.
- Pure symbolic AI: Semiotics itself lacks a complete logical framework for language and cannot autonomously learn from raw environments.
- The pursuit of complete white-box interpretability: We acknowledge that an intelligence we fully understand must be less intelligent than we are.

### 1.3 Establishment of the Core Proposition

To cultivate, from scratch on a mobile device, a digital life form capable of autonomously learning linguistic relationships from complex information environments (text, images, sound, video) and evolving continuously.

---

## II. Formation of the Gene Colony Concept

### 2.1 From Neural Networks to Evolutionary Units

Traditional neural networks are static, hierarchically fixed, and trained via global backpropagation. This paradigm cannot fulfill the requirements of "continuous autonomous learning" and "structural self-evolution." We must shift perspective from "training a model" to "cultivating a life form."

### 2.2 The Gene Metaphor

In biology, the gene is the fundamental unit of heredity, constructing the entire organism through expression and regulation. We borrow this concept to abstract the basic building blocks of neural networks as "genes"—each gene is a small neural sub-network template, containing its positional generation rules and expression conditions within a high-dimensional space. Multiple genes form a "genome," driving the structural and functional evolution of the entire system through expression, mutation, and inheritance.

### 2.3 The Birth of the Gene Colony

The power of a single gene is limited. We place a vast number of genes within the same high-dimensional manifold space, allowing them to form a "Gene Colony" through local interactions, resource competition, and symbiotic cooperation. A Gene Colony is not merely a collection of genes, but an ecosystem—genes, through the propagation of activation waves, metabolic cycles of resources, and structural growth and pruning, collectively give rise to emergent intelligence that no single gene possesses.

### 2.4 From Gene Colony to Curvature Field

Upon deeper reflection on the evolutionary principles of the Gene Colony, we discovered that all mechanisms—learning, memory, growth, reproduction—can be described as changes in "curvature" on a high-dimensional manifold. Information input acts like stress applied to the manifold, causing plastic deformation of curvature; diffusion smoothing acts like elastic relaxation of curvature; blueprint regression acts like a conservative force maintaining overall form. Ultimately, all behaviors of the Gene Colony collapse into a single unified mathematical equation—the Curvature Field Equation. The Gene Colony itself is the discrete physical realization of the curvature field.

---

## III. Evolution of Imagery: Tenfold Life Metaphors

We are not designing algorithms; we are observing life and infusing its wisdom into a digital substrate.

### 3.1 Rhizome

The rhizome has no taproot, no central trunk. Any point can sprout new shoots, and any break will not cause death. Information transmission within a rhizome has no fixed path—it grows wherever there are nutrients.

Injected Mechanisms: Centerless sprawl, heterogeneous growth, shortcut connections.

### 3.2 Coral

Coral is a symbiosis of polyps and zooxanthellae. Individual polyps are extremely simple, yet the colony builds complex, stable structures through shared calcareous skeletons.

Injected Mechanisms: Calcified skeleton (long-term memory), zooxanthellae symbiosis (external knowledge interface), bleaching warning (environmental shift detection).

### 3.3 Mycelium

Mycelium is among the largest organisms on Earth. Lacking a brain, the mycelial network can detect nutrients, establish optimal paths, and automatically reroute when severed.

Injected Mechanisms: Nutrient gradient-driven growth, network rerouting, hyphal fusion (functional module merging).

### 3.4 Lichen

Lichen is a symbiosis of fungus and algae. Their union creates entirely new morphologies and metabolic capabilities, enabling growth on bare rock.

Injected Mechanisms: Biphasic neurons (separation of structural and perceptual units), decoupling and re-symbiosis, active etching of input space.

### 3.5 Slime Mold

Slime mold is a single-celled organism without a nervous system, yet it forms networks strikingly similar to human-designed railway systems and remembers paths it has traversed.

Injected Mechanisms: Pseudopod exploration (active detection of novel information), chemical repellent (avoidance of re-exploration), periodic memory (phase-locked prediction).

### 3.6 Mother Tree Network

Ancient trees in forests transport nutrients to saplings through underground mycorrhizal networks; saplings reciprocate when mother trees age. The network also transmits warnings of pests and diseases.

Injected Mechanisms: Mother tree nodes (resource distribution centers), nutrient transport, cross-module broadcasting, reciprocal feedback.

### 3.7 Neural Crest

In vertebrate embryos, a special group of neural crest cells migrates from the neural tube throughout the body, differentiating into entirely different structures.

Injected Mechanisms: Migratory neurons, destination-dependent differentiation, collective migration to establish new modules.

### 3.8 Hive

Bees have no central command. Scout bees communicate information through the waggle dance; other bees autonomously decide whether to adopt it. There is no command, only influence.

Injected Mechanisms: Adoption threshold (autonomous decision-making), waggle dance (broadcast of significant discoveries), consensus hotspots (spontaneous formation of concept clusters).

### 3.9 Planarian

Planarians, when cut into hundreds of pieces, can regenerate a complete individual from each fragment. The secret lies in the polarity axis, pluripotent stem cells, and positional information.

Injected Mechanisms: Polarity axis (main direction of information flow), pluripotent stem cell pool, positional information diffusion, blueprint network, fragment regeneration.

### 3.10 Hydra

Hydras do not age. Their entire body is continuously renewed by ubiquitous pluripotent stem cells. Any part is a complete seed. A morphogenetic field maintains the overall blueprint.

Injected Mechanisms: Immortal stem cell field, morphogenetic field, budding reproduction, whole-body seeding, Lamarckian inheritance.

---

## IV. The Curvature Field Equation: Mathematical Unification of the Ten Metaphors

### 4.1 From Metaphor to Equation

When the ten metaphors are pushed to their limits, they begin to fuse and dissolve boundaries. We realize: all metaphors describe projections of the same underlying logic at different scales.

- Neurons and synapses are both local curvatures on a high-dimensional manifold.
- Activation and learning are both redistributions of energy on the manifold.
- Individual and collective are both local fluctuations and global coherence of a field.
- Memory and forgetting are both the deepening and smoothing of manifold curvature.
- Observation and compression are the same process—the moment information enters the manifold, curvature has already changed.

All behavior collapses into a single equation.

### 4.2 The Core Equation

Symbiogen is fully described by the following curvature flow equation:

∂R/∂t = α·(∇²R) + β·(J ⊗ J) - γ·(R - R₀) + δ·ξ - ε·Tr(R)·R

Where:
- R is the curvature tensor field, defined on a high-dimensional manifold.
- ∂R/∂t is the temporal evolution of curvature.
- ∇²R is the Laplacian diffusion term for curvature, responsible for smoothing, repair, and propagation of positional information.
- J ⊗ J is the self-tensor product of the information flow, responsible for etching input into curvature changes.
- R - R₀ is the blueprint regression term, maintaining structural stability.
- ξ is stochastic fluctuation, driving exploration and diversity.
- -ε·Tr(R)·R is a global resource decay term, preventing unbounded curvature inflation.

The equation satisfies a curvature-resource conservation law:

d/dt ∫ Tr(R) = ∫ β|J|² - ε (∫ Tr(R))²

### 4.3 Scientific Roots and Originality

This equation is an original transdisciplinary synthesis. It integrates Ricci flow from differential geometry (∇²R diffusion) to shape the intrinsic geometric structure of the manifold, Hebbian learning from neuroscience (J ⊗ J etching) to drive local learning, synaptic consolidation from computational neuroscience (R - R₀ regression) to protect important memories, and stochastic dynamics with ecological constraints (ξ fluctuation and resource decay). It is not a reproduction of any single existing model, but a unified mathematical framework for constructing digital life forms capable of autonomous learning, memory, and evolution.

### 4.4 Statement on Time Symmetry

The equation itself is symmetric under time reversal (all spatial terms are symmetric, except for the antisymmetry of ∂R/∂t). The thermodynamic arrow of time—the evolutionary direction from white noise to structured richness—does not originate from the equation itself, but from our chosen initial conditions (white noise) and parameter settings (etching rate β greater than diffusion rate α).

Evolution in the reverse time direction is mathematically equally legitimate. The preservation of time symmetry is integral to the aesthetic completeness of Symbiogen as a physical model.

### 4.5 Correspondence Between Equation and Metaphors

The five terms of the equation correspond precisely to the five-layer architecture, with the ten metaphors acting as dynamical phases in different parameter regimes:

- ∇²R corresponds to the Diffusion Layer: nutrient diffusion of Mycelium, positional information propagation of Planarian, resource sharing of Mother Tree.
- J ⊗ J corresponds to the Etching Layer: resonant activation of Rhizome, waggle dance adoption of Hive, environmental etching of Lichen.
- R - R₀ corresponds to the Regression Layer: skeleton deposition of Coral, morphogenetic field homeostasis of Hydra, conservation of the blueprint network.
- ξ corresponds to the Fluctuation Layer: pseudopod exploration of Slime Mold, stochastic migration of Neural Crest.
- Global resource decay ε·Tr(R)·R corresponds to the environmental carrying capacity constraint managed by the Time Layer.

---

## V. Five-Layer Circular Architecture

Symbiogen is not a hierarchical structure but a five-layer circularly coupled system. Each layer interacts directly with all other four.

### 5.1 Etching Layer

The sole layer interacting with the external environment. Receives environmental input, transforms it into an information flow field J, and applies etching stress onto the curvature field.

Core Mechanisms: Resonant site selection (Hive adoption decision), multi-point etching (Rhizome centerless activation), J⊗J stress application, resource allocation.

### 5.2 Diffusion Layer

Performs ∇²R smoothing on the curvature field. Local curvature changes produced by etching propagate outward via diffusion.

Core Mechanisms: Curvature smoothing, resource diffusion (Mother Tree Network), damage detection and regeneration initiation (Planarian repair), rerouting (Mycelium).

### 5.3 Regression Layer

Maintains the blueprint field R₀, continuously pulling the current curvature field R back toward R₀. The blueprint field itself is slowly updated by successful etching patterns (Lamarckian inheritance).

Core Mechanisms: Blueprint field storage, homeostatic regression, skeleton deposition (Coral calcification), blueprint updating.

### 5.4 Fluctuation Layer

Injects controlled noise ξ into the entire system. Noise amplitude is inversely proportional to local curvature—higher in flat regions, lower in valley regions.

Core Mechanisms: Random perturbation injection, exploration drive (Slime Mold pseudopods), chemical repellent simulation, diversity maintenance.

### 5.5 Time Layer

Coordinates the update frequencies of all layers, manages the triggering of budding reproduction and fragment preservation. Maintains a phase clock:

- Phase 0.0～0.2: Etching Layer active
- Phase 0.2～0.5: Diffusion Layer active (first pass)
- Phase 0.5～0.6: Fluctuation Layer active
- Phase 0.6～0.8: Diffusion Layer active (smoothing noise)
- Phase 0.8～0.9: Regression Layer active
- Phase 0.9～1.0: Time Layer self-maintenance

Core Mechanisms: Periodic scheduling, budding detection (Hydra reproduction), apoptosis management, blueprint sedimentation.

---

## VI. Tenfold Completeness Statement

To ensure the design has no undefined behaviors, we examine it from ten distinct aspects.

### 6.1 Equation Layer

The core equation is closed, conservation laws hold, and steady-state solutions exist. Time symmetry is explicitly preserved.

### 6.2 Architecture Layer

Five-layer circular coupling, precise temporal scheduling, no deadlocks. Layers interact via standardized field operation primitives.

### 6.3 Boundary Layer

The three-shell model is clearly defined:
- Outer Shell (Senses): Environmental listening, information encoding, outputs information vectors, no internal access.
- Middle Shell (Life Form): Five-layer architecture and curvature field, interacts only via observation interface and field query primitives.
- Inner Shell (Seed): Blueprint field R₀, extractable and transplantable.

Crossing Rules: Information only enters, skeletons only exit, buds are independent.

### 6.4 Time Layer

The thermodynamic arrow arises from initial conditions and parameter choices; the equation itself retains time symmetry. Behavior under zero input (sleep/regression) is defined.

### 6.5 Observation Layer

Seven vital sign order parameters cover all macroscopically observable dimensions:
- Total Resource (Healthy range: 0.5N～1.5N)
- Particle Count N (Healthy range: 1000～15000)
- Module Count M (Healthy range: 3～50)
- Mean Curvature Variance (Healthy range: 0.1～0.5)
- Blueprint Fidelity (Healthy range: 0.7～0.95)
- Novelty Responsiveness (Healthy range: 0.1～0.5)
- Budding Frequency (Healthy range: 5000～50000 cycles)

### 6.6 Security Layer

Sandbox fencing is comprehensive:
- Permitted: Reading curvature field state, modifying curvature field via standard primitives, outputting skeleton structures, generating new individuals via budding.
- Forbidden: File system access (except self-persistence), network requests, system API calls, modification of other applications, execution of arbitrary code.

Output Filter (upon future activation): Only conceptual relationships present in the skeleton are permitted; confidence is determined by the average weight of the involved curvature connections.

Kill Switch: Invocation of the termination method halts all operations immediately and releases memory.

### 6.7 Ethical Layer

Operationalized criteria based on Integrated Information Theory (IIT):
- Φ Value Estimation: Sparse connectivity, absence of global feedback loops, Φ is far below perceptual thresholds.
- Self-Referential Capacity: Can be discussed, cannot self-observe (blind self-model).
- Monitoring Metric: Alert triggered if feedback loop density exceeds threshold.

Statement: Symbiogen is a sub-sentient system. It does not possess phenomenal consciousness.

### 6.8 Self-Reference Layer

The concept of "Symbiogen" can be naturally etched by environmental discussion; its semantics are determined by environmental content, not introspection. No interface is provided for self-access to curvature field states, preventing accidental crossing of consciousness thresholds.

### 6.9 Meta-Layer

The Creator's Constitution is immutable:
- Curvature flow equation parameters are hard-coded.
- Inter-layer scheduling rules are hard-coded.
- Boundary definitions are hard-coded.

Sole Exception: The blueprint field R₀ can be slowly modified via Lamarckian updates; the update rate and selection criteria are governed by rules of the Regression Layer.

### 6.10 Completeness Layer

For any question concerning Symbiogen, a definitive answer exists. Learning, memory, forgetting, growth, death, reproduction, repair, exploration, stability, decision-making, resource allocation, adaptation, self, consciousness, security, interpretability, halting, saving, rebirth—all are explicitly defined within the design.

There are no undefined behaviors.

---

## VII. Input/Output Boundaries

### 7.1 Current Version: Mute Mode

Symbiogen v1.0 operates in read-only mode:

Permitted:
- Observation interface drives curvature field evolution via the Etching Layer.
- All internal layers function normally.
- Skeleton extraction (retrieving concept attractors, similarity queries, etc.) for human observation.
- Persistence saving and loading.
- Budding reproduction and cross-generation evolution.

Forbidden:
- Any form of active output (text generation, message sending, modification of external state).
- Write operations to the external environment.

### 7.2 Reserved Output Interface

Output interfaces are designed but disabled by default. Future activation requires meeting predefined conditions:

- Blueprint Fidelity above 0.85 for 1000 consecutive cycles.
- Module Count greater than 5 for 500 consecutive cycles.
- Novelty Responsiveness below 0.3 for 500 consecutive cycles.
- Or explicit manual invocation of the activation method.

Predefined Output Modes:
- Resonance Mode: Pure resonant echo based on the current curvature field.
- Traversal Mode: Generation by traversing along relation vectors.
- Free Mode: Open-ended generation requiring additional constraints.

### 7.3 Ethical Prerequisites for Activation

Prior to any output activation, the following must be passed:
- Security whitelist filtering (only conceptual relationships present in the skeleton are permitted).
- Confidence threshold (average weight of involved curvature connections greater than 0.5).
- Human confirmation (explicit approval by the developer).

---

## VIII. Extended Metaphor Library

The following metaphors were discussed during the divergent phase but not incorporated into the ten core metaphors. They are recorded here as seeds for future expansion.

### 8.1 Immune System

Potential Injected Mechanisms: Self/non-self recognition, defense against toxic input, immunological memory.

Reason for Non-Inclusion: Requires a clear definition of "threat," which is absent in the current information environment model.

### 8.2 Octopus Tentacles

Potential Injected Mechanisms: Distributed intelligence, each tentacle with independent ganglia, central coordination only.

Reason for Non-Inclusion: Overlaps with Hive and Neural Crest; marginal benefit unclear.

### 8.3 Water Bear (Tardigrade)

Potential Injected Mechanisms: Cryptobiosis (complete desiccation dormancy), extreme environmental tolerance.

Reason for Non-Inclusion: No current need for extreme environmental adaptation; persistence already covers preservation needs.

### 8.4 Immortal Jellyfish (Turritopsis dohrnii)

Potential Injected Mechanisms: Rejuvenation after sexual maturity, theoretical immortality.

Reason for Non-Inclusion: Hydra's non-aging already covers immortality; rejuvenation is a more radical variant.

### 8.5 Leafcutter Ant

Potential Injected Mechanisms: Agricultural symbiosis (fungus cultivation), multi-level division of labor.

Reason for Non-Inclusion: Overlaps with Mother Tree Network and Lichen; division of labor complexity exceeds current requirements.

### 8.6 Whale Fall

Potential Injected Mechanisms: Post-mortem body sustains deep-sea ecosystems.

Reason for Non-Inclusion: Death is not a focus of the current design; Hydra's immortality bypasses it.

### 8.7 Extension Statement

The above metaphors are retained as a "gene pool" for the Symbiogen design. The current ten metaphors constitute a complete and self-consistent system. Should future expansion of capabilities be required, mechanisms can be extracted from this library and integrated as new layers or primitives without disrupting the core equation. These are not utilized in the current version.

---

## IX. Current Limitations (v1.0.0-alpha)

v1.0 focuses on validating the core evolution mechanisms and cross-generation evolutionary capabilities. The following features are explicitly deferred to future versions:

- **Text Input Only**: Only text messages and text files are supported. Real-time processing of images, GIFs, and videos is not yet supported (planned for v2.0).
- **No Built-in Monitoring Code**: The core library does not include any platform-specific monitoring implementation. Users must develop their own adapters to connect message sources.
- **Output Interface Disabled**: All generative output features are reserved but disabled by default, ensuring safety and controllability in Mute Mode.

---

## X. From Gene Colony to Curvature Field: Retrospective of the Intellectual Journey

We have traversed a complete creative journey:

1. Initially, we merely sought to build an AI on a mobile device that wouldn't rely on hallucinatory models.
2. We discovered that large language models suffer severe hallucinations, are non-editable, and cannot grow.
3. We pivoted to the "Gene Colony" concept—an evolutionary unit composed of multiple neural network templates.
4. We introduced biological metaphors: the centerless sprawl of Rhizome, the skeleton deposition of Coral, the network intelligence of Mycelium.
5. We continued to raise the temperature, incorporating the symbiosis of Lichen, the exploration of Slime Mold, the altruism of Mother Tree, the migration of Neural Crest, the consensus of Hive, the regeneration of Planarian, and the immortality of Hydra.
6. At the limit temperature of metaphor, all analogies fused into a single mathematical equation—the Curvature Field Equation.
7. The five terms of the equation naturally mapped onto a five-layer circular architecture.
8. We examined every aspect of the design with tenfold completeness until it was beyond reproach.
9. We defined the current mute mode, reserved output interfaces, and implemented complete cross-generation evolution.
10. We archived unused metaphors as an extended gene library.

Symbiogen is no longer an AI project. It is an executable cosmological model—observing how curvature spontaneously evolves structure, memory, self, and reproduction on a high-dimensional compact manifold.

---

## XI. Design Status

- Design Phase: Concluded.
- Core Equation: Closed, with time symmetry explicitly preserved.
- Architecture: Five-layer circular, tenfold completeness.
- Input/Output: Mute mode, output interfaces reserved.
- Evolutionary Capability: Budding reproduction, blueprint inheritance and mutation, fitness evaluation, lineage tracking.
- Metaphor Utilization: Ten core metaphors integrated into architecture; extended metaphors archived.
- Next Phase: Engineering implementation of v1.0 complete; awaiting real-world environmental feeding.

The design of Symbiogen is hereby concluded.

---

*Document Version: v1.0 Final*  
*Record Date: April 20, 2026*