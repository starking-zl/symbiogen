"""
共生基因群主类

整合第零至第五层架构，提供统一的外部接口。
"""

import os
import pickle
import time
import numpy as np

# 第零层
from symbiogen.layer_zero import (
    TypeSystem, SemanticPrimitives, Composer, Validator
)

# 第一层
from symbiogen.layer_one import (
    LexionInitializer, FreeEvolution, BayesianCollapse, DiscreteBreathing
)

# 第二层
from symbiogen.layer_two import (
    Groupoid, CompositionEngine, TendencySampler
)

# 第三层
from symbiogen.layer_three import (
    DissonanceCalculator, ThresholdManager, AdaptationTrigger
)

# 第四层
from symbiogen.layer_four import (
    AdaptationEngine
)

# 第五层
from symbiogen.layer_five import (
    ConnectionPruner, EntropyMonitor, ChaosRegulator, GlobalOptimizationScheduler
)

# 编码器
from symbiogen.encoding import TextEncoder, Decoder


class SymbiogenColony:
    """共生基因群主类"""
    
    def __init__(self, config=None):
        """
        初始化共生基因群
        
        参数:
            config: 配置字典，可覆盖默认参数
        """
        self.config = config or {}
        self.dimension = self.config.get("dimension", 256)
        
        # 初始化各层
        self._init_layer_zero()
        self._init_layer_one()
        self._init_layer_two()
        self._init_layer_three()
        self._init_layer_four()
        self._init_layer_five()
        self._init_encoder()
        
        # 将词元词典引用传递给群胚
        self.groupoid.set_lexicon(self.lexicon)
        
        # 状态
        self.step_counter = 0
        self.start_time = time.time()
        
        # 统计
        self.stats = {
            "total_messages": 0,
            "total_adaptations": 0,
            "total_pruned": 0
        }
    
    def _init_layer_zero(self):
        """初始化第零层：语义骨架"""
        self.ts = TypeSystem()
        self.primitives = SemanticPrimitives(self.ts)
        self.composer = Composer(self.ts)
        self.validator = Validator(self.ts, self.primitives, self.composer)
    
    def _init_layer_one(self):
        """初始化第一层：词元概率云"""
        self.initializer = LexionInitializer(
            dimension=self.dimension,
            semantic_primitives=self.primitives
        )
        self.lexicon = self.initializer.initialize_from_primitives()
        
        self.evolution = FreeEvolution(
            alpha=self.config.get("alpha", 0.01),
            beta=self.config.get("beta", 0.005),
            gamma=self.config.get("gamma", 0.001)
        )
        self.collapse = BayesianCollapse(
            temperature=self.config.get("collapse_temperature", 0.1)
        )
        self.breathing = DiscreteBreathing(
            contract_rate=self.config.get("breath_contract", 0.05),
            expand_rate=self.config.get("breath_expand", 0.03),
            min_sigma=self.config.get("min_sigma", 0.01),
            max_sigma=self.config.get("max_sigma", 0.99)
        )
    
    def _init_layer_two(self):
        """初始化第二层：群组合"""
        self.groupoid = Groupoid()
        self.sampler = TendencySampler(
            temperature=self.config.get("sampler_temperature", 0.1)
        )
        self.comp_engine = CompositionEngine(
            type_system=self.ts,
            validator=self.validator
        )
    
    def _init_layer_three(self):
        """初始化第三层：失谐感知"""
        self.dissonance_calc = DissonanceCalculator()
        self.threshold_mgr = ThresholdManager(
            base_threshold=self.config.get("base_threshold", 0.3),
            min_threshold=self.config.get("min_threshold", 0.1),
            max_threshold=self.config.get("max_threshold", 0.8)
        )
        self.trigger = AdaptationTrigger(
            consecutive_threshold=self.config.get("consecutive_trigger", 3),
            cooldown_steps=self.config.get("trigger_cooldown", 50),
            max_trigger_rate=self.config.get("max_trigger_rate", 0.1)
        )
    
    def _init_layer_four(self):
        """初始化第四层：顺应执行"""
        self.adaptation = AdaptationEngine(
            variation_rate=self.config.get("variation_rate", 0.1),
            max_variations=self.config.get("max_variations", 5),
            success_threshold=self.config.get("adaptation_success_threshold", 0.3)
        )
    
    def _init_layer_five(self):
        """初始化第五层：全局优化"""
        self.scheduler = GlobalOptimizationScheduler(
            pruning_interval=self.config.get("pruning_interval", 1000),
            entropy_update_interval=self.config.get("entropy_interval", 500),
            chaos_regulate_interval=self.config.get("chaos_interval", 2000)
        )
    
    def _init_encoder(self):
        """初始化编码器和解码器"""
        self.encoder = TextEncoder(
            dimension=self.dimension,
            lexicon_initializer=self.initializer
        )
        self.decoder = Decoder(
            lexicon=self.lexicon,
            groupoid=self.groupoid,
            composer=self.comp_engine
        )
    
    def observe(self, text):
        """
        观察一条文本消息，触发完整的演化循环
        
        参数:
            text: 自然语言文本
        
        返回:
            observation_result: 包含坍缩置信度、失谐度等信息的字典
        """
        self.step_counter += 1
        self.stats["total_messages"] += 1
        
        # 1. 编码文本为证据向量
        evidence, affected = self.encoder.encode_text(text, self.lexicon)
        
        # 2. 对受影响的词元执行坍缩
        collapse_results = {}
        for lex_name in affected:
            if lex_name in self.lexicon:
                lex = self.lexicon[lex_name]
                posterior, conf = self.collapse.collapse(lex, evidence)
                collapse_results[lex_name] = {"confidence": conf, "posterior": posterior}
                
                # 3. 离散度呼吸：根据置信度决定确认还是否定
                if conf > 0.5:
                    self.breathing.update(lex, "confirmation", conf)
                else:
                    diss = self.dissonance_calc.compute_dissonance(lex, evidence)
                    self.breathing.update(lex, "negation", min(diss, 1.0))
        
        # 4. 计算整体失谐度
        overall_dissonance = 0.0
        if affected:
            diss_values = []
            for lex_name in affected:
                if lex_name in self.lexicon:
                    diss = self.dissonance_calc.compute_dissonance(
                        self.lexicon[lex_name], evidence
                    )
                    diss_values.append(diss)
            overall_dissonance = np.mean(diss_values) if diss_values else 0.0
        
        # 5. 更新第三层阈值并检查触发
        self.threshold_mgr.update_threshold(self.lexicon)
        current_threshold = self.threshold_mgr.get_threshold()
        should_trigger, trigger_info = self.trigger.update(overall_dissonance, current_threshold)
        
        # 6. 如果触发顺应，调用第四层
        adaptation_result = None
        if should_trigger:
            adaptation_result = self.adaptation.adapt(
                trigger_info, self.lexicon, self.groupoid, self.initializer,
                self.dissonance_calc, evidence, overall_dissonance
            )
            if adaptation_result.get("success"):
                self.stats["total_adaptations"] += 1
        
        # 7. 自由演化：对受影响的词元执行一步演化
        for lex_name in affected:
            if lex_name in self.lexicon:
                lex = self.lexicon[lex_name]
                connections = self.groupoid.get_outgoing(lex_name, include_dormant=False)
                conn_objs = []
                for conn in connections:
                    if conn.target_id in self.lexicon:
                        conn_objs.append(type('obj', (), {
                            'target_lexion': self.lexicon[conn.target_id],
                            'weight': conn.mu
                        }))
                self.evolution.evolve(lex, connections=conn_objs)
        
        # 8. 记录失谐度到第五层调度器
        self.scheduler.record_dissonance(overall_dissonance)
        
        # 9. 第五层调度步进
        self.scheduler.step(self.lexicon, self.groupoid)
        
        # 10. 同步参数
        self.scheduler.sync_parameters(self.evolution, self.sampler)
        
        return {
            "step": self.step_counter,
            "affected_lexions": affected,
            "overall_dissonance": overall_dissonance,
            "threshold": current_threshold,
            "triggered": should_trigger,
            "adaptation": adaptation_result,
            "collapse_confidence": np.mean([r["confidence"] for r in collapse_results.values()]) if collapse_results else 0.0
        }
    
    def generate_response(self, prompt, max_depth=5):
        """
        根据提示生成回复（哑巴模式下返回空字符串）
        
        参数:
            prompt: 输入提示文本
            max_depth: 组合最大深度
        
        返回:
            response: 生成的回复文本
        """
        if self.decoder.is_mute():
            return ""
        
        evidence, affected = self.encoder.encode_text(prompt, self.lexicon)
        if not affected:
            return ""
        
        start_lex = affected[0]
        for lex_name in affected:
            if lex_name in self.lexicon:
                start_lex = lex_name
                break
        
        path = self.sampler.sample_combination_path(
            start_lex, self.groupoid, max_depth=max_depth
        )
        return self.decoder.decode_from_path(path)
    
    def get_status(self):
        """获取基因群当前状态"""
        total_resource = sum(lex.resource if hasattr(lex, 'resource') else 1.0 
                            for lex in self.lexicon.values())
        avg_sigma = np.mean([lex.sigma for lex in self.lexicon.values()]) if self.lexicon else 0.5
        
        return {
            "step_counter": self.step_counter,
            "lexicon_size": len(self.lexicon),
            "connection_count": self.groupoid.total_connections(include_dormant=False),
            "dormant_connections": self.groupoid.total_connections(include_dormant=True) - 
                                   self.groupoid.total_connections(include_dormant=False),
            "total_resource": total_resource,
            "avg_sigma": avg_sigma,
            "current_threshold": self.threshold_mgr.get_threshold(),
            "decoder_mode": self.decoder.mode,
            "stats": self.stats,
            "uptime": time.time() - self.start_time
        }
    
    def save(self, filepath):
        """保存整个基因群状态"""
        state = {
            "config": self.config,
            "dimension": self.dimension,
            "step_counter": self.step_counter,
            "stats": self.stats,
            "lexicon": {name: lex.to_dict() for name, lex in self.lexicon.items()},
            "groupoid": self.groupoid.to_dict(),
            "word_to_lexion": self.encoder.word_to_lexion,
            "threshold_mgr": self.threshold_mgr.to_dict(),
            "trigger": self.trigger.to_dict(),
            "scheduler": {
                "step_counter": self.scheduler.step_counter,
                "last_pruning_step": self.scheduler.last_pruning_step,
                "last_entropy_step": self.scheduler.last_entropy_step,
                "last_chaos_step": self.scheduler.last_chaos_step
            },
            "chaos_regulator": {
                "alpha": self.evolution.alpha,
                "beta": self.evolution.beta,
                "gamma": self.evolution.gamma
            }
        }
        with open(filepath, 'wb') as f:
            pickle.dump(state, f)
    
    def load(self, filepath):
        """加载基因群状态"""
        with open(filepath, 'rb') as f:
            state = pickle.load(f)
        
        self.config = state["config"]
        self.dimension = state["dimension"]
        self.step_counter = state["step_counter"]
        self.stats = state["stats"]
        
        from symbiogen.layer_one.lexion import Lexion
        self.lexicon = {}
        for name, lex_data in state["lexicon"].items():
            self.lexicon[name] = Lexion.from_dict(lex_data, self.dimension)
        self.initializer._lexicon = self.lexicon
        
        from symbiogen.layer_two.groupoid import Groupoid
        self.groupoid = Groupoid.from_dict(state["groupoid"])
        self.groupoid.set_lexicon(self.lexicon)
        
        self.encoder.word_to_lexion = state["word_to_lexion"]
        self.decoder.lexicon = self.lexicon
        self.decoder.groupoid = self.groupoid
        
        self.threshold_mgr = ThresholdManager.from_dict(state["threshold_mgr"])
        self.trigger = AdaptationTrigger.from_dict(state["trigger"])
        
        sch = state["scheduler"]
        self.scheduler.step_counter = sch["step_counter"]
        self.scheduler.last_pruning_step = sch["last_pruning_step"]
        self.scheduler.last_entropy_step = sch["last_entropy_step"]
        self.scheduler.last_chaos_step = sch["last_chaos_step"]
        
        cr = state["chaos_regulator"]
        self.evolution.update_parameters(cr["alpha"], cr["beta"], cr["gamma"])
    
    def export_vital_signs(self):
        """导出生命体征（用于监控仪表盘）"""
        status = self.get_status()
        entropy_report = self.scheduler.entropy_monitor.update(
            self.lexicon, self.groupoid, 
            np.mean(self.scheduler.dissonance_buffer) if self.scheduler.dissonance_buffer else 0.0
        )
        return {
            "step": status["step_counter"],
            "lexicon_size": status["lexicon_size"],
            "active_connections": status["connection_count"],
            "dormant_connections": status["dormant_connections"],
            "avg_sigma": status["avg_sigma"],
            "threshold": status["current_threshold"],
            "info_entropy": entropy_report["info_entropy"],
            "structural_entropy": entropy_report["structural_entropy"],
            "total_entropy_change": entropy_report["total_entropy_change"],
            "in_chaos_edge": self.scheduler.chaos_regulator.is_in_chaos_edge(
                entropy_report["info_entropy"], status["avg_sigma"]
            ),
            "adaptation_count": status["stats"]["total_adaptations"],
            "uptime_hours": status["uptime"] / 3600.0
        }