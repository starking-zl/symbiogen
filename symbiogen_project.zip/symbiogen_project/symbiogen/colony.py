import os
import time
import uuid
import copy
import numpy as np
from datetime import datetime
from symbiogen.field import CurvatureField
from symbiogen.scheduling.scheduler import Scheduler
from symbiogen.encoding.text_encoder import TextEncoder
from symbiogen.utils.metrics import get_vital_signs


class SymbiogenColony:
    """共生基因群主类 —— 具备出芽生殖与跨世代进化能力"""

    def __init__(self, dimension=256, config=None, parent_id=None, generation=0):
        self.dimension = dimension
        self.config = config or {}

        # 谱系属性
        self.colony_id = str(uuid.uuid4())[:8]
        self.parent_id = parent_id
        self.generation = generation
        self.birth_time = datetime.now().isoformat()
        self.budding_history = []
        self.fitness_score = 0.0
        self.fitness_history = []

        # 核心组件
        self.field = CurvatureField(dimension)
        self.encoder = TextEncoder(dimension)
        self.scheduler = Scheduler(self.field, self.config.get("layers"))

        # 状态
        self.step_counter = 0
        self.vital_signs_history = []
        self.created_at = datetime.now().isoformat()

        # 初始化：白噪声粒子
        initial_particles = self.config.get("initial_particles", 100)
        for _ in range(initial_particles):
            self.field.add_particle()

        # 随机初始化一些连接
        self._init_random_synapses()

    def _init_random_synapses(self, connection_prob=0.05):
        """随机初始化连接"""
        import random
        particle_ids = list(self.field.particles.keys())
        for pid in particle_ids:
            for other_id in particle_ids:
                if pid != other_id and random.random() < connection_prob:
                    self.field.add_synapse(pid, other_id)

    def observe(self, text):
        """观察一条文本消息"""
        input_vector = self.encoder.encode(text)
        self.scheduler.etching_layer.enqueue(input_vector)
        self.scheduler.run_full_cycle()
        self.step_counter += 1
        if self.step_counter % 100 == 0:
            self._log_vital_signs()

    def observe_batch(self, texts):
        """批量观察多条消息"""
        for text in texts:
            self.observe(text)

    def _log_vital_signs(self):
        """记录生命体征"""
        signs = get_vital_signs(self.field)
        signs["timestamp"] = datetime.now().isoformat()
        signs["step"] = self.step_counter
        self.vital_signs_history.append(signs)

    def get_status(self):
        """获取当前状态"""
        return {
            "step_counter": self.step_counter,
            "created_at": self.created_at,
            "colony_id": self.colony_id,
            "parent_id": self.parent_id,
            "generation": self.generation,
            "fitness_score": self.fitness_score,
            "field_summary": self.field.get_field_summary(),
            "latest_vital_signs": self.vital_signs_history[-1] if self.vital_signs_history else None
        }

    def save(self, filepath):
        """保存完整状态"""
        self.field.save(filepath)

    def load(self, filepath):
        """加载状态"""
        self.field.load(filepath)

    # ========== 进化相关方法 ==========

    def bud(self, mutation_rate=0.01):
        """
        出芽生殖：生成一个继承当前蓝图并发生突变的新基因群个体。

        参数:
            mutation_rate: 蓝图变异率 (0.0 ~ 1.0)

        返回:
            SymbiogenColony: 芽体实例
        """
        # 1. 创建芽体配置（芽体从较少粒子开始）
        bud_config = copy.deepcopy(self.config)
        bud_config["initial_particles"] = max(20, bud_config.get("initial_particles", 100) // 2)

        # 2. 创建芽体实例
        bud = SymbiogenColony(
            dimension=self.dimension,
            config=bud_config,
            parent_id=self.colony_id,
            generation=self.generation + 1
        )

        # 3. 继承并变异蓝图场（拉马克式遗传）
        bud.field.blueprint = copy.deepcopy(self.field.blueprint)
        self._mutate_blueprint(bud.field.blueprint, mutation_rate)

        # 4. 继承母体的部分稳定粒子作为先天结构
        self._inherit_stable_particles(bud, count=min(20, len(self.field.particles) // 10))

        # 5. 记录出芽事件
        self.budding_history.append({
            "time": datetime.now().isoformat(),
            "bud_id": bud.colony_id,
            "mutation_rate": mutation_rate
        })

        return bud

    def _mutate_blueprint(self, blueprint, rate):
        """
        对蓝图场施加随机突变。

        突变类型：
        - 锚点坐标微扰
        - 目标曲率微调
        - 锚点强度变化
        - 低概率新增/删除锚点
        """
        import random

        for anchor in blueprint.anchors:
            if random.random() < rate:
                noise = np.random.randn(self.dimension) * 0.05
                anchor["coordinate"] = anchor["coordinate"] + noise
            if random.random() < rate:
                anchor["target_curvature"] += np.random.randn() * 0.1
            if random.random() < rate:
                anchor["strength"] *= (1 + np.random.randn() * 0.1)
                anchor["strength"] = max(0.01, anchor["strength"])

        # 低概率新增锚点
        if random.random() < rate * 0.5 and len(blueprint.anchors) < 100:
            new_coord = np.random.randn(self.dimension) * 0.1
            new_curv = np.random.randn() * 0.1
            blueprint.add_anchor(new_coord, new_curv, strength=0.5)

        # 低概率删除弱锚点
        if random.random() < rate * 0.3:
            blueprint.anchors = [a for a in blueprint.anchors if a["strength"] > 0.1]

    def _inherit_stable_particles(self, bud, count):
        """
        继承母体中最稳定的若干粒子到芽体中，作为先天结构。
        """
        if len(self.field.particles) == 0:
            return

        candidates = []
        for pid, p in self.field.particles.items():
            score = p.resource * (1.0 / (1.0 + p.activation_var)) * (p.age / 100.0 + 0.1)
            candidates.append((pid, score))

        candidates.sort(key=lambda x: x[1], reverse=True)
        selected = candidates[:count]

        for pid, _ in selected:
            p = self.field.particles[pid]
            new_id = bud.field.add_particle(p.coordinate.copy())
            bud.field.particles[new_id].curvature = p.curvature
            bud.field.particles[new_id].resource = p.resource * 0.5
            bud.field.particles[new_id].particle_type = p.particle_type

    def evaluate_fitness(self):
        """
        评估当前个体的环境适应度。
        适应度由多个生命体征加权计算得出。
        """
        from symbiogen.utils.metrics import compute_fitness
        signs = get_vital_signs(self.field)
        self.fitness_score = compute_fitness(signs)
        self.fitness_history.append({
            "step": self.step_counter,
            "fitness": self.fitness_score,
            "timestamp": datetime.now().isoformat()
        })
        return self.fitness_score

    def evolve_step(self, environment_inputs, generations=1, survival_ratio=0.3):
        """
        执行一代或多代进化：从当前个体出芽产生多个子代，用环境输入喂养，选择最优者。

        参数:
            environment_inputs: 用于评估的环境消息列表
            generations: 进化代数
            survival_ratio: 每代存活比例

        返回:
            SymbiogenColony: 最终优胜个体
        """
        from symbiogen.evolution.selector import select_best
        from symbiogen.evolution.lineage import LineageTracker

        tracker = LineageTracker()
        tracker.add_individual(self)

        current_best = self
        for gen in range(generations):
            # 1. 出芽产生候选后代
            offspring = []
            num_offspring = max(3, int(1.0 / survival_ratio))
            for _ in range(num_offspring):
                child = current_best.bud(mutation_rate=0.02)
                for msg in environment_inputs:
                    child.observe(msg)
                child.evaluate_fitness()
                offspring.append(child)
                tracker.add_individual(child, parent_id=current_best.colony_id)

            # 2. 选择适应度最高的个体
            current_best = select_best(offspring, survival_ratio)

            # 3. 记录世代最优
            tracker.record_generation_best(gen, current_best.colony_id, current_best.fitness_score)

        return current_best

    def get_lineage(self):
        """获取谱系信息"""
        return {
            "colony_id": self.colony_id,
            "parent_id": self.parent_id,
            "generation": self.generation,
            "birth_time": self.birth_time,
            "age_steps": self.step_counter,
            "fitness_score": self.fitness_score,
            "budding_count": len(self.budding_history),
            "vital_signs": self.vital_signs_history[-1] if self.vital_signs_history else None
        }

    def run_demo(self, texts, verbose=True):
        """演示运行"""
        for i, text in enumerate(texts):
            self.observe(text)
            if verbose and i % 10 == 0:
                summary = self.field.get_field_summary()
                print(f"Step {self.step_counter}: particles={summary['particle_count']}, "
                      f"resource={summary['total_resource']:.2f}")