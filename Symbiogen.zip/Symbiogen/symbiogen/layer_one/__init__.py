"""
第一层：词元概率云层

本层是共生基因群的动态核心，负责：
- 维护每个词元的离散概率向量 (256维)
- 执行自由演化 (扩散项 + 自指势能项)
- 响应环境输入 (贝叶斯坍缩)
- 管理离散度呼吸 (确认收缩，否定/沉默扩张)

本层依赖第零层提供的类型系统和语义原子锚点。
"""

from .lexion import Lexion
from .evolution import FreeEvolution
from .collapse import BayesianCollapse
from .breathing import DiscreteBreathing
from .init import LexionInitializer

__all__ = [
    "Lexion",
    "FreeEvolution",
    "BayesianCollapse",
    "DiscreteBreathing",
    "LexionInitializer"
]