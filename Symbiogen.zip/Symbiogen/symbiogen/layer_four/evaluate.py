"""
变异评估器

评估试探性变异是否“成功”：
- 对于新词元：检查是否能降低失谐度
- 对于新连接：检查组合后是否产生有意义的输出
- 对于连接调整：检查是否提高了成功率
"""

import numpy as np

class VariationEvaluator:
    """变异评估引擎"""
    
    def __init__(self, success_threshold=0.3, evaluation_window=10):
        """
        参数:
            success_threshold: 成功判定的置信度阈值
            evaluation_window: 评估所需的观察窗口大小
        """
        self.success_threshold = success_threshold
        self.evaluation_window = evaluation_window
        
    def evaluate(self, variation, lexicon, groupoid, dissonance_calculator, 
                 evidence_vector=None, original_dissonance=None):
        """
        评估单个变异的成功程度
        
        参数:
            variation: 变异字典
            lexicon: 词元词典
            groupoid: 群胚管理器
            dissonance_calculator: 失谐度计算器
            evidence_vector: 触发顺应的环境证据
            original_dissonance: 变异前的失谐度
        
        返回:
            score: 成功分数 (0~1)
            should_keep: 是否应保留此变异
        """
        var_type = variation.get("type")
        
        if var_type == "new_lexion":
            return self._evaluate_new_lexion(variation, lexicon, evidence_vector, 
                                             original_dissonance)
        elif var_type == "new_connection":
            return self._evaluate_new_connection(variation, lexicon, groupoid)
        elif var_type == "adjust_connection":
            return self._evaluate_connection_adjustment(variation, lexicon, groupoid)
        else:
            return 0.0, False
    
    def _evaluate_new_lexion(self, variation, lexicon, evidence_vector, original_dissonance):
        """评估新词元变异"""
        if evidence_vector is None:
            return 0.3, False  # 无证据时无法评估
        
        new_p = variation["new_p"]
        
        # 计算新词元与证据向量的相似度
        similarity = np.dot(evidence_vector, new_p) / (np.linalg.norm(evidence_vector) * 
                                                       np.linalg.norm(new_p) + 1e-8)
        
        # 成功分数：相似度越高越好
        score = similarity
        
        # 如果原始失谐度已知，检查是否有改善
        if original_dissonance is not None:
            # 简化：新词元的高相似度意味着失谐度会降低
            improvement = max(0, similarity - 0.5) * 2
            score = (score + improvement) / 2
        
        should_keep = score > self.success_threshold
        return score, should_keep
    
    def _evaluate_new_connection(self, variation, lexicon, groupoid):
        """评估新连接变异"""
        source_name = variation["source_name"]
        target_name = variation["target_name"]
        
        if source_name not in lexicon or target_name not in lexicon:
            return 0.0, False
        
        source_lex = lexicon[source_name]
        target_lex = lexicon[target_name]
        
        # 评估两个词元的潜在组合价值
        # 1. 概率云相似度
        sim = np.dot(source_lex.p, target_lex.p) / (np.linalg.norm(source_lex.p) * 
                                                     np.linalg.norm(target_lex.p) + 1e-8)
        
        # 2. 两者的确定性（离散度越低，连接越有价值）
        certainty = (1 - source_lex.sigma) * (1 - target_lex.sigma)
        
        # 综合分数
        score = (sim * 0.6 + certainty * 0.4)
        
        should_keep = score > self.success_threshold
        return score, should_keep
    
    def _evaluate_connection_adjustment(self, variation, lexicon, groupoid):
        """评估连接调整变异"""
        conn = variation.get("connection")
        if conn is None:
            return 0.0, False
        
        # 获取连接的历史成功率
        success_rate = conn.get_success_rate()
        
        # 如果调整方向是增强连接（delta_mu > 0）且历史成功率尚可
        delta_mu = variation.get("delta_mu", 0)
        if delta_mu > 0:
            score = success_rate * 0.8 + 0.2  # 鼓励增强已有成功连接
        else:
            score = success_rate * 0.6  # 减弱连接需谨慎
        
        should_keep = score > self.success_threshold * 0.8  # 调整的阈值稍低
        return score, should_keep
    
    def evaluate_batch(self, variations, lexicon, groupoid, dissonance_calculator,
                       evidence_vector=None, original_dissonance=None):
        """
        批量评估变异，返回按分数排序的结果
        """
        results = []
        for var in variations:
            score, keep = self.evaluate(var, lexicon, groupoid, dissonance_calculator,
                                        evidence_vector, original_dissonance)
            results.append({
                "variation": var,
                "score": score,
                "should_keep": keep
            })
        
        # 按分数降序排序
        results.sort(key=lambda x: x["score"], reverse=True)
        return results