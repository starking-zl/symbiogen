"""持久化接口（已集成在 colony 中，此处为转发）"""
def save_colony(colony, filepath):
    colony.save(filepath)

def load_colony(filepath):
    from symbiogen import SymbiogenColony
    colony = SymbiogenColony()
    colony.load(filepath)
    return colony