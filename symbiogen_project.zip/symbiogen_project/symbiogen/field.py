import pickle
import numpy as np
from symbiogen.data.particle import Particle
from symbiogen.data.synapse import Synapse
from symbiogen.data.blueprint import Blueprint

class CurvatureField:
    """高维曲率场 —— 共生基因群的物理载体"""
    
    def __init__(self, dimension=256):
        self.dimension = dimension
        self.particles = {}  # {particle_id: Particle}
        self.synapses = []   # [Synapse, ...]
        self.blueprint = Blueprint(dimension)
        
    def add_particle(self, coordinate=None):
        """添加新粒子"""
        if coordinate is None:
            coordinate = np.random.randn(self.dimension) * 0.01
        p = Particle(coordinate)
        self.particles[p.particle_id] = p
        return p.particle_id
    
    def remove_particle(self, particle_id):
        """移除粒子及其所有关联连接"""
        if particle_id in self.particles:
            del self.particles[particle_id]
        self.synapses = [s for s in self.synapses 
                         if s.pre_id != particle_id and s.post_id != particle_id]
    
    def add_synapse(self, pre_id, post_id, weight=None):
        """添加连接"""
        if pre_id in self.particles and post_id in self.particles:
            s = Synapse(pre_id, post_id, weight)
            self.synapses.append(s)
            return s
        return None
    
    def get_neighbors(self, particle_id):
        """获取粒子的所有邻居（出向连接的目标）"""
        neighbors = []
        for s in self.synapses:
            if s.pre_id == particle_id:
                neighbors.append(s.post_id)
        return neighbors
    
    def get_incoming(self, particle_id):
        """获取粒子的所有入向连接"""
        incoming = []
        for s in self.synapses:
            if s.post_id == particle_id:
                incoming.append(s.pre_id)
        return incoming
    
    def get_synapse(self, pre_id, post_id):
        """获取指定连接"""
        for s in self.synapses:
            if s.pre_id == pre_id and s.post_id == post_id:
                return s
        return None
    
    def save(self, filepath):
        """保存场状态"""
        state = {
            "dimension": self.dimension,
            "particles": {pid: p.to_dict() for pid, p in self.particles.items()},
            "synapses": [s.to_dict() for s in self.synapses],
            "blueprint": self.blueprint.to_dict()
        }
        with open(filepath, 'wb') as f:
            pickle.dump(state, f)
    
    def load(self, filepath):
        """加载场状态"""
        with open(filepath, 'rb') as f:
            state = pickle.load(f)
        
        self.dimension = state["dimension"]
        self.particles = {}
        for pid, p_data in state["particles"].items():
            self.particles[pid] = Particle.from_dict(p_data)
        
        self.synapses = [Synapse.from_dict(s_data) for s_data in state["synapses"]]
        self.blueprint = Blueprint.from_dict(state["blueprint"])
    
    def get_field_summary(self):
        """获取场的基本统计"""
        total_resource = sum(p.resource for p in self.particles.values())
        avg_curvature = np.mean([p.curvature for p in self.particles.values()]) if self.particles else 0
        
        return {
            "particle_count": len(self.particles),
            "synapse_count": len(self.synapses),
            "total_resource": total_resource,
            "avg_curvature": avg_curvature,
            "blueprint_anchors": len(self.blueprint.anchors)
        }