#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""v1.0 跨世代进化功能测试"""

import sys
sys.path.insert(0, '/storage/emulated/0/symbiogen')

from symbiogen.colony import SymbiogenColony


def test_bud_with_mutation():
    """测试出芽与蓝图突变"""
    print("测试 1: 出芽生殖与蓝图突变")
    mom = SymbiogenColony(dimension=32, config={"initial_particles": 50})

    mom_anchors = len(mom.field.blueprint.anchors)
    print(f"  母体蓝图锚点数: {mom_anchors}")

    baby = mom.bud(mutation_rate=0.1)
    baby_anchors = len(baby.field.blueprint.anchors)
    print(f"  子代蓝图锚点数: {baby_anchors}")

    assert baby.parent_id == mom.colony_id
    assert baby.generation == mom.generation + 1
    print("  谱系继承测试通过 ✓")
    return True


def test_fitness_evaluation():
    """测试适应度评估"""
    print("\n测试 2: 适应度评估")
    colony = SymbiogenColony(dimension=32, config={"initial_particles": 30})

    messages = ["你好", "共生基因群", "曲率场方程", "演化测试"]
    for msg in messages:
        colony.observe(msg)

    fitness = colony.evaluate_fitness()
    print(f"  适应度分数: {fitness:.4f}")
    assert 0.0 <= fitness <= 1.0
    print("  适应度评估测试通过 ✓")
    return True


def test_simple_evolution():
    """测试简单进化循环"""
    print("\n测试 3: 进化循环（1代）")
    ancestor = SymbiogenColony(dimension=32, config={"initial_particles": 40})

    env_messages = [
        "曲率场是最优美的设计",
        "根茎、珊瑚、菌丝体",
        "共生基因群在演化"
    ]

    evolved = ancestor.evolve_step(
        environment_inputs=env_messages,
        generations=1,
        survival_ratio=0.5
    )

    print(f"  祖代适应度: {ancestor.fitness_score:.4f}")
    print(f"  进化后适应度: {evolved.fitness_score:.4f}")
    print(f"  世代数: {evolved.generation}")

    assert evolved.generation > ancestor.generation
    print("  进化循环测试通过 ✓")
    return True


def test_lineage_tracker():
    """测试谱系追踪"""
    print("\n测试 4: 谱系追踪")
    from symbiogen.evolution import LineageTracker

    tracker = LineageTracker()
    mom = SymbiogenColony(dimension=16, config={"initial_particles": 20})
    tracker.add_individual(mom)

    baby = mom.bud(mutation_rate=0.02)
    tracker.add_individual(baby, parent_id=mom.colony_id)

    grandbaby = baby.bud(mutation_rate=0.02)
    tracker.add_individual(grandbaby, parent_id=baby.colony_id)

    stats = tracker.get_statistics()
    print(f"  总个体数: {stats['total_individuals']}")
    assert stats['total_individuals'] == 3
    print("  谱系追踪测试通过 ✓")
    return True


def main():
    print("=" * 50)
    print("共生基因群 v1.0 - 跨世代进化测试")
    print("=" * 50)

    try:
        test_bud_with_mutation()
        test_fitness_evaluation()
        test_simple_evolution()
        test_lineage_tracker()
        print("\n" + "=" * 50)
        print("✓ 所有进化功能测试通过！")
        print("=" * 50)
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()