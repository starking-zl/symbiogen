# Symbiogen · Symbiotic Gene Colony Project Structure

This document explains the directory organization and purpose of each file in Symbiogen v1.0.0-alpha, helping developers quickly locate code.

---

## Root Directory

- **LICENSE**: Full text of Apache License 2.0.
- **README.md**: Project homepage containing introduction, quick start, features, usage, etc.
- **requirements.txt**: Python dependency list; currently only `numpy>=1.21.0`.
- **setup.py**: Optional installation script for installing Symbiogen as a Python package.
- **.gitignore**: Git ignore rules, excluding runtime data, caches, virtual environments, etc.

---

## symbiogen/ —— Core Python Package

All core code resides within this directory.

### symbiogen/__init__.py
Package initialization file, exports main class `SymbiogenColony`, `CurvatureField`, and evolution components `LineageTracker`, `select_best`, and defines version number.

### symbiogen/colony.py
**Implementation of main class `SymbiogenColony`.**
Contains core methods for individual evolution, budding reproduction (`bud`), blueprint mutation (`_mutate_blueprint`), fitness evaluation (`evaluate_fitness`), multi-generation evolution (`evolve_step`), and lineage information (`get_lineage`).

### symbiogen/field.py
**Implementation of curvature field container `CurvatureField`.**
Manages particle set, synapse set, and blueprint field. Provides methods for adding/removing particles and synapses, save/load, and field statistics.

---

### symbiogen/data/ —— Data Structures

- **particle.py**: Defines `Particle` class (fundamental unit on high-dimensional manifold).
- **synapse.py**: Defines `Synapse` class (directed connection with STDP timing information).
- **blueprint.py**: Defines `Blueprint` class (blueprint field R₀, heritable genome).
- **skeleton.py**: Reserved for skeleton extraction.
- **polarity.py**: Reserved for polarity axis.

---

### symbiogen/layers/ —— Five-Layer Circular Architecture

- **base.py**: Abstract base class `Layer`.
- **etching.py**: `EtchingLayer`, transforms input into J⊗J etching stress.
- **diffusion.py**: `DiffusionLayer`, performs curvature diffusion ∇²R.
- **regression.py**: `RegressionLayer`, pulls curvature back toward blueprint and periodically updates blueprint.
- **fluctuation.py**: `FluctuationLayer`, injects stochastic noise ξ.
- **time_layer.py**: `TimeLayer`, manages lifecycle (aging, pruning, growth).

---

### symbiogen/primitives/ —— Field Operation Primitives

Low-level functions that directly manipulate `CurvatureField`.

- **etch.py**: `etch(field, input_vector, ...)` implements information etching.
- **diffuse.py**: `diffuse(field, ...)` implements curvature and resource diffusion.
- **regress.py**: `regress(field, ...)` implements regression toward blueprint.
- **fluctuate.py**: `fluctuate(field, ...)` implements stochastic fluctuation.
- **lifecycle.py**: Lifecycle management functions: `apply_resource_decay`, `prune_low_resource_particles`, `grow_new_particles`, `age_particles`.
- **query.py**: Reserved for field queries.

---

### symbiogen/evolution/ —— Cross-Generation Evolution

- **selector.py**: `select_best`, `select_top_k`, selects individuals based on fitness.
- **lineage.py**: `LineageTracker` class, records lineage, generation best, statistics, and persistence.

---

### symbiogen/encoding/ —— Input Encoding

- **text_encoder.py**: `TextEncoder` class, converts text to fixed-dimension information vector.
- **image_encoder.py**: Reserved for image encoding (v2.0).
- **audio_encoder.py**: Reserved for audio encoding (v2.0).
- **video_encoder.py**: Reserved for video encoding (v2.0).
- **zooxanthellae.py**: Reserved for external knowledge injection.

---

### symbiogen/interfaces/ —— External Interfaces

- **input_adapter.py**: Reserved, base class for input adapters.
- **output_adapter.py**: Reserved, base class for output adapters (disabled in mute mode).
- **persistence.py**: Provides persistence functions: `save_colony`, `load_colony`, `save_blueprint`, `load_blueprint`.
- **observation.py**: Reserved for observation dashboard interface.

---

### symbiogen/scheduling/ —— Temporal Scheduling

- **phase_clock.py**: `PhaseClock` class, manages 0.0～1.0 phase cycle.
- **scheduler.py**: `Scheduler` class, triggers corresponding layers based on phase, coordinates complete evolution cycle.

---

### symbiogen/utils/ —— Utility Functions

- **math_utils.py**: Distance computation, Laplacian operator, vector normalization, cosine similarity.
- **metrics.py**: Vital sign calculations (total resource, particle count, module count, curvature variance, blueprint fidelity, novelty responsiveness) and `compute_fitness` for fitness evaluation.
- **validators.py**: Reserved for configuration validation.
- **logging_utils.py**: Reserved for logging helpers.

---

### symbiogen/sandbox/ —— Security Sandbox

Reserved directory for future implementation of capability whitelist, kill switch, and other security mechanisms.

---

### symbiogen/metaphors/ —— Ten Metaphor Implementations

Reserved directory, planned for v2.0 to inject metaphors (Rhizome, Coral, Mycelium, etc.) as independent modules. All files currently empty.

---

## adapters/ —— Platform Adapters

Used for connecting to external message sources. **Contains no runnable code**, serves only as design reference.

- **terminal/stdin_adapter.py**: Reserved, standard input adapter.
- **android/notification_listener.py**: Reserved, Android notification listener adapter (design reference).
- **android/termux_runner.py**: Reserved, Termux environment launcher.
- **mock/mock_chatroom.py**: Reserved, mock chatroom for testing.

---

## tests/ —— Tests

- **test_batch3.py**: Batch 3 tests, validating five-layer architecture and scheduler.
- **test_evolution.py**: Complete evolution functionality tests (budding, mutation, fitness, lineage).
- **unit/**: Reserved for unit tests.
- **integration/**: Reserved for integration tests.
- **fixtures/**: Test data (e.g., `sample_messages.json`).

---

## scripts/ —— Auxiliary Scripts

- **interactive.py**: Interactive dialogue window. Supports feeding text, viewing dashboard, save/load state, temporary question echo.
- **init_colony.py**: Reserved for initializing a new colony.
- **run_demo.py**: Reserved, demonstration script.
- **visualize_skeleton.py**: Reserved for skeleton visualization.
- **export_blueprint.py**: Reserved for blueprint export.

---

## docs/ —— Documentation

- **design/Symbiogen_Complete_Design_v1.0_zh.md**: Complete Chinese design specification.
- **design/Symbiogen_Complete_Design_v1.0_en.md**: Complete English design specification.
- **api/**: Reserved for API documentation.
- **diagrams/**: Reserved for architecture diagrams.

---

## data/ —— Runtime Data

Ignored by `.gitignore`, stores files generated during actual operation:

- **colonies/**: Saved `.sym` individual state files.
- **blueprints/**: Exported `.blueprint` blueprint seeds.
- **logs/**: Runtime logs.

---

## config/ —— Configuration Files

- **default.yaml**: Reserved for default parameter configuration.
- **logging.yaml**: Reserved for logging configuration.
- **schemas/config_schema.yaml**: Reserved for configuration validation schema.

---

*Document Version: v1.0.0-alpha*