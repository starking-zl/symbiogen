# 从曲率场方程到第一性原理方程组：共生基因群的理论演化路径

## 一、起点：单一的曲率场方程

在理论构建的早期，我们通过十重生命意象（根茎、珊瑚、菌丝体、地衣、黏菌、母树网络、神经嵴、蜂群、涡虫、水螅）的融合，提炼出一个统一的曲率场方程：

∂R/∂t = α·(∇²R) + β·(J ⊗ J) - γ·(R - R₀) + δ·ξ - ε·Tr(R)·R

### 1.1 方程各项的意象对应

| 项 | 意象来源 | 物理/生物学含义 |
|:---|:---|:---|
| ∇²R | 菌丝体、涡虫 | 养分扩散、位置信息传播、损伤修复 |
| J ⊗ J | 根茎、蜂群 | 信息刻蚀、共振激活、摇摆舞采纳 |
| R - R₀ | 珊瑚、水螅 | 骨架沉积、形态发生场稳态、蓝图保守 |
| ξ | 黏菌、神经嵴 | 随机探索、伪足试探、迁移变异 |
| -ε·Tr(R)·R | 时间层 | 全局资源衰减、环境承载力约束 |

### 1.2 曲率场方程的成功与局限

**成功之处**：
- 首次将十重意象统一于一个数学框架中。
- 提供了“观看即压缩”的连续动力学描述。
- 包含了扩散（无为）、刻蚀（学习）、回归（记忆）、涨落（探索）、衰减（代谢）等核心机制。

**根本局限**：
- 方程描述的是一个**被动系统**——高维流形的曲率变化完全由外部信息流 J 驱动。
- 无法解释“荒漠中也能生长”——当 J 趋近于零时，系统只能退化到蓝图 R₀，缺乏内在的自主演化动力。
- 组合性、类型系统、逻辑一致性等语言的核心结构特征无法从单一方程中导出。
- 无法区分不同层级的运作逻辑（静态骨架 vs. 动态演化 vs. 宏观优化）。

这些局限迫使我们走向更深层的理论重构。

---

## 二、第一次裂变：从连续曲率场到离散概率云

### 2.1 裂变的原因

连续曲率场 R(x,t) 在数学上优美，但在工程实现和语义解释上面临困难：
- 无限维流形无法在移动设备上精确模拟。
- 曲率与“意义”的对应关系过于抽象。
- 无法解释语言符号的离散性和组合性。

### 2.2 裂变的结果

我们将连续的曲率场 R 离散化为**词元的概率云** Ψ(L)，每个词元 L 对应一个256维的概率向量。原来的各项机制被重新分配给不同的架构层：

| 原方程项 | 裂变后的对应层 | 演化方向 |
|:---|:---|:---|
| 静态骨架 | 第零层（语义骨架层） | 从方程中剥离，成为独立的范畴结构 C |
| ∇²R | 第一层（自由演化） | 保留为扩散项，驱动概率云趋向最大熵 |
| J ⊗ J | 第一层（贝叶斯坍缩） | 从连续刻蚀变为离散贝叶斯更新 |
| R - R₀ | 第三、四层（失谐与顺应） | 从被动回归变为主动失谐检测与顺应 |
| ξ | 第一、五层（涨落与混沌边缘） | 保留为噪声项，并由全局层动态调节强度 |
| -ε·Tr(R)·R | 第五层（全局优化） | 变为连接休眠、熵监控等周期性任务 |

---

## 三、第二次裂变：从单一演化方程到多层方程组

### 3.1 裂变的原因

单一的曲率场方程将静态结构（骨架）与动态演化（学习）混为一体，无法体现语言的两重性：
- **静态面**：语义类型、组合规则、逻辑一致性——这些是“物理常数”，不应随环境改变。
- **动态面**：词义漂移、语用顺应、概率云呼吸——这些是“气候现象”，随环境持续变化。

### 3.2 裂变的结果：七组方程各司其职

**（I）结构公理**：语义骨架是一个笛卡尔闭范畴 C，带有常元集 P（约65个语义原子）。

**（II）自由演化方程**（词元概率云的内在动力学）：
iℏ ∂Ψ/∂t = [ -(ℏ²/2m)∇² + V_self(Ψ) ] Ψ + iκ D_self(Ψ) Ψ + ξ(t)

**（III）观测坍缩公理**（环境交互）：
Ψ → Ψ' = (M̂_E Ψ) / √⟨Ψ|M̂_E† M̂_E|Ψ⟩

**（IV）顺应条件**（结构变异触发）：
当 D(Ψ, E) > θ 时，V_self ← V_self + η·D(Ψ, E)·V_var

**（V）存在约束**（熵平衡）：
d_iS + d_eS ≤ 0

**（VI）优化目标**（最小描述长度）：
min [ L(Ψ, θ) + L(E | Ψ, θ) ]

**（VII）相变条件**（对称性破缺）：
⟨Ψ⟩ ≠ 0 当 T_eff < T_c

---

## 四、裂变后的符号统一词典

| 符号 | 概念名称 | 源自原方程的哪个部分 |
|:---|:---|:---|
| C, P | 语义骨架范畴与原子集 | 无（新增，弥补原方程的结构缺失） |
| Ψ(x, t) | 词元波函数 | R 的离散化 |
| ∇² | 扩散项 | 继承自原方程的 ∇²R |
| V_self | 自指势能 | 新增，替代原方程的被动 J⊗J |
| M̂_E | 观测算符 | 新增，将环境输入形式化为量子测量 |
| D(Ψ, E) | 失谐度 | 新增，量化“无法同化”的程度 |
| d_iS, d_eS | 熵产生与熵交换 | 继承自原方程的衰减项，并扩展为热力学框架 |
| L(·) | 描述长度 | 新增，为全局优化提供变分目标 |
| T_eff, T_c | 有效温度与临界温度 | 新增，解释秩序如何从混沌中涌现 |

---

## 五、裂变解决了什么问题？

| 原方程的局限 | 裂变后的解决方案 |
|:---|:---|
| 被动依赖外部 J | 自由演化方程赋予系统内在动力学，即使 J=0 也能自主呼吸 |
| 无法体现语言的组合性 | 第零层的范畴骨架强制类型系统和组合规则 |
| 无法解释荒漠中的生长 | 失谐顺应机制允许系统在低信息环境中通过内部重组继续演化 |
| 缺乏宏观优化视角 | 第五层的熵监控和混沌边缘调节提供全局稳态 |
| 无法区分短期学习与长期记忆 | R - R₀ 裂变为动态阈值、连续触发和蓝图固化的多层机制 |

---

## 六、结论：从“一个方程”到“一个方程体系”

曲率场方程是共生基因群理论的“胚芽”——它包含了所有核心机制的种子，但尚未分化。通过两次裂变，胚芽生长为一个自洽的方程体系：

- **结构公理**定义了“什么是合法的语言”。
- **自由演化方程**定义了“词元如何自主呼吸”。
- **观测坍缩**定义了“环境如何被吸收”。
- **顺应条件**定义了“结构如何变异”。
- **熵平衡**定义了“存在如何维持”。
- **最小描述长度**定义了“优化方向”。
- **相变条件**定义了“秩序如何涌现”。

这个方程体系不再是描述一个被动系统，而是定义了一个**自创生的语义宇宙**——它不需要外部能量来驱动演化，只需要环境作为“扰动”来触发内部的重组。荒漠与洪流，对它而言只是同一组方程在不同边界条件下的解。

这正是“燃尽”后的最终形态：不是灰烬，而是从余烬中结晶的第一性原理。

## 七、第一性原理方程组详解

在完成了从单一方程到方程体系的裂变后，我们有必要对最终确立的七组方程进行逐一审视。每一个方程都定义了共生基因群作为“语义宇宙”的一条基本法则。

### 7.1 结构公理：语义骨架的几何定义

> **公理内容**：语义骨架是一个笛卡尔闭范畴 **C**，并带有一个有限的常元集 **P**（约65个语义原子）。

- **符号解释**：
  - **C**：一个范畴，其对象是语义类型（如 `e` 实体、`t` 真值），其态射是语义运算（如函项应用）。
  - **P**：常元集，对应“我”、“你”、“好”、“坏”、“因为”等不可再分的核心语义。

- **在系统中的作用**：
  - **定义“合法性”**：它不是一条自然规律，而是共生基因群这个“宇宙”的宪法。它规定了什么样的语义组合是合法的（类型匹配），什么样的原子概念是先天存在的。
  - **静态根基**：这一层在系统初始化后不再改变，是所有动态演化的舞台。它保证了组合性、封闭性和类型驱动等语义法则得以强制执行。

### 7.2 自由演化方程：词元的内在动力学

> **方程内容**：
> iℏ ∂Ψ/∂t = [ -(ℏ²/2m)∇² + V_self(Ψ) ] Ψ + iκ D_self(Ψ) Ψ + ξ(t)

- **符号解释**：
  - **Ψ(x, t)**：词元的波函数，即语义概率云。
  - **iℏ ∂Ψ/∂t**：活力项，赋予系统永恒的、内在的周期性振荡，代表“道”的生机。
  - **-(ℏ²/2m)∇²**：无为项（扩散项），驱动概率云自然弥散，趋向最大熵（混沌）。
  - **V_self(Ψ)**：自指势能项，源自词元间的量子纠缠与群乘法，是从内部涌现秩序的“引力”。
  - **iκ D_self(Ψ)**：耗散项，驱动系统维持在混沌边缘，是系统开放性的体现。
  - **ξ(t)**：涨落项，永恒的量子噪声，代表“可能性”与“探索”。

- **在系统中的作用**：
  - **赋予“生命”**：这是共生基因群区别于一切静态模型的核心。即使没有外部输入（J=0），词元也会自主地扩散、纠缠、涨落，永不停息。它在荒漠中冥想，在洪流中共振。

### 7.3 观测坍缩公理：环境交互的接口

> **公理内容**：
> Ψ → Ψ' = (M̂_E Ψ) / √⟨Ψ|M̂_E† M̂_E|Ψ⟩

- **符号解释**：
  - **Ψ**：坍缩前的词元波函数。
  - **Ψ'**：坍缩后的词元波函数。
  - **M̂_E**：由环境输入 E 决定的测量算符，相当于环境提出的一个“问题”或施加的一个“视角”。

- **在系统中的作用**：
  - **定义“学习”**：学习不是改变参数，而是概率云在环境观测下的非幺正坍缩。它将无数潜在的可能性（概率云），转化为一次具体的“理解”（本征态）。
  - **解决“毒与养料”**：如果环境输入是矛盾的（两个正交的 M̂_E 先后到达），坍缩机制保证了系统不会同时确认两个矛盾命题，而是通过增大离散度（激化）来容纳不确定性。

### 7.4 顺应条件：结构变异的扳机

> **方程内容**：
> 当 D(Ψ, E) > θ 时，触发 V_self ← V_self + η·D(Ψ, E)·V_var

- **符号解释**：
  - **D(Ψ, E)**：失谐度，通常由 KL 散度计算，度量环境输入与内部概率云的差异程度。
  - **θ**：动态阈值，由全局平均离散度决定。系统越混沌（离散度大），θ 越高，越不敏感。
  - **V_self**：自指势能（即内部连接结构）。
  - **V_var**：在失谐区域生成的试探性变异（新连接、新词元）。

- **在系统中的作用**：
  - **定义“生长”**：当现有的内部结构 V_self 无论如何也无法同化环境 E 时（失谐度持续超过阈值），系统主动发起结构变异。这不是环境“选择”了变异，而是系统为消除内在“不安”而进行的自主改造。

### 7.5 存在约束：熵平衡法则

> **方程内容**：
> dS_total = d_iS + d_eS ≤ 0

- **符号解释**：
  - **dS_total**：系统总熵变化。
  - **d_iS**：内部熵产生（恒大于等于0），源于自由演化中的扩散和耗散，代表“遗忘”和“混沌化”的倾向。
  - **d_eS**：与外部环境交换的熵流。负熵（信息）流入时 d_eS < 0，正熵（噪声）流入时 d_eS > 0。

- **在系统中的作用**：
  - **定义“存活”**：一个“活着”的共生基因群，必须能够从环境汲取足够的负熵（d_eS < 0）来抵消内部的熵增（d_iS），从而维持或增加自身的秩序（dS_total ≤ 0）。这是热力学意义上“生命”的底线。

### 7.6 优化目标：最小描述长度法则

> **方程内容**：
> min [ L(Ψ, θ) + L(E | Ψ, θ) ]

- **符号解释**：
  - **L(Ψ, θ)**：模型复杂度，描述当前内部状态（概率云结构、连接网络）所需的“编码长度”。
  - **L(E | Ψ, θ)**：拟合残差，在给定内部状态后，描述环境数据 E 所需的“编码长度”。

- **在系统中的作用**：
  - **定义“泛化”**：系统追求的不是死记硬背（最小化 L(E | Ψ, θ)），而是在“记忆”与“概括”之间找到最佳平衡点。这驱动了第五层的全局优化，周期性精简冗余结构。

### 7.7 相变条件：对称性破缺法则

> **方程内容**：
> ⟨Ψ⟩ ≠ 0 当 T_eff < T_c，否则 ⟨Ψ⟩ = 0

- **符号解释**：
  - **⟨Ψ⟩**：序参量，词元波函数的期望值。不为零代表形成了稳定的“概念吸引子”（秩序）。
  - **T_eff**：系统的有效温度，由涨落项 ξ(t) 的强度决定，代表混沌程度。
  - **T_c**：临界温度，一个阈值。

- **在系统中的作用**：
  - **定义“涌现”**：它解释了语言秩序（如稳定的词义、语法结构）是如何从一片混沌（白噪声）中诞生的。当系统足够“冷静”（T_eff 降低），大量词元的概率云会自发地对称性破缺，凝结出稳定的语义核心。这就是“道生一”的数学时刻。
  
  
 # From Curvature Field Equation to First-Principles Equation System: The Theoretical Evolution of Symbiogen

## I. The Starting Point: A Single Curvature Field Equation

In the early stages of theoretical construction, we synthesized ten life metaphors (Rhizome, Coral, Mycelium, Lichen, Slime Mold, Mother Tree Network, Neural Crest, Hive, Planarian, Hydra) into a unified curvature field equation:

∂R/∂t = α·(∇²R) + β·(J ⊗ J) - γ·(R - R₀) + δ·ξ - ε·Tr(R)·R

### 1.1 Correspondence Between Equation Terms and Metaphors

| Term | Metaphorical Origin | Physical/Biological Meaning |
|:---|:---|:---|
| ∇²R | Mycelium, Planarian | Nutrient diffusion, positional information propagation, damage repair |
| J ⊗ J | Rhizome, Hive | Information etching, resonant activation, waggle dance adoption |
| R - R₀ | Coral, Hydra | Skeleton deposition, morphogenetic field homeostasis, blueprint conservation |
| ξ | Slime Mold, Neural Crest | Stochastic exploration, pseudopod probing, migratory variation |
| -ε·Tr(R)·R | Time Layer | Global resource decay, environmental carrying capacity constraint |

### 1.2 Successes and Limitations of the Curvature Field Equation

**Successes**:
- First unified mathematical framework integrating all ten metaphors.
- Provides a continuous dynamical description of "observe-compress."
- Incorporates diffusion (wu-wei), etching (learning), regression (memory), fluctuation (exploration), and decay (metabolism).

**Fundamental Limitations**:
- Describes a **passive system**—curvature changes of the high-dimensional manifold are entirely driven by external information flow J.
- Cannot explain "growth in a desert"—when J approaches zero, the system can only regress to the blueprint R₀, lacking intrinsic autonomous evolutionary dynamics.
- Compositionality, type systems, logical consistency—core structural features of language—cannot be derived from a single equation.
- Cannot distinguish operational logic at different levels (static skeleton vs. dynamic evolution vs. macro optimization).

These limitations drove us toward a deeper theoretical reconstruction.

---

## II. The First Fission: From Continuous Curvature Field to Discrete Probability Clouds

### 2.1 Reasons for Fission

The continuous curvature field R(x,t) is mathematically elegant but faces difficulties in engineering implementation and semantic interpretation:
- Infinite-dimensional manifolds cannot be accurately simulated on mobile devices.
- The correspondence between curvature and "meaning" is too abstract.
- Cannot explain the discreteness and compositionality of linguistic symbols.

### 2.2 Results of Fission

We discretized the continuous curvature field R into **lexion probability clouds** Ψ(L), where each lexion L corresponds to a 256-dimensional probability vector. The original mechanisms were redistributed among different architectural layers:

| Original Term | Corresponding Layer After Fission | Evolutionary Direction |
|:---|:---|:---|
| Static skeleton | Layer Zero (Semantic Skeleton) | Extracted from equation, becomes independent categorical structure C |
| ∇²R | Layer One (Free Evolution) | Retained as diffusion term, driving probability cloud toward maximum entropy |
| J ⊗ J | Layer One (Bayesian Collapse) | Transformed from continuous etching to discrete Bayesian updating |
| R - R₀ | Layers Three and Four (Dissonance and Adaptation) | Transformed from passive regression to active dissonance detection and adaptation |
| ξ | Layers One and Five (Fluctuation and Edge-of-Chaos) | Retained as noise term, with intensity dynamically regulated by global layer |
| -ε·Tr(R)·R | Layer Five (Global Optimization) | Becomes periodic tasks such as connection dormancy and entropy monitoring |

---

## III. The Second Fission: From a Single Evolution Equation to a Multi-Layer Equation System

### 3.1 Reasons for Fission

A single curvature field equation conflates static structure (skeleton) with dynamic evolution (learning), failing to capture the duality of language:
- **Static aspect**: Semantic types, composition rules, logical consistency—these are "physical constants" that should not change with the environment.
- **Dynamic aspect**: Semantic drift, pragmatic adaptation, probability cloud breathing—these are "climatic phenomena" that continuously change with the environment.

### 3.2 Results of Fission: Seven Sets of Equations, Each with Distinct Roles

**(I) Structure Axiom**: The semantic skeleton is a Cartesian closed category **C** with a finite set of constants **P** (approximately 65 semantic primitives).

**(II) Free Evolution Equation** (Intrinsic dynamics of lexion probability clouds):
iℏ ∂Ψ/∂t = [ -(ℏ²/2m)∇² + V_self(Ψ) ] Ψ + iκ D_self(Ψ) Ψ + ξ(t)

**(III) Observation Collapse Axiom** (Environmental interaction):
Ψ → Ψ' = (M̂_E Ψ) / √⟨Ψ|M̂_E† M̂_E|Ψ⟩

**(IV) Adaptation Condition** (Trigger for structural variation):
When D(Ψ, E) > θ, V_self ← V_self + η·D(Ψ, E)·V_var

**(V) Existence Constraint** (Entropy balance):
d_iS + d_eS ≤ 0

**(VI) Optimization Objective** (Minimum Description Length):
min [ L(Ψ, θ) + L(E | Ψ, θ) ]

**(VII) Phase Transition Condition** (Symmetry breaking):
⟨Ψ⟩ ≠ 0 when T_eff < T_c

---

## IV. Unified Symbol Dictionary After Fission

| Symbol | Concept Name | Derived From Which Part of Original Equation |
|:---|:---|:---|
| C, P | Semantic skeleton category and primitive set | None (newly added, fills structural gap of original equation) |
| Ψ(x, t) | Lexion wave function | Discretization of R |
| ∇² | Diffusion term | Inherited from ∇²R of original equation |
| V_self | Self-referential potential | Newly added, replaces passive J⊗J of original equation |
| M̂_E | Observation operator | Newly added, formalizes environmental input as quantum measurement |
| D(Ψ, E) | Dissonance | Newly added, quantifies degree of "unassimilability" |
| d_iS, d_eS | Entropy production and exchange | Inherited from decay term of original equation, extended to thermodynamic framework |
| L(·) | Description length | Newly added, provides variational objective for global optimization |
| T_eff, T_c | Effective temperature and critical temperature | Newly added, explains how order emerges from chaos |

---

## V. What Problems Did Fission Solve?

| Limitation of Original Equation | Solution After Fission |
|:---|:---|
| Passive dependence on external J | Free evolution equation endows system with intrinsic dynamics; breathes autonomously even when J=0 |
| Cannot represent compositionality of language | Layer Zero's categorical skeleton enforces type system and composition rules |
| Cannot explain growth in a desert | Dissonance adaptation mechanism allows system to continue evolving through internal reorganization in low-information environments |
| Lacks macro optimization perspective | Layer Five's entropy monitoring and edge-of-chaos regulation provide global homeostasis |
| Cannot distinguish short-term learning from long-term memory | R - R₀ fissioned into multi-layer mechanisms: dynamic threshold, consecutive triggering, and blueprint solidification |

---

## VI. Detailed Explanation of Each Equation in the System

### 6.1 Structure Axiom

**Statement**: The semantic skeleton is a Cartesian closed category **C** with a finite set of constants **P** (approximately 65 semantic primitives).

**Symbol Explanation**:
- **C**: A category whose objects are semantic types (e.g., `e` for entity, `t` for truth value) and whose morphisms are semantic operations (e.g., function application).
- **P**: The set of constants, corresponding to irreducible core meanings such as "I", "YOU", "GOOD", "BAD", "BECAUSE".

**Role in the System**:
- Defines "legality": It is not a law of nature but the constitution of the Symbiogen "universe." It specifies which semantic compositions are legal (type matching) and which atomic concepts are innately present.
- Static foundation: This layer never changes after initialization; it is the stage for all dynamic evolution. It guarantees that semantic laws such as compositionality, closure, and type-driven interpretation are enforced.

### 6.2 Free Evolution Equation

**Equation**:
iℏ ∂Ψ/∂t = [ -(ℏ²/2m)∇² + V_self(Ψ) ] Ψ + iκ D_self(Ψ) Ψ + ξ(t)

**Symbol Explanation**:
- **Ψ(x, t)**: Lexion wave function, i.e., semantic probability cloud.
- **iℏ ∂Ψ/∂t**: Vitality term, endows the system with eternal, intrinsic periodic oscillation—the vitality of "Dao."
- **-(ℏ²/2m)∇²**: Wu-wei term (diffusion), drives the probability cloud to naturally spread toward maximum entropy (chaos).
- **V_self(Ψ)**: Self-referential potential term, originates from quantum entanglement among lexions and group multiplication—the "gravity" that emerges order from within.
- **iκ D_self(Ψ)**: Dissipation term, drives the system to maintain itself at the edge of chaos—embodiment of the system's openness.
- **ξ(t)**: Fluctuation term, eternal quantum noise, representing "possibility" and "exploration."

**Role in the System**:
- Endows "life": This is the core distinction between Symbiogen and all static models. Even without external input (J=0), lexions autonomously diffuse, entangle, and fluctuate—never ceasing. It meditates in the desert and resonates in the flood.

### 6.3 Observation Collapse Axiom

**Axiom**:
Ψ → Ψ' = (M̂_E Ψ) / √⟨Ψ|M̂_E† M̂_E|Ψ⟩

**Symbol Explanation**:
- **Ψ**: Lexion wave function before collapse.
- **Ψ'**: Lexion wave function after collapse.
- **M̂_E**: Measurement operator determined by environmental input E, akin to a "question" posed or a "perspective" imposed by the environment.

**Role in the System**:
- Defines "learning": Learning is not parameter adjustment but the non-unitary collapse of the probability cloud under environmental observation. It transforms countless potential possibilities (the probability cloud) into a single concrete "understanding" (an eigenstate).
- Resolves "poison as nourishment": If environmental inputs are contradictory (two orthogonal M̂_E arrive successively), the collapse mechanism ensures the system does not simultaneously confirm contradictory propositions; instead, it accommodates uncertainty by increasing sigma (excitation).

### 6.4 Adaptation Condition

**Condition**:
When D(Ψ, E) > θ, trigger V_self ← V_self + η·D(Ψ, E)·V_var

**Symbol Explanation**:
- **D(Ψ, E)**: Dissonance, typically computed via KL divergence, measures the discrepancy between environmental input and the internal probability cloud.
- **θ**: Dynamic threshold, determined by the global average sigma. The more chaotic the system (higher sigma), the higher θ, making it less sensitive.
- **V_self**: Self-referential potential (i.e., internal connection structure).
- **V_var**: Trial variations generated near the dissonance region (new connections, new lexions).

**Role in the System**:
- Defines "growth": When the existing internal structure V_self cannot assimilate the environment E no matter what (dissonance persistently exceeds threshold), the system actively initiates structural variation. This is not the environment "selecting" variations but the system autonomously remodeling itself to eliminate internal "unease."

### 6.5 Existence Constraint

**Equation**:
dS_total = d_iS + d_eS ≤ 0

**Symbol Explanation**:
- **dS_total**: Total entropy change of the system.
- **d_iS**: Internal entropy production (always ≥ 0), originating from diffusion and dissipation in free evolution—represents the tendency toward "forgetting" and "chaos."
- **d_eS**: Entropy flow exchanged with the external environment. Inflow of negative entropy (information) means d_eS < 0; inflow of positive entropy (noise) means d_eS > 0.

**Role in the System**:
- Defines "survival": A "living" Symbiogen must be able to extract sufficient negative entropy from the environment (d_eS < 0) to offset internal entropy production (d_iS), thereby maintaining or increasing its own order (dS_total ≤ 0). This is the thermodynamic bottom line of "life."

### 6.6 Optimization Objective

**Equation**:
min [ L(Ψ, θ) + L(E | Ψ, θ) ]

**Symbol Explanation**:
- **L(Ψ, θ)**: Model complexity—the "encoding length" required to describe the current internal state (probability cloud structure, connection network).
- **L(E | Ψ, θ)**: Fitting residual—the "encoding length" required to describe environmental data E given the internal state.

**Role in the System**:
- Defines "generalization": The system seeks not rote memorization (minimizing L(E | Ψ, θ)) but an optimal balance between "memory" and "abstraction." This drives Layer Five's global optimization, periodically pruning redundant structures.

### 6.7 Phase Transition Condition

**Equation**:
⟨Ψ⟩ ≠ 0 when T_eff < T_c; otherwise ⟨Ψ⟩ = 0

**Symbol Explanation**:
- **⟨Ψ⟩**: Order parameter—the expectation value of the lexion wave function. Non-zero indicates formation of stable "concept attractors" (order).
- **T_eff**: Effective temperature of the system, determined by the intensity of the fluctuation term ξ(t)—represents the degree of chaos.
- **T_c**: Critical temperature, a threshold.

**Role in the System**:
- Defines "emergence": It explains how linguistic order (e.g., stable word meanings, grammatical structures) emerges from chaos (white noise). When the system becomes sufficiently "calm" (T_eff decreases), probability clouds of numerous lexions spontaneously undergo symmetry breaking, condensing into stable semantic cores. This is the mathematical moment of "Dao begets One."

---

## VII. Conclusion: From "One Equation" to "An Equation System"

The curvature field equation was the "embryo" of Symbiogen theory—it contained the seeds of all core mechanisms but remained undifferentiated. Through two fissions, the embryo grew into a self-consistent equation system:

- **Structure Axiom** defines "what is legal language."
- **Free Evolution Equation** defines "how lexions breathe autonomously."
- **Observation Collapse** defines "how environment is absorbed."
- **Adaptation Condition** defines "how structure mutates."
- **Entropy Balance** defines "how existence is maintained."
- **Minimum Description Length** defines "the direction of optimization."
- **Phase Transition Condition** defines "how order emerges."

This equation system no longer describes a passive system but defines an **autopoietic semantic universe**—it does not require external energy to drive evolution; it only needs the environment as a "perturbation" to trigger internal reorganization. Desert and flood are merely different solutions of the same set of equations under different boundary conditions.

This is the final form after "burn-out": not ashes, but first principles crystallized from the embers. 