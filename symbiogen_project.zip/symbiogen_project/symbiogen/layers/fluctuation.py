from symbiogen.layers.base import Layer
from symbiogen.primitives.fluctuate import fluctuate

class FluctuationLayer(Layer):
    """涨落层：注入随机噪声，驱动探索"""
    
    def __init__(self, field, config=None):
        if config is None: config = {}
        super().__init__(field, config)
        self.delta = config.get("delta", 0.01)
    
    def run(self, **kwargs):
        fluctuate(self.field, delta=self.delta)