"""
通用语义原子集

基于自然语义元语言 (NSM) 理论，定义了约65个在所有人类语言中
都能找到对应表达的核心概念。这些原子是组合性语义的最小单元。

每个原子存储其精确的语义类型（SemanticType 对象），
而非简化的类型名。
"""

from .types import TypeSystem, AtomicType, PowerType


class SemanticPrimitives:
    """
    语义原子管理器
    
    原子分为多个范畴：实体、关系、逻辑、时空、评价、动作等。
    每个原子具有唯一名称、精确语义类型、范畴和描述。
    """
    
    # 原子范畴常量
    CAT_ENTITY = "entity"           # 实体
    CAT_RELATION = "relation"       # 关系
    CAT_LOGIC = "logic"             # 逻辑
    CAT_SPACETIME = "spacetime"     # 时空
    CAT_EVALUATION = "evaluation"   # 评价
    CAT_ACTION = "action"           # 动作
    CAT_QUANTITY = "quantity"       # 数量
    CAT_EXISTENCE = "existence"     # 存在
    
    def __init__(self, type_system):
        """
        初始化语义原子集
        
        参数:
            type_system: TypeSystem 实例，提供类型构造能力
        """
        self.ts = type_system
        # 存储结构: name -> (SemanticType, category, description)
        self._primitives = {}
        self._initialize_primitives()
    
    def _initialize_primitives(self):
        """初始化约65个语义原子，每个原子赋予精确的语义类型"""
        
        # 获取原子类型
        e = self.ts.TYPE_E          # 实体
        t = self.ts.TYPE_T          # 真值
        s = self.ts.TYPE_S          # 世界-时间索引
        
        # 常用复合类型
        et = self.ts.make_power(e, t)           # e → t   (一元谓词)
        eet = self.ts.make_power(e, et)         # e → e → t (二元关系)
        ee = self.ts.make_power(e, e)           # e → e   (一元函数)
        tt = self.ts.make_power(t, t)           # t → t   (真值函数)
        ttt = self.ts.make_power(t, tt)         # t → t → t (二元逻辑连接词)
        se = self.ts.make_power(s, e)           # s → e   (时态实体)
        st = self.ts.make_power(s, t)           # s → t   (时态命题)
        set_type = self.ts.make_power(s, et)    # s → e → t (时态谓词)
        
        # ========== 实体类 (类型 e) ==========
        entities = [
            ("I", e, self.CAT_ENTITY, "我"),
            ("YOU", e, self.CAT_ENTITY, "你"),
            ("SOMEONE", e, self.CAT_ENTITY, "某人"),
            ("SOMETHING", e, self.CAT_ENTITY, "某物"),
            ("PEOPLE", e, self.CAT_ENTITY, "人们"),
            ("BODY", e, self.CAT_ENTITY, "身体"),
            ("THING", e, self.CAT_ENTITY, "东西"),
            ("WORLD", e, self.CAT_ENTITY, "世界"),
        ]
        for name, typ, cat, desc in entities:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 关系类 (类型 e → e → t) ==========
        relations = [
            ("KIND", eet, self.CAT_RELATION, "种类"),
            ("PART", eet, self.CAT_RELATION, "部分"),
            ("HAVE", eet, self.CAT_RELATION, "拥有"),
            ("BELONG", eet, self.CAT_RELATION, "属于"),
        ]
        for name, typ, cat, desc in relations:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 逻辑类 ==========
        # 一元逻辑连接词 (类型 t → t)
        logics_unary = [
            ("NOT", tt, self.CAT_LOGIC, "不"),
        ]
        for name, typ, cat, desc in logics_unary:
            self._primitives[name] = (typ, cat, desc)
        
        # 二元逻辑连接词 (类型 t → t → t)
        logics_binary = [
            ("AND", ttt, self.CAT_LOGIC, "且"),
            ("OR", ttt, self.CAT_LOGIC, "或"),
            ("BECAUSE", ttt, self.CAT_LOGIC, "因为"),
            ("IF", ttt, self.CAT_LOGIC, "如果"),
        ]
        for name, typ, cat, desc in logics_binary:
            self._primitives[name] = (typ, cat, desc)
        
        # 模态类 (类型 t → t)
        modals = [
            ("CAN", tt, self.CAT_LOGIC, "能"),
            ("MAYBE", tt, self.CAT_LOGIC, "可能"),
            ("MUST", tt, self.CAT_LOGIC, "必须"),
        ]
        for name, typ, cat, desc in modals:
            self._primitives[name] = (typ, cat, desc)
        
        # 真值常量 (类型 t)
        truth_values = [
            ("TRUE", t, self.CAT_LOGIC, "真"),
            ("FALSE", t, self.CAT_LOGIC, "假"),
        ]
        for name, typ, cat, desc in truth_values:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 时空类 ==========
        # 时态算子 (类型 t → t 或 s → t)
        spacetime_operators = [
            ("WHEN", self.ts.make_power(s, tt), self.CAT_SPACETIME, "当...时"),
            ("WHERE", self.ts.make_power(e, tt), self.CAT_SPACETIME, "在...地方"),
            ("BEFORE", tt, self.CAT_SPACETIME, "在...之前"),
            ("AFTER", tt, self.CAT_SPACETIME, "在...之后"),
        ]
        for name, typ, cat, desc in spacetime_operators:
            self._primitives[name] = (typ, cat, desc)
        
        # 时空实体 (类型 e 或 s)
        spacetime_entities = [
            ("NOW", s, self.CAT_SPACETIME, "现在"),
            ("HERE", e, self.CAT_SPACETIME, "这里"),
            ("TIME", e, self.CAT_SPACETIME, "时间"),
            ("PLACE", e, self.CAT_SPACETIME, "地方"),
        ]
        for name, typ, cat, desc in spacetime_entities:
            self._primitives[name] = (typ, cat, desc)
        
        # 空间关系 (类型 e → e → t)
        spatial_relations = [
            ("FAR", eet, self.CAT_SPACETIME, "远"),
            ("NEAR", eet, self.CAT_SPACETIME, "近"),
            ("ABOVE", eet, self.CAT_SPACETIME, "在...之上"),
            ("BELOW", eet, self.CAT_SPACETIME, "在...之下"),
            ("INSIDE", eet, self.CAT_SPACETIME, "在...之内"),
        ]
        for name, typ, cat, desc in spatial_relations:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 评价类 (类型 e → t) ==========
        evaluations = [
            ("GOOD", et, self.CAT_EVALUATION, "好"),
            ("BAD", et, self.CAT_EVALUATION, "坏"),
            ("BIG", et, self.CAT_EVALUATION, "大"),
            ("SMALL", et, self.CAT_EVALUATION, "小"),
            ("BEAUTIFUL", et, self.CAT_EVALUATION, "美"),
            ("UGLY", et, self.CAT_EVALUATION, "丑"),
        ]
        for name, typ, cat, desc in evaluations:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 动作类 ==========
        # 一元动作 (类型 e → t)
        actions_unary = [
            ("LIVE", et, self.CAT_ACTION, "活"),
            ("DIE", et, self.CAT_ACTION, "死"),
            ("HAPPEN", st, self.CAT_ACTION, "发生"),
        ]
        for name, typ, cat, desc in actions_unary:
            self._primitives[name] = (typ, cat, desc)
        
        # 二元动作 (类型 e → e → t)
        actions_binary = [
            ("DO", eet, self.CAT_ACTION, "做"),
            ("MOVE", eet, self.CAT_ACTION, "移动"),
            ("SAY", eet, self.CAT_ACTION, "说"),
            ("THINK", eet, self.CAT_ACTION, "想"),
            ("KNOW", eet, self.CAT_ACTION, "知道"),
            ("SEE", eet, self.CAT_ACTION, "看见"),
            ("HEAR", eet, self.CAT_ACTION, "听见"),
            ("WANT", eet, self.CAT_ACTION, "想要"),
            ("FEEL", eet, self.CAT_ACTION, "感觉"),
        ]
        for name, typ, cat, desc in actions_binary:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 数量类 ==========
        # 数量词作为限定词，类型为 (e → t) → (e → t) → t 或类似
        # 为简化，赋予占位类型，实际使用时通过组合规则处理
        quantities = [
            ("ONE", e, self.CAT_QUANTITY, "一"),
            ("TWO", e, self.CAT_QUANTITY, "二"),
            ("MANY", et, self.CAT_QUANTITY, "许多"),
            ("ALL", et, self.CAT_QUANTITY, "所有"),
            ("SOME", et, self.CAT_QUANTITY, "一些"),
            ("MOST", et, self.CAT_QUANTITY, "大多数"),
        ]
        for name, typ, cat, desc in quantities:
            self._primitives[name] = (typ, cat, desc)
        
        # ========== 存在类 ==========
        existence = [
            ("EXIST", et, self.CAT_EXISTENCE, "存在"),
            ("THERE_IS", st, self.CAT_EXISTENCE, "有"),
        ]
        for name, typ, cat, desc in existence:
            self._primitives[name] = (typ, cat, desc)
    
    def get_all_primitives(self):
        """返回所有原子名称列表"""
        return list(self._primitives.keys())
    
    def get_primitive_type(self, name):
        """
        获取原子的精确语义类型
        
        参数:
            name: 原子名称
        
        返回:
            SemanticType 对象，若不存在则返回 None
        """
        if name in self._primitives:
            return self._primitives[name][0]
        return None
    
    def get_primitive_info(self, name):
        """
        获取原子的完整信息
        
        返回:
            (SemanticType, category, description) 元组，若不存在则返回 None
        """
        return self._primitives.get(name, None)
    
    def is_primitive(self, name):
        """检查是否为语义原子"""
        return name in self._primitives
    
    def get_primitives_by_category(self, category):
        """按范畴获取原子名称列表"""
        return [
            name for name, (_, cat, _) in self._primitives.items() 
            if cat == category
        ]
    
    def get_all_categories(self):
        """获取所有原子范畴"""
        categories = set()
        for _, cat, _ in self._primitives.values():
            categories.add(cat)
        return list(categories)
    
    def get_primitive_count(self):
        """返回原子总数"""
        return len(self._primitives)