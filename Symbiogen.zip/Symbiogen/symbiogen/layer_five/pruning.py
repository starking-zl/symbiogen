"""
连接修剪器

周期性检查所有连接，将满足休眠条件的连接标记为休眠态，
将可唤醒的连接恢复为活跃态。

修剪策略说明：
- 采用保守修剪：只有当连接数超过最小保留数，且存在符合休眠条件的连接时才修剪。
- 即使某词元总连接数很大，如果符合条件的候选连接很少，实际修剪量也会受限。
- 这避免了因临时波动而过度修剪重要连接。
"""

import time
import numpy as np

class ConnectionPruner:
    """连接修剪引擎"""
    
    def __init__(self, 
                 dormancy_sigma_threshold=0.8,
                 dormancy_days_threshold=7,
                 wake_sigma_threshold=0.3,
                 min_connections_per_lexion=2):
        """
        参数:
            dormancy_sigma_threshold: 进入休眠的离散度阈值
            dormancy_days_threshold: 进入休眠的闲置天数阈值
            wake_sigma_threshold: 唤醒的离散度阈值（低于此值可唤醒）
            min_connections_per_lexion: 每个词元保留的最小活跃连接数
        """
        self.dormancy_sigma_threshold = dormancy_sigma_threshold
        self.dormancy_days_threshold = dormancy_days_threshold
        self.wake_sigma_threshold = wake_sigma_threshold
        self.min_connections_per_lexion = min_connections_per_lexion
        
        # 统计
        self.total_pruned = 0
        self.total_woken = 0
    
    def prune(self, groupoid, lexicon=None):
        """
        执行一轮修剪：将符合条件的活跃连接设为休眠
        
        参数:
            groupoid: 群胚管理器
            lexicon: 词元词典（可选，用于保护关键连接）
        
        返回:
            pruned_count: 本次休眠的连接数
            details: 详细信息列表
        """
        pruned_count = 0
        details = []
        
        all_connections = groupoid.get_all_connections(include_dormant=False)
        
        # 按源词元分组，确保每个词元保留最小连接数
        connections_by_source = {}
        for conn in all_connections:
            if conn.source_id not in connections_by_source:
                connections_by_source[conn.source_id] = []
            connections_by_source[conn.source_id].append(conn)
        
        for source_id, conns in connections_by_source.items():
            # 如果该词元的连接数已经很少，跳过修剪（保守策略）
            if len(conns) <= self.min_connections_per_lexion:
                continue
            
            # 评估每条连接是否应休眠
            candidates = []
            for conn in conns:
                if conn.is_dormant_candidate(self.dormancy_sigma_threshold, 
                                             self.dormancy_days_threshold):
                    # 计算休眠优先级：离散度越高、闲置越久，优先级越高
                    days_unused = (time.time() - conn.last_used) / 86400.0
                    priority = conn.sigma * 0.6 + min(days_unused / 30.0, 1.0) * 0.4
                    candidates.append((conn, priority))
            
            if not candidates:
                continue
            
            # 按优先级排序（优先级高的先休眠）
            candidates.sort(key=lambda x: x[1], reverse=True)
            
            # 计算可休眠的最大数量（保留最小连接数）
            max_prune = len(conns) - self.min_connections_per_lexion
            
            # 实际休眠数量 = min(候选数量, 最大允许数量)
            # Python切片自动处理超出范围的情况
            for conn, _ in candidates[:max_prune]:
                conn.set_dormant(True)
                pruned_count += 1
                details.append({
                    "source": source_id,
                    "target": conn.target_id,
                    "sigma": conn.sigma,
                    "days_unused": (time.time() - conn.last_used) / 86400.0
                })
        
        self.total_pruned += pruned_count
        return pruned_count, details
    
    def wake(self, groupoid):
        """
        唤醒可恢复的连接：离散度已降低的休眠连接
        
        参数:
            groupoid: 群胚管理器
        
        返回:
            woken_count: 本次唤醒的连接数
        """
        woken_count = 0
        
        # 获取所有休眠连接
        all_connections = groupoid.get_all_connections(include_dormant=True)
        dormant_conns = [c for c in all_connections if c.dormant]
        
        for conn in dormant_conns:
            # 唤醒条件：离散度降低到阈值以下
            if conn.sigma <= self.wake_sigma_threshold:
                conn.set_dormant(False)
                woken_count += 1
        
        self.total_woken += woken_count
        return woken_count
    
    def force_prune_low_use(self, groupoid, use_count_threshold=5, days_threshold=30):
        """
        强制修剪长期极低使用的连接（无论离散度如何）
        
        参数:
            groupoid: 群胚管理器
            use_count_threshold: 使用次数阈值
            days_threshold: 创建天数阈值
        
        返回:
            pruned: 本次修剪的连接数
        """
        pruned = 0
        all_connections = groupoid.get_all_connections(include_dormant=False)
        
        for conn in all_connections:
            days_exist = (time.time() - conn.created_at) / 86400.0
            if conn.use_count < use_count_threshold and days_exist > days_threshold:
                conn.set_dormant(True)
                pruned += 1
        
        self.total_pruned += pruned
        return pruned
    
    def get_statistics(self):
        """获取修剪统计"""
        return {
            "total_pruned": self.total_pruned,
            "total_woken": self.total_woken,
            "net_change": self.total_woken - self.total_pruned,
            "dormancy_sigma_threshold": self.dormancy_sigma_threshold,
            "dormancy_days_threshold": self.dormancy_days_threshold
        }