"""
环境坍缩

当环境输入到达时，词元概率云发生贝叶斯坍缩：
p' ∝ p × likelihood(E | p)

这模拟了量子测量过程，将可能性转化为确定性。
"""

import numpy as np

class BayesianCollapse:
    """贝叶斯坍缩引擎"""
    
    def __init__(self, temperature=0.1):
        """
        参数:
            temperature: 坍缩温度，控制坍缩的锐利程度
                        温度越低，坍缩越尖锐 (确定性越强)
        """
        self.temperature = temperature
    
    def compute_likelihood(self, lexion, evidence_vector):
        """
        计算给定词元状态下，观测到证据向量的似然
        
        似然 = exp(-|p - evidence|² / (2 * σ² * T))
        其中 σ 是词元的离散度，T 是温度。
        
        离散度越大，似然越扁平 (越不确定如何坍缩)。
        """
        # 证据向量与当前概率分布的距离
        diff = lexion.p - evidence_vector
        distance_sq = np.dot(diff, diff)
        
        # 离散度影响：σ 越大，似然越扁平
        sigma_factor = lexion.sigma ** 2 + 1e-6
        
        # 计算似然
        likelihood = np.exp(-distance_sq / (2 * sigma_factor * self.temperature))
        
        return likelihood
    
    def collapse(self, lexion, evidence_vector):
        """
        执行坍缩：贝叶斯更新
        
        参数:
            lexion: 要坍缩的词元
            evidence_vector: 环境提供的证据向量 (256维)
        
        返回:
            坍缩后的概率向量 (原地修改)
            坍缩置信度 (后验概率的最大值)
        """
        # 计算似然
        likelihood = self.compute_likelihood(lexion, evidence_vector)
        
        # 贝叶斯更新: 后验 ∝ 先验 × 似然
        posterior = lexion.p * likelihood
        
        # 归一化
        posterior_sum = np.sum(posterior)
        if posterior_sum > 1e-12:
            posterior = posterior / posterior_sum
        else:
            # 数值下溢时，退化为均匀分布
            posterior = np.ones(lexion.dimension) / lexion.dimension
        
        # 更新概率向量
        lexion.p = posterior
        
        # 更新相位中心
        lexion.mu = self._compute_posterior_center(posterior, evidence_vector)
        
        # 更新频率和年龄
        lexion.update_frequency()
        
        # 计算坍缩置信度 (后验的最大值)
        confidence = np.max(posterior)
        
        # 记录激活值
        lexion.record_activation(confidence)
        
        return posterior, confidence
    
    def _compute_posterior_center(self, posterior, evidence):
        """计算后验的相位中心 (向证据方向偏移)"""
        n = len(posterior)
        # 找到后验概率最大的维度
        max_idx = np.argmax(posterior)
        vec = np.zeros(n)
        vec[max_idx] = 1.0
        return vec
    
    def compute_dissonance(self, lexion, evidence_vector):
        """
        计算失谐度：KL散度 D_KL(evidence || p)
        
        失谐度度量环境输入与当前概率云的差异程度。
        用于触发顺应。
        """
        # 确保证据向量是归一化的
        ev = evidence_vector / (np.sum(evidence_vector) + 1e-12)
        
        # KL散度
        kl = 0.0
        for i in range(len(lexion.p)):
            if lexion.p[i] > 1e-12 and ev[i] > 1e-12:
                kl += ev[i] * np.log(ev[i] / lexion.p[i])
        
        return kl