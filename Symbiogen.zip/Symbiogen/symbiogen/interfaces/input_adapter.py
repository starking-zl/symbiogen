"""输入适配器抽象基类"""
from abc import ABC, abstractmethod

class InputAdapter(ABC):
    @abstractmethod
    def start(self):
        """启动监听"""
        pass

    @abstractmethod
    def stop(self):
        """停止监听"""
        pass

    @abstractmethod
    def register_callback(self, callback):
        """注册收到消息时的回调函数"""
        pass