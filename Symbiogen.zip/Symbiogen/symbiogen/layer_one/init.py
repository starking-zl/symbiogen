"""
词元初始化器

负责从第零层的语义原子集创建初始词元，
并为新词元提供白噪声初始化。
"""

import numpy as np
from .lexion import Lexion

class LexionInitializer:
    """词元初始化器"""
    
    def __init__(self, dimension=256, semantic_primitives=None):
        """
        参数:
            dimension: 概率向量的维度
            semantic_primitives: 第零层的语义原子管理器
        """
        self.dimension = dimension
        self.primitives = semantic_primitives
        self._lexicon = {}  # name -> Lexion
    
    def initialize_from_primitives(self):
        """
        从语义原子集创建初始词元
        
        语义原子是系统的“先天锚点”，其词元具有：
        - 初始概率云集中于特定方向
        - 离散度较低 (确定性较高)
        - 标记为 is_primitive=True
        """
        if self.primitives is None:
            raise ValueError("semantic_primitives is required for initialization")
        
        for atom_name in self.primitives.get_all_primitives():
            lex = Lexion(
                name=atom_name,
                dimension=self.dimension,
                is_primitive=True,
                primitive_name=atom_name
            )
            
            # 语义原子的初始概率云：集中于特定方向
            # 使用哈希确定方向，确保同一原子每次初始化方向一致
            seed = hash(atom_name) % self.dimension
            lex.p = np.zeros(self.dimension)
            lex.p[seed] = 0.8
            # 向邻近维度扩散
            for i in range(1, 5):
                lex.p[(seed + i) % self.dimension] = 0.05 / i
                lex.p[(seed - i) % self.dimension] = 0.05 / i
            lex.p = lex.p / np.sum(lex.p)
            
            # 相位中心
            lex.mu = np.zeros(self.dimension)
            lex.mu[seed] = 1.0
            
            # 原子初始离散度较低 (确定性高)
            lex.sigma = 0.15
            
            # 原子初始相干性较高
            lex.phi = 0.8
            
            self._lexicon[atom_name] = lex
        
        return self._lexicon
    
    def create_new_lexion(self, name):
        """
        创建新词元 (白噪声初始化)
        
        新词元没有先天锚定，初始状态为高离散度的白噪声。
        """
        if name in self._lexicon:
            raise ValueError(f"Lexion '{name}' already exists")
        
        lex = Lexion(name=name, dimension=self.dimension, is_primitive=False)
        
        # 白噪声初始化：均匀分布 + 微小扰动
        lex.p = np.ones(self.dimension) / self.dimension
        noise = np.random.randn(self.dimension) * 0.01
        lex.p = lex.p + noise
        lex.p = np.maximum(lex.p, 1e-12)
        lex.p = lex.p / np.sum(lex.p)
        
        # 随机相位中心
        lex.mu = np.random.randn(self.dimension)
        lex.mu = lex.mu / (np.linalg.norm(lex.mu) + 1e-8)
        
        # 新词元初始离散度大 (不确定性高)
        lex.sigma = 0.7
        
        # 新词元初始相干性低
        lex.phi = 0.05
        
        self._lexicon[name] = lex
        return lex
    
    def get_lexion(self, name):
        """获取词元"""
        return self._lexicon.get(name, None)
    
    def get_all_lexions(self):
        """获取所有词元"""
        return self._lexicon
    
    def get_primitive_lexions(self):
        """获取所有语义原子词元"""
        return {name: lex for name, lex in self._lexicon.items() if lex.is_primitive}
    
    def lexicon_size(self):
        """返回当前词元数量"""
        return len(self._lexicon)