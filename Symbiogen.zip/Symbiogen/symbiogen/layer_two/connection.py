"""
连接类

每条连接代表一个词元指向另一个词元的倾向性。
- mu_conn: 倾向中心 (连接强度的期望)
- sigma_conn: 倾向离散度 (连接强度的不确定性)
- conn_type: 连接类型 ("application", "modification", "association")
- last_used: 最后使用时间 (用于休眠判断)
"""

import time
import numpy as np

class Connection:
    """词元间的有向连接"""
    
    # 连接类型常量
    TYPE_APPLICATION = "application"      # 函项应用
    TYPE_MODIFICATION = "modification"    # 谓词修饰
    TYPE_ASSOCIATION = "association"      # 一般关联
    
    def __init__(self, source_id, target_id, conn_type=TYPE_ASSOCIATION):
        self.source_id = source_id          # 源词元标识
        self.target_id = target_id          # 目标词元标识
        
        # 倾向中心 (初始为小的随机值)
        self.mu = np.random.randn() * 0.1
        
        # 倾向离散度 (初始较大，代表不确定)
        self.sigma = 0.5
        
        # 连接类型
        self.conn_type = conn_type
        
        # 使用计数
        self.use_count = 0
        
        # 最后使用时间戳
        self.last_used = time.time()
        
        # 创建时间
        self.created_at = time.time()
        
        # 是否休眠
        self.dormant = False
        
        # 历史成功率 (用于评估变异)
        self.success_history = []
    
    def update_after_use(self, success, confidence):
        """
        使用后更新状态
        
        参数:
            success: 本次组合是否成功 (产生有意义的输出)
            confidence: 坍缩置信度 (0~1)
        """
        self.use_count += 1
        self.last_used = time.time()
        
        # 记录成功历史
        self.success_history.append(1.0 if success else 0.0)
        if len(self.success_history) > 50:
            self.success_history = self.success_history[-50:]
        
        # 根据成功与否调整倾向区间
        if success:
            # 成功：mu向正方向微移，sigma收缩
            # 如果当前mu为正，向+1方向移动；如果为负，向0方向移动
            if self.mu >= 0:
                self.mu += 0.01 * confidence * (1.0 - self.mu)
            else:
                self.mu += 0.01 * confidence * (0.0 - self.mu)  # 向零靠拢
            self.sigma = max(0.05, self.sigma * (1.0 - 0.02 * confidence))
        else:
            # 失败：mu向零微移，sigma扩张
            self.mu *= 0.99
            self.sigma = min(0.95, self.sigma * 1.02)
    
    def get_success_rate(self):
        """获取近期成功率"""
        if not self.success_history:
            return 0.5
        return np.mean(self.success_history)
    
    def is_dormant_candidate(self, dormancy_threshold=0.8, unused_days=7):
        """判断是否应进入休眠"""
        if self.dormant:
            return False
        # 离散度过高且长期未使用
        days_unused = (time.time() - self.last_used) / 86400.0
        return self.sigma >= dormancy_threshold and days_unused >= unused_days
    
    def set_dormant(self, dormant=True):
        """设置休眠状态"""
        self.dormant = dormant
    
    def to_dict(self):
        """序列化"""
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "mu": self.mu,
            "sigma": self.sigma,
            "conn_type": self.conn_type,
            "use_count": self.use_count,
            "last_used": self.last_used,
            "created_at": self.created_at,
            "dormant": self.dormant,
            "success_history": self.success_history
        }
    
    @classmethod
    def from_dict(cls, data):
        """反序列化"""
        conn = cls(data["source_id"], data["target_id"], data["conn_type"])
        conn.mu = data["mu"]
        conn.sigma = data["sigma"]
        conn.use_count = data["use_count"]
        conn.last_used = data["last_used"]
        conn.created_at = data["created_at"]
        conn.dormant = data["dormant"]
        conn.success_history = data["success_history"]
        return conn
    
    def __repr__(self):
        status = "💤" if self.dormant else "→"
        return f"Connection({self.source_id} {status} {self.target_id}, μ={self.mu:.3f}, σ={self.sigma:.3f})"