import numpy as np
def diffuse(field, iterations=3, alpha=0.1):
    """
    曲率扩散：∇²R 平滑
    
    参数:
        field: CurvatureField 实例
        iterations: 扩散迭代次数
        alpha: 扩散系数
    """
    for _ in range(iterations):
        curvature_updates = {}
        resource_updates = {}
        
        for pid, p in field.particles.items():
            neighbors = field.get_neighbors(pid)
            if not neighbors:
                continue
            
            # 邻居平均曲率
            neighbor_curvs = []
            neighbor_resources = []
            for nid in neighbors:
                n = field.particles.get(nid)
                if n:
                    neighbor_curvs.append(n.curvature)
                    neighbor_resources.append(n.resource)
            
            if neighbor_curvs:
                curvature_updates[pid] = alpha * (np.mean(neighbor_curvs) - p.curvature)
                resource_updates[pid] = alpha * (np.mean(neighbor_resources) - p.resource)
        
        # 应用更新
        for pid, update in curvature_updates.items():
            field.particles[pid].curvature += update
        for pid, update in resource_updates.items():
            field.particles[pid].resource += update