"""
组合运算

实现蒙太古语义学的核心组合规则：
- 函项应用 (Function Application)
- 谓词修饰 (Predicate Modification)
- λ-抽象 (Lambda Abstraction) - 简化版
"""

class Composer:
    """
    组合器
    
    提供语义组合的合法运算，确保输出类型正确。
    """
    
    def __init__(self, type_system):
        self.ts = type_system
    
    def function_application(self, fun_expr, arg_expr, fun_type, arg_type):
        """
        函项应用：将函数作用于参数
        
        fun_type: A → B
        arg_type: A
        返回类型: B
        """
        if not isinstance(fun_type, PowerType):
            raise TypeError(f"函数应用要求第一个表达式为函数类型，实际为 {fun_type}")
        
        if fun_type.domain != arg_type:
            raise TypeError(f"类型不匹配：函数期望 {fun_type.domain}，参数为 {arg_type}")
        
        # 在实际语义计算中，这里会执行真正的函数调用
        # 骨架层仅验证类型合法性，实际计算由上层完成
        return fun_type.codomain
    
    def predicate_modification(self, pred1_expr, pred2_expr, pred1_type, pred2_type):
        """
        谓词修饰：两个谓词的交集
        
        要求两个谓词类型相同，均为 e → t
        返回类型: e → t
        """
        expected = self.ts.make_power(self.ts.TYPE_E, self.ts.TYPE_T)
        
        if pred1_type != expected:
            raise TypeError(f"谓词修饰要求类型 {expected}，实际 pred1 为 {pred1_type}")
        if pred2_type != expected:
            raise TypeError(f"谓词修饰要求类型 {expected}，实际 pred2 为 {pred2_type}")
        
        return expected
    
    def lambda_abstraction(self, var_name, body_expr, var_type, body_type):
        """
        λ-抽象：从表达式中抽象出函数
        
        var_type: 变量类型 A
        body_type: 函数体类型 B
        返回类型: A → B
        """
        return self.ts.make_power(var_type, body_type)
    
    def is_composable(self, expr_list, target_type):
        """
        检查一系列表达式是否能组合为目标类型
        
        这是一个简化版的类型推导，用于快速验证。
        """
        if len(expr_list) == 0:
            return False
        
        # 简化处理：假设所有表达式都是通过函项应用组合
        current = expr_list[0]
        for i in range(1, len(expr_list)):
            if isinstance(current, PowerType):
                if current.domain == expr_list[i]:
                    current = current.codomain
                else:
                    return False
            else:
                return False
        
        return current == target_type