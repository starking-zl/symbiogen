from symbiogen.layers.base import Layer
from symbiogen.primitives.diffuse import diffuse

class DiffusionLayer(Layer):
    """扩散层：执行 ∇²R 平滑和资源扩散"""
    
    def __init__(self, field, config=None):
        if config is None: config = {}
        super().__init__(field, config)
        self.iterations = config.get("iterations", 3)
        self.alpha = config.get("alpha", 0.1)
    
    def run(self, **kwargs):
        diffuse(self.field, iterations=self.iterations, alpha=self.alpha)
        return self.iterations