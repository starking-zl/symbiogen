import numpy as np

def etch(field, input_vector, strength=1.0, top_k=5):
    """
    信息刻蚀：将输入向量 J 转化为曲率场的塑性形变
    
    参数:
        field: CurvatureField 实例
        input_vector: 信息流向量 J
        strength: 刻蚀强度
        top_k: 选择共振度最高的 K 个粒子进行刻蚀
    """
    input_vector = np.array(input_vector, dtype=np.float32)
    
    # 计算所有粒子与输入向量的共振度
    resonances = []
    for pid, p in field.particles.items():
        resonance = np.dot(input_vector, p.coordinate)
        resonances.append((pid, resonance))
    
    # 选择共振度最高的 K 个
    resonances.sort(key=lambda x: abs(x[1]), reverse=True)
    selected = resonances[:top_k]
    
    # 对选中粒子进行刻蚀
    for pid, resonance in selected:
        if abs(resonance) < 0.01:
            continue
            
        p = field.particles[pid]
        
        # J ⊗ J 刻蚀：更新曲率
        etching_amount = strength * resonance * resonance
        p.curvature += etching_amount
        
        # 资源增加
        p.resource += abs(etching_amount) * 0.1
        
        # 更新激活值
        p.activation = resonance * strength
        
        # 更新统计量
        p.activation_mean = 0.9 * p.activation_mean + 0.1 * p.activation
        p.activation_var = 0.9 * p.activation_var + 0.1 * (p.activation - p.activation_mean) ** 2
    
    return len(selected)