"""共生基因群 Symbiogen —— 一个能从环境中自主生长出语言理解的数字生命"""

from symbiogen.colony import SymbiogenColony
from symbiogen.field import CurvatureField
from symbiogen.evolution import LineageTracker, select_best

__version__ = "1.0.0"
__all__ = ["SymbiogenColony", "CurvatureField", "LineageTracker", "select_best"]