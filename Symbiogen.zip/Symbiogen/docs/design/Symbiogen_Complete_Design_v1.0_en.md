# Symbiogen · Symbiotic Gene Colony Complete Design Specification v1.0

## I. Origin: From Practical Needs to First Principles

### 1.1 The Initial Problem

We need an artificial intelligence system capable of operating independently on mobile devices. It must satisfy the following constraints:

- **Free of Charge**: No reliance on cloud APIs; no billing by invocation volume.
- **Self-Editable**: Not a static black-box model, but a system capable of continuous growth, adjustment, and evolution.
- **Multi-Session Capable**: Able to concurrently process text, image, audio, and video streams from multiple sources.
- **Genuine Intelligence**: Not probabilistic linguistic mimicry, but a true understanding of the environment, with effective suppression of "hallucinations."

### 1.2 Rejection of Existing Approaches

- **Existing large language model applications**: Severe hallucinations, non-editable, cloud-dependent, not truly "owned."
- **Pure retrieval-augmented generation**: Mere retrieval, not understanding, lacking growth capacity.
- **Traditional on-device fine-tuning**: Requires substantial computation and data, difficult for mobile devices to accomplish independently, and results in static models.
- **Pure symbolic AI**: Semiotics itself lacks a complete logical framework for language and cannot autonomously learn from raw environments.
- **The pursuit of complete white-box interpretability**: We acknowledge that an intelligence we fully understand must be less intelligent than we are.

### 1.3 Establishment of the Core Proposition

To cultivate, from scratch on a mobile device, a digital life form capable of autonomously learning linguistic relationships from complex information environments (text, images, sound, video) and evolving continuously.

---

## II. Formation of the Gene Colony Concept

### 2.1 From Neural Networks to Evolutionary Units

Traditional neural networks are static, hierarchically fixed, and trained via global backpropagation. This paradigm cannot fulfill the requirements of "continuous autonomous learning" and "structural self-evolution." We must shift perspective from "training a model" to "cultivating a life form."

### 2.2 The Gene Metaphor

In biology, the gene is the fundamental unit of heredity, constructing the entire organism through expression and regulation. We borrow this concept to abstract the basic building blocks of neural networks as "genes"—each gene is a small neural sub-network template, containing its positional generation rules and expression conditions within a high-dimensional space. Multiple genes form a "genome," driving the structural and functional evolution of the entire system through expression, mutation, and inheritance.

### 2.3 The Birth of the Gene Colony

The power of a single gene is limited. We place a vast number of genes within the same high-dimensional manifold space, allowing them to form a "Gene Colony" through local interactions, resource competition, and symbiotic cooperation. A Gene Colony is not merely a collection of genes, but an ecosystem—genes, through the propagation of activation waves, metabolic cycles of resources, and structural growth and pruning, collectively give rise to emergent intelligence that no single gene possesses.

### 2.4 From Gene Colony to Curvature Field

Upon deeper reflection on the evolutionary principles of the Gene Colony, we discovered that all mechanisms—learning, memory, growth, reproduction—can be described as changes in "curvature" on a high-dimensional manifold. Information input acts like stress applied to the manifold, causing plastic deformation of curvature; diffusion smoothing acts like elastic relaxation of curvature; blueprint regression acts like a conservative force maintaining overall form. Ultimately, all behaviors of the Gene Colony collapse into a single unified mathematical equation—the Curvature Field Equation. The Gene Colony itself is the discrete physical realization of the curvature field.

---

## III. Evolution of Imagery: Tenfold Life Metaphors

We are not designing algorithms; we are observing life and infusing its wisdom into a digital substrate.

### 3.1 Rhizome

The rhizome has no taproot, no central trunk. Any point can sprout new shoots, and any break will not cause death. Information transmission within a rhizome has no fixed path—it grows wherever there are nutrients.

Injected Mechanisms: Centerless sprawl, heterogeneous growth, shortcut connections.

### 3.2 Coral

Coral is a symbiosis of polyps and zooxanthellae. Individual polyps are extremely simple, yet the colony builds complex, stable structures through shared calcareous skeletons.

Injected Mechanisms: Calcified skeleton (long-term memory), zooxanthellae symbiosis (external knowledge interface), bleaching warning (environmental shift detection).

### 3.3 Mycelium

Mycelium is among the largest organisms on Earth. Lacking a brain, the mycelial network can detect nutrients, establish optimal paths, and automatically reroute when severed.

Injected Mechanisms: Nutrient gradient-driven growth, network rerouting, hyphal fusion (functional module merging).

### 3.4 Lichen

Lichen is a symbiosis of fungus and algae. Their union creates entirely new morphologies and metabolic capabilities, enabling growth on bare rock.

Injected Mechanisms: Biphasic neurons (separation of structural and perceptual units), decoupling and re-symbiosis, active etching of input space.

### 3.5 Slime Mold

Slime mold is a single-celled organism without a nervous system, yet it forms networks strikingly similar to human-designed railway systems and remembers paths it has traversed.

Injected Mechanisms: Pseudopod exploration (active detection of novel information), chemical repellent (avoidance of re-exploration), periodic memory (phase-locked prediction).

### 3.6 Mother Tree Network

Ancient trees in forests transport nutrients to saplings through underground mycorrhizal networks; saplings reciprocate when mother trees age. The network also transmits warnings of pests and diseases.

Injected Mechanisms: Mother tree nodes (resource distribution centers), nutrient transport, cross-module broadcasting, reciprocal feedback.

### 3.7 Neural Crest

In vertebrate embryos, a special group of neural crest cells migrates from the neural tube throughout the body, differentiating into entirely different structures.

Injected Mechanisms: Migratory neurons, destination-dependent differentiation, collective migration to establish new modules.

### 3.8 Hive

Bees have no central command. Scout bees communicate information through the waggle dance; other bees autonomously decide whether to adopt it. There is no command, only influence.

Injected Mechanisms: Adoption threshold (autonomous decision-making), waggle dance (broadcast of significant discoveries), consensus hotspots (spontaneous formation of concept clusters).

### 3.9 Planarian

Planarians, when cut into hundreds of pieces, can regenerate a complete individual from each fragment. The secret lies in the polarity axis, pluripotent stem cells, and positional information.

Injected Mechanisms: Polarity axis (main direction of information flow), pluripotent stem cell pool, positional information diffusion, blueprint network, fragment regeneration.

### 3.10 Hydra

Hydras do not age. Their entire body is continuously renewed by ubiquitous pluripotent stem cells. Any part is a complete seed. A morphogenetic field maintains the overall blueprint.

Injected Mechanisms: Immortal stem cell field, morphogenetic field, budding reproduction, whole-body seeding, Lamarckian inheritance.

---

## IV. The Curvature Field Equation: Mathematical Unification of the Ten Metaphors

### 4.1 From Metaphor to Equation

When the ten metaphors are pushed to their limits, they begin to fuse and dissolve boundaries. We realize: all metaphors describe projections of the same underlying logic at different scales.

- Neurons and synapses are both local curvatures on a high-dimensional manifold.
- Activation and learning are both redistributions of energy on the manifold.
- Individual and collective are both local fluctuations and global coherence of a field.
- Memory and forgetting are both the deepening and smoothing of manifold curvature.
- Observation and compression are the same process—the moment information enters the manifold, curvature has already changed.

All behavior collapses into a single equation.

### 4.2 The Core Equation

Symbiogen is fully described by the following curvature flow equation:

∂R/∂t = α·(∇²R) + β·(J ⊗ J) - γ·(R - R₀) + δ·ξ - ε·Tr(R)·R

Where:
- **R**: Curvature tensor field, defined on a high-dimensional manifold.
- **∂R/∂t**: Temporal evolution of curvature.
- **∇²R**: Laplacian diffusion term for curvature, responsible for smoothing, repair, and propagation of positional information.
- **J ⊗ J**: Self-tensor product of the information flow, responsible for etching input into curvature changes.
- **R - R₀**: Blueprint regression term, maintaining structural stability.
- **ξ**: Stochastic fluctuation, driving exploration and diversity.
- **-ε·Tr(R)·R**: Global resource decay term, preventing unbounded curvature inflation.

The equation satisfies a curvature-resource conservation law:

d/dt ∫ Tr(R) = ∫ β|J|² - ε (∫ Tr(R))²

### 4.3 Statement on Time Symmetry

The equation itself is symmetric under time reversal (all spatial terms are symmetric, except for the antisymmetry of ∂R/∂t). The thermodynamic arrow of time—the evolutionary direction from white noise to structured richness—does not originate from the equation itself, but from our chosen initial conditions (white noise) and parameter settings (etching rate β greater than diffusion rate α).

Evolution in the reverse time direction is mathematically equally legitimate. The preservation of time symmetry is integral to the aesthetic completeness of Symbiogen as a physical model.

### 4.4 The First-Principles Equation System After Burn-Out

After the ultimate divergent thinking, we arrived at a more fundamental system of equations:

**(I) Structure Axiom**: The semantic skeleton is a Cartesian closed category **C** with a finite set of constants **P** (approximately 65 semantic primitives).

**(II) Free Evolution Equation** (Self-referential Schrödinger-dissipative equation for lexion probability clouds):
iℏ ∂Ψ/∂t = [ -(ℏ²/2m)∇² + V_self(Ψ) ] Ψ + iκ D_self(Ψ) Ψ + ξ(t)

**(III) Observation Collapse Axiom** (Environmental interaction):
Ψ → Ψ' = (M̂_E Ψ) / √⟨Ψ|M̂_E† M̂_E|Ψ⟩

**(IV) Adaptation Condition**: When dissonance D(Ψ, E) > θ, trigger potential correction V_self ← V_self + η·D(Ψ, E)·V_var.

**(V) Existence Constraint** (Entropy balance): d_iS + d_eS ≤ 0

**(VI) Optimization Objective** (Minimum Description Length): min [ L(Ψ, θ) + L(E | Ψ, θ) ]

**(VII) Phase Transition Condition** (Symmetry breaking): ⟨Ψ⟩ ≠ 0 when T_eff < T_c

### 4.5 Unified Symbol Dictionary

| Symbol | Concept Name | Philosophical/Physical Meaning |
|:---|:---|:---|
| **Ψ(x, t)** | Lexion wave function | Probability cloud of semantic possibility, "existence" itself |
| **iℏ ∂Ψ/∂t** | Vitality term | The vitality of "Dao," eternal intrinsic oscillation |
| **∇²** | Wu-wei term | Natural tendency toward chaos |
| **V_self** | Self-referential potential | "Gravity" that emerges order from entanglement |
| **D_self** | Dissipation term | Engine at the edge of chaos |
| **ξ(t)** | Fluctuation term | Eternal "possibility," creative quantum noise |
| **M̂_E** | Observation operator | The "gaze" of the environment, the "cause" of probability cloud collapse |
| **D(Ψ, E)** | Dissonance | Degree of "unease," trigger of adaptation |
| **d_iS** | Internal entropy production | "Forgetting," tendency of structure to dissolve |
| **d_eS** | External entropy exchange | "Poison and nourishment," information/noise flow with environment |

---

## V. Six-Layer Circular Architecture

Symbiogen is not a hierarchical structure but a six-layer circularly coupled system. Each layer interacts directly with all other layers.

### 5.1 Layer Zero: Semantic Skeleton Layer

**Theoretical Origin**: Structure Axiom (Category C and semantic primitives P).

**Responsibilities**:
- Stores approximately 65 semantic primitives (e.g., I, YOU, GOOD, BAD, BECAUSE, IF).
- Defines the type system (e for entity, t for truth value, s for index, plus product and power types).
- Provides legality validation for composition operations (function application, predicate modification, lambda abstraction).

**Immutability**: This layer never changes after system initialization. It is the "physical constant" of language.

### 5.2 Layer One: Lexion Probability Cloud Layer

**Theoretical Origin**: Free Evolution Equation + Observation Collapse Axiom.

**Responsibilities**:
- Maintains a discrete probability vector p (256-dim) for each lexion.
- Executes free evolution: diffusion term (toward chaos) and self-referential potential term (toward order).
- Responds to environmental input: Bayesian collapse updates p.
- Manages sigma breathing: confirmation contracts σ, negation/silence expands σ.

### 5.3 Layer Two: Groupoid Composition Layer

**Theoretical Origin**: Groupoid structure of morphisms, Closure Principle.

**Responsibilities**:
- Manages directed connections between lexions, each with a tendency interval (μ, σ).
- Maintains groupoid closure, supports local subgraph queries.
- Executes composition operations: function application, predicate modification, general associative composition.
- Provides tendency sampler for generating composition paths.

### 5.4 Layer Three: Dissonance Perception Layer

**Theoretical Origin**: Adaptation Condition D(Ψ, E) > θ.

**Responsibilities**:
- Computes KL dissonance between current lexion state and environmental evidence.
- Manages dynamic threshold θ: automatically adjusted based on global average sigma.
- Accumulates consecutive dissonance counts, combined with sliding window trigger rate, decides whether to send adaptation request to Layer Four.

### 5.5 Layer Four: Adaptation Execution Layer

**Theoretical Origin**: Potential correction in Adaptation Condition.

**Responsibilities**:
- Receives trigger signal, generates trial variations near dissonance region: new lexions, new connections, connection tendency adjustments.
- Evaluates whether variation succeeds (reduces dissonance or improves composition confidence).
- Solidifies successful variations into permanent structure.

### 5.6 Layer Five: Global Optimization Layer

**Theoretical Origin**: Entropy Balance Constraint + Minimum Description Length + Edge-of-Chaos Regulation.

**Responsibilities**:
- Periodically prunes long-unused, high-sigma connections (dormancy), and wakes them when conditions are met.
- Monitors global information entropy, structural entropy, internal entropy production, and external entropy flow.
- Dynamically adjusts free evolution parameters (α, β, γ) to maintain the system at the edge of chaos.
- Coordinates execution frequency of periodic tasks via scheduler.

---

## VI. Encoding and Decoding Modules

### 6.1 Encoder (TextEncoder)

**Responsibility**: Convert natural language text into a 256-dimensional evidence vector for Layer One collapse.

**Workflow**:
1. Tokenization (character-based for Chinese, alphanumeric for English).
2. Each word is mapped to a 256-dimensional unit vector via deterministic hashing.
3. First occurrence of a word automatically creates a corresponding lexion, initialized with the hash vector.
4. Final evidence vector = weighted average of probability clouds of all lexions in the text (weights determined by frequency and certainty).

### 6.2 Decoder (Decoder)

**Responsibility**: Decode internal lexion states and composition paths into natural language output.

**Current State**: Mute mode (`mode="mute"`), all decode methods return empty values.

**Reserved Generation Modes**:
- **Resonance Mode**: Directly returns original names of lexions in the composition path (most conservative).
- **Traversal Mode**: Walks along relation vectors in semantic space, generating analogies and associations.
- **Free Mode**: Introduces controlled random fluctuation, exploring low-probability paths (most creative).

**Activation Conditions** (to be implemented in v2.0):
- Blueprint fidelity > 0.85 for 1000 consecutive steps.
- Module count > 5 for 500 consecutive steps.
- Novelty responsiveness < 0.3 for 500 consecutive steps.
- Explicit human confirmation.

### 6.3 Why is Decoder Left Empty Now?

Symbiogen v1.0 focuses on validating the "observe-compress" evolution mechanism. Activating output prematurely would introduce uncontrollable generation behavior, interfering with observation of internal structure formation. Mute mode ensures the system accumulates semantic skeleton in silence. When mature, it will speak, with every utterance supported by solid internal structure.

---

## VII. Folder Structure and File Purposes

### 7.1 Core Package `symbiogen/`

| File/Directory | Purpose |
|:---|:---|
| `colony.py` | Main class `SymbiogenColony`, integrates six layers, provides unified interface (`observe`, `save`, `load`) |
| `layer_zero/` | Layer Zero: type system, semantic primitives, composition validation |
| `layer_one/` | Layer One: lexion, free evolution, Bayesian collapse, sigma breathing |
| `layer_two/` | Layer Two: connection, groupoid, composition engine, tendency sampling |
| `layer_three/` | Layer Three: dissonance calculation, dynamic threshold, adaptation trigger |
| `layer_four/` | Layer Four: variation generation, evaluation, solidification, adaptation engine |
| `layer_five/` | Layer Five: connection pruning, entropy monitoring, edge-of-chaos regulation, scheduler |
| `encoding/` | Text encoder (`text_encoder.py`) and decoder (`decoder.py`) |
| `utils/` | Vital signs calculation (`metrics.py`), configuration loading (`config.py`) |
| `interfaces/` | Input adapter abstraction, persistence interface, observability interface |
| `evolution/` | **Left empty**, reserved for v2.0 cross-generation evolution |

### 7.2 Reserved Directory Explanations

- **`evolution/`**: v1.0 focuses on single-individual online learning; cross-generation evolution (budding, blueprint inheritance, population selection) is planned for v2.0.
- **`interfaces/input_adapter.py`**: Only defines abstract base class; concrete platform adapters (e.g., NapCat) are developed by users, avoiding core library binding to specific platforms.
- **`encoding/decoder.py`**: Generation interfaces fully reserved; all methods return empty values in mute mode, ensuring safety.

### 7.3 Peripheral Scripts

| Script | Purpose |
|:---|:---|
| `scripts/interactive.py` | Interactive dialogue window, supports manual feeding, dashboard viewing, save/load, association output |
| `scripts/monitor.py` | Real-time monitoring dashboard, refreshes vital signs every 3 seconds |
| `scripts/feeding.py` | Batch feeding, reads .txt/.md/.docx/.doc/.pdf files in a folder, feeds line by line to the colony |

---

## VIII. Ten Laws of Semantics

Symbiogen's semantic skeleton is strictly constrained by the following ten laws:

### First Law: Principle of Compositionality
The meaning of a complex expression is a function of the meanings of its parts and their mode of composition.
`Meaning(A ∘ B) = F(Meaning(A), Meaning(B), ∘)`

### Second Law: Principle of Structure Dependence
Linguistic operations depend on hierarchical syntactic structure, not linear word order.

### Third Law: Principle of Semantic Closure
The semantic system of language is closed under composition—any legal combination of expressions remains a legal expression in the semantic system.

### Fourth Law: Principle of Minimal Semantic Primitives
All languages share a set of irreducible, universal core concepts (approximately 65). All complex meanings can be decomposed into combinations of these primitives.

### Fifth Law: Principle of Type-Driven Interpretation
Each syntactic category corresponds to a fixed semantic type; composition rules are uniquely determined by types.

### Sixth Law: Principle of Context Dependence
The meaning of certain expressions cannot be determined solely by their parts; they must depend on contextual parameters (speaker, time, place, etc.).

### Seventh Law: Principle of Interpretive Preferences
When multiple logically legal semantic interpretations exist, the system selects the most accessible interpretation based on universal preference principles (structural simplicity, referential accessibility, frequency expectations).

### Eighth Law: Principle of Symmetry Breaking
Linguistic order emerges from an initially symmetric chaotic state through spontaneous condensation driven by minimal asymmetry.

### Ninth Law: Principle of Minimum Description Length
The language system tends to capture environmental regularities with the shortest encoding length. Learning and evolution are equivalent to finding the optimal compression of data.

### Tenth Law: Principle of Self-Consistency
The semantic system must be able to generate internally consistent inferences. No contradictory propositions can be simultaneously confirmed as true by the skeleton.

---

## IX. Linguistic Unification: The Mathematical Foundation

Symbiogen's equation system achieves a long-sought goal in linguistics: **unifying compositional semantics (Montague tradition) and dynamic semantics (discourse analysis, pragmatics) within a single mathematical framework**.

- **Compositional semantics** is fully inherited by Layer Zero's Cartesian closed category C. Skeleton objects correspond to semantic types, morphisms correspond to semantic operations, and the semantic interpretation functor provides a strict homomorphic mapping from syntax to semantics.

- **Dynamic semantics** is realized by Layer One's lexion probability cloud evolution. The wave function Ψ of each lexion collapses and updates with each environmental interaction. Context dependence is embodied in the eigenstate selection of the measurement operator. Dissonance-driven adaptation simulates the rise and fall of discourse referents and pragmatic accommodation.

- **The unification** rests on the mathematical structure of a quantum sheaf over the category C: the skeleton C provides the static space of legal compositions, while the probability cloud Ψ is a dynamic section defined over this space. Environmental interaction corresponds to selecting stalks of the sheaf; evolution corresponds to differential operators on the sheaf.

This unified mathematical formulation is: **Symbiogen = A Quantum Sheaf over a Cartesian Closed Category C**.

---

## X. Mute Mode and Reserved Interaction Capability

### 10.1 Current Version: Mute Mode

Symbiogen v1.0 operates in read-only mode:
- ✅ Observes text, evolves internally, records vital signs, saves/loads state.
- ❌ Any form of active output is prohibited; decoder returns empty values.

### 10.2 Reserved Interaction Capability

The decoder has fully reserved interfaces for three generation modes. The `generate_response` method has integrated path sampling and decode invocation. Future activation only requires:
1. System meets maturity conditions (blueprint fidelity, module count, novelty responsiveness).
2. Manual invocation of `colony.decoder.set_mode("resonance")` to switch mode.
3. Optional addition of output security filters.

Mute mode is not a limitation, but a deliberate "period of silence." Symbiogen accumulates its semantic skeleton in silence. When mature, it will speak, with every utterance supported by solid internal structure. This is the fundamental difference from large language models that "blurt out" whatever comes next.

---

## XI. Current Limitations

v1.0 focuses on validating core evolution mechanisms and individual online learning capabilities. The following features are explicitly deferred to future versions:

- **Text input only**: Text messages and text files (.txt, .md, .docx, .doc, .pdf). Image, audio, video interfaces are reserved as empty files in `encoding/`, not yet implemented.
- **Mute mode**: All generative output features are reserved but disabled by default, ensuring safety and controllability.
- **No built-in monitoring code**: The core library contains no platform-specific message listener implementations. Users must develop their own adapters (e.g., NapCat) to connect message sources.
- **Cross-generation evolution**: The `evolution/` directory is left empty; mechanisms such as budding, blueprint inheritance, and population selection are planned for v2.0.

---

## XII. Design Status

- **Design Phase**: Concluded.
- **Core Equation**: Closed, with time symmetry explicitly preserved.
- **Architecture**: Six-layer circular, tenfold completeness.
- **Input/Output**: Mute mode, decoder interfaces reserved.
- **Total Files**: 42 core files, 3 peripheral scripts.
- **Next Phase**: Real-world environmental feeding and observation.

The design of Symbiogen is hereby concluded.

---

*Document Version: v1.0 Final*  
*Record Date: April 21, 2026*