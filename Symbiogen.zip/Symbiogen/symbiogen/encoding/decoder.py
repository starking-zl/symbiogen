"""
解码器

将共生基因群的内部状态转化为自然语言输出。
当前版本为哑巴模式，解码器仅提供接口框架，
具体生成逻辑留待 v2.0 激活。
"""

import numpy as np

class Decoder:
    """内部状态到自然语言的解码器"""
    
    def __init__(self, lexicon=None, groupoid=None, composer=None):
        """
        参数:
            lexicon: 词元词典
            groupoid: 群胚管理器
            composer: 组合引擎
        """
        self.lexicon = lexicon
        self.groupoid = groupoid
        self.composer = composer
        
        # 解码模式
        self.mode = "mute"  # mute / resonance / traversal / free
    
    def set_mode(self, mode):
        """设置解码模式"""
        if mode in ["mute", "resonance", "traversal", "free"]:
            self.mode = mode
        else:
            raise ValueError(f"Unknown decode mode: {mode}")
    
    def decode_from_path(self, path):
        """
        从组合路径生成文本
        
        参数:
            path: 词元ID列表
        
        返回:
            text: 生成的文本（哑巴模式下返回空字符串）
        """
        if self.mode == "mute":
            return ""
        
        # 预留：共振模式、遍历模式、自由模式的实现
        if self.mode == "resonance":
            return self._decode_resonance(path)
        elif self.mode == "traversal":
            return self._decode_traversal(path)
        elif self.mode == "free":
            return self._decode_free(path)
        
        return ""
    
    def decode_from_vector(self, vector, top_k=5):
        """
        从证据向量生成文本
        
        参数:
            vector: 256维证据向量
            top_k: 返回最相关词元数量
        
        返回:
            words: 相关词元名称列表（哑巴模式下返回空列表）
        """
        if self.mode == "mute" or self.lexicon is None:
            return []
        
        # 计算所有词元与向量的相似度
        similarities = []
        for name, lex in self.lexicon.items():
            sim = np.dot(vector, lex.p) / (np.linalg.norm(vector) * np.linalg.norm(lex.p) + 1e-12)
            similarities.append((name, sim))
        
        similarities.sort(key=lambda x: x[1], reverse=True)
        return [name for name, _ in similarities[:top_k]]
    
    def _decode_resonance(self, path):
        """共振模式：直接返回路径中词元的原始名称"""
        if not path or self.lexicon is None:
            return ""
        words = []
        for lex_id in path:
            if lex_id in self.lexicon:
                name = self.lexicon[lex_id].name
                # 去除内部前缀
                if name.startswith("W:"):
                    words.append(name[2:])
                elif not name.isupper():  # 非语义原子
                    words.append(name)
        return " ".join(words)
    
    def _decode_traversal(self, path):
        """遍历模式：沿关系向量生成（预留）"""
        return self._decode_resonance(path)  # 暂时复用共振模式
    
    def _decode_free(self, path):
        """自由模式：开放生成（预留）"""
        return self._decode_resonance(path)  # 暂时复用共振模式
    
    def is_mute(self):
        """检查是否处于哑巴模式"""
        return self.mode == "mute"
    
    def get_status(self):
        """获取解码器状态"""
        return {
            "mode": self.mode,
            "lexicon_size": len(self.lexicon) if self.lexicon else 0
        }