import numpy as np
def regress(field, gamma=0.01):
    """
    蓝图回归：将曲率场向蓝图场 R₀ 拉回
    
    参数:
        field: CurvatureField 实例
        gamma: 回归强度
    """
    for pid, p in field.particles.items():
        target = field.blueprint.query(p.coordinate)
        p.curvature -= gamma * (p.curvature - target)