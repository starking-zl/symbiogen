"""
第二层：群组合层

本层负责：
- 管理词元之间的指向关系 (态射)
- 每条连接维护倾向区间 (mu_conn, sigma_conn)
- 执行组合运算 (函项应用、谓词修饰等)
- 维持群胚结构的封闭性

本层依赖第一层的词元概率云状态，并为第三层提供组合结果。
"""

from .connection import Connection
from .groupoid import Groupoid
from .composer import CompositionEngine
from .sampler import TendencySampler

__all__ = [
    "Connection",
    "Groupoid",
    "CompositionEngine",
    "TendencySampler"
]