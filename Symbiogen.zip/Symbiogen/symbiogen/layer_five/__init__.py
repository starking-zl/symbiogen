"""
第五层：全局优化层

本层负责系统的宏观调节：
- 周期性结构精简（连接休眠/唤醒）
- 全局熵产生监控
- 混沌边缘参数动态调节

本层依赖第一、二层的状态信息，并可通过第四层触发结构变更。
"""

from .pruning import ConnectionPruner
from .entropy import EntropyMonitor
from .edge_of_chaos import ChaosRegulator
from .scheduler import GlobalOptimizationScheduler

__all__ = [
    "ConnectionPruner",
    "EntropyMonitor",
    "ChaosRegulator",
    "GlobalOptimizationScheduler"
]