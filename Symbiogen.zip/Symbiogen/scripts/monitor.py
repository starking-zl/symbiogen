#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
实时监控仪表盘

每3秒刷新一次，显示共生基因群的完整生命体征。
数据源为 live_state.sym（由喂养窗口或交互窗口持续更新）。

使用方法：
    python scripts/monitor.py

按 Ctrl+C 退出。
"""

import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symbiogen import SymbiogenColony


def clear_screen():
    """清屏"""
    os.system('clear' if os.name == 'posix' else 'cls')


def format_number(n):
    """格式化大数字"""
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    elif n >= 1_000:
        return f"{n/1_000:.1f}K"
    else:
        return str(n)


def main():
    live_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "colonies", "live_state.sym")
    colony = SymbiogenColony()

    print("共生基因群实时监控已启动。等待 live_state.sym 文件...")
    print("按 Ctrl+C 退出。\n")

    try:
        while True:
            if os.path.exists(live_path):
                try:
                    colony.load(live_path)
                except Exception as e:
                    print(f"加载状态失败: {e}")
                    time.sleep(3)
                    continue

                # 获取生命体征
                vital = colony.export_vital_signs()
                status = colony.get_status()

                clear_screen()

                # 标题
                print("=" * 60)
                print(f"共生基因群 · 实时监控")
                print(f"运行步数: {vital['step']}  |  运行时长: {vital['uptime_hours']:.1f}h")
                print("-" * 60)

                # 词元与连接
                print(f"词元数量: {format_number(vital['lexicon_size'])}  "
                      f"活跃连接: {format_number(vital['active_connections'])}  "
                      f"休眠连接: {format_number(vital['dormant_connections'])}")

                # 离散度与阈值
                print(f"平均离散度: {vital['avg_sigma']:.3f}  |  动态阈值: {vital['threshold']:.3f}")

                # 熵状态
                print(f"信息熵: {vital['info_entropy']:.3f}  |  结构熵: {vital['structural_entropy']:.3f}  |  "
                      f"熵变化: {vital['total_entropy_change']:+.3f}")

                # 混沌边缘与顺应
                edge_status = "✓ 混沌边缘" if vital['in_chaos_edge'] else "○ 偏离边缘"
                print(f"状态: {edge_status}  |  顺应次数: {vital['adaptation_count']}")

                # 适应度（需要额外计算）
                from symbiogen.utils.metrics import compute_fitness, get_vital_signs
                signs = get_vital_signs(colony)
                fitness = compute_fitness(signs)
                print(f"适应度: {fitness:.4f}")

                # 解码器模式
                print(f"解码器模式: {status['decoder_mode']}")

                print("=" * 60)
                print("\n按 Ctrl+C 退出...")
            else:
                clear_screen()
                print("等待喂养窗口生成 live_state.sym 文件...")
                print(f"预期路径: {live_path}")

            time.sleep(3)

    except KeyboardInterrupt:
        print("\n监控已停止。")


if __name__ == "__main__":
    main()