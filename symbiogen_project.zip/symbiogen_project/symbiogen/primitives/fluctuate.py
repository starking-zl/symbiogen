import numpy as np

def fluctuate(field, delta=0.01):
    """
    随机涨落：注入噪声驱动探索
    
    参数:
        field: CurvatureField 实例
        delta: 噪声基础幅度
    """
    for pid, p in field.particles.items():
        # 噪声幅度与局部曲率成反比（平坦区域噪声大，峡谷区域噪声小）
        local_noise_scale = delta / (1.0 + abs(p.curvature))
        noise = np.random.randn() * local_noise_scale
        p.curvature += noise