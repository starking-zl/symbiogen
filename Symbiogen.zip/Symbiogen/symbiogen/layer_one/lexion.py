"""
词元类

每个词元维护其概率云状态：
- p: 256维离散概率向量，表示语义可能性分布
- mu: 相位中心，概率云的“重心”
- sigma: 离散度，概率云的不确定程度 (0, 1]
- phi: 相干性标量，简化版的相位信息
- freq: 使用频率计数
- primitive: 若该词元直接对应语义原子，则记录原子名称；否则为 None
"""

import numpy as np

class Lexion:
    """词元：语义概率云的基本单元"""
    
    def __init__(self, name, dimension=256, is_primitive=False, primitive_name=None):
        self.name = name
        self.dimension = dimension
        
        # 概率向量 (初始化为均匀分布或白噪声)
        self.p = np.ones(dimension) / dimension
        
        # 相位中心 (初始为随机单位向量)
        self.mu = np.random.randn(dimension)
        self.mu = self.mu / (np.linalg.norm(self.mu) + 1e-8)
        
        # 离散度 (初始为中等偏大，代表不确定)
        self.sigma = 0.5
        
        # 相干性 (简化相位，初始为低相干)
        self.phi = 0.1
        
        # 使用频率
        self.freq = 0
        
        # 年龄 (经历的坍缩次数)
        self.age = 0
        
        # 是否为语义原子
        self.is_primitive = is_primitive
        self.primitive_name = primitive_name
        
        # 最后激活时间 (用于休眠判断)
        self.last_activated = 0
        
        # 激活历史 (用于计算失谐度)
        self.activation_history = []
        
    def update_frequency(self):
        """增加使用频率"""
        self.freq += 1
        self.age += 1
    
    def record_activation(self, activation_value):
        """记录本次激活值，用于失谐计算"""
        self.activation_history.append(activation_value)
        if len(self.activation_history) > 100:
            self.activation_history = self.activation_history[-50:]
    
    def get_mean_activation(self):
        """获取近期平均激活值"""
        if not self.activation_history:
            return 0.0
        return np.mean(self.activation_history)
    
    def to_dict(self):
        """序列化为字典 (用于保存)"""
        return {
            "name": self.name,
            "p": self.p.tolist(),
            "mu": self.mu.tolist(),
            "sigma": self.sigma,
            "phi": self.phi,
            "freq": self.freq,
            "age": self.age,
            "is_primitive": self.is_primitive,
            "primitive_name": self.primitive_name,
            "last_activated": self.last_activated
        }
    
    @classmethod
    def from_dict(cls, data, dimension=256):
        """从字典反序列化"""
        lex = cls(data["name"], dimension, data["is_primitive"], data["primitive_name"])
        lex.p = np.array(data["p"])
        lex.mu = np.array(data["mu"])
        lex.sigma = data["sigma"]
        lex.phi = data["phi"]
        lex.freq = data["freq"]
        lex.age = data["age"]
        lex.last_activated = data["last_activated"]
        return lex
    
    def __repr__(self):
        prim_mark = "*" if self.is_primitive else ""
        return f"Lexion({self.name}{prim_mark}, σ={self.sigma:.3f}, freq={self.freq})"