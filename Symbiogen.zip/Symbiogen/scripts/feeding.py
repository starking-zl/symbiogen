#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
批量喂养脚本 (v2.0)

读取指定文件夹内的所有文本文件（支持 .txt, .md, .json, .csv, .docx, .doc, .pdf），
逐行或逐段喂给共生基因群。源文件不会被删除，仅读取内容。

使用方法：
    python scripts/feeding.py /path/to/your/text/folder

若未指定文件夹路径，则默认读取当前目录下的 `data/feeding/` 文件夹。
"""

import sys
import os
import subprocess
import tempfile

# 将项目根目录加入搜索路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from symbiogen import SymbiogenColony

def read_docx(file_path):
    """从 .docx 文件中提取文本"""
    try:
        from docx import Document
        doc = Document(file_path)
        full_text = []
        for para in doc.paragraphs:
            if para.text.strip():
                full_text.append(para.text.strip())
        return "\n".join(full_text)
    except ImportError:
        print("错误：未安装 python-docx。请运行 'pip install python-docx'")
        return ""

def read_doc(file_path):
    """从 .doc 文件中提取文本，使用 antiword 工具"""
    try:
        # 尝试使用 antiword
        result = subprocess.run(
            ['antiword', file_path],
            capture_output=True, text=True, check=False
        )
        if result.returncode == 0:
            return result.stdout.strip()
        else:
            print(f"antiword 提取失败: {result.stderr.strip()}")
            return ""
    except FileNotFoundError:
        print("错误：未安装 antiword。请运行 'pkg install antiword'")
        return ""

def read_pdf(file_path):
    """从 .pdf 文件中提取文本，使用 pypdfium2"""
    try:
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(file_path)
        full_text = []
        for page in pdf:
            textpage = page.get_textpage()
            full_text.append(textpage.get_text_range())
        return "\n".join(full_text)
    except ImportError:
        print("错误：未安装 pypdfium2。请运行 'pip install pypdfium2'")
        return ""

def read_text_files(folder_path):
    """读取文件夹内所有支持格式的文本文件"""
    supported_extensions = {
        '.txt', '.md', '.json', '.csv', '.log', '.text',
        '.docx', '.doc', '.pdf'
    }
    file_paths = []

    if not os.path.isdir(folder_path):
        print(f"错误：文件夹不存在 - {folder_path}")
        return []

    for root, dirs, files in os.walk(folder_path):
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in supported_extensions:
                full_path = os.path.join(root, file)
                file_paths.append(full_path)

    return file_paths

def feed_folder(colony, folder_path, verbose=True):
    """将文件夹内所有文本文件喂给基因群"""
    file_paths = read_text_files(folder_path)

    if not file_paths:
        print(f"在文件夹 {folder_path} 中未找到任何支持的文本文件。")
        return

    print(f"找到 {len(file_paths)} 个文本文件。")
    print("开始喂养...")

    for file_path in file_paths:
        ext = os.path.splitext(file_path)[1].lower()
        if verbose:
            print(f"\n正在处理: {os.path.basename(file_path)}")

        content = ""
        if ext == '.docx':
            content = read_docx(file_path)
        elif ext == '.doc':
            content = read_doc(file_path)
        elif ext == '.pdf':
            content = read_pdf(file_path)
        else: # 纯文本文件
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except Exception as e:
                print(f"  读取文件失败 {file_path}: {e}")
                continue

        if not content:
            continue

        # 按行喂给基因群，对于非纯文本文件，按段落（即换行符）分割可能更合适
        lines = content.splitlines()
        for line in lines:
            line = line.strip()
            if line:
                colony.observe(line)

        if verbose:
            status = colony.get_status()
            print(f"  完成，当前词元数 {status['lexicon_size']}")

    print(f"\n喂养完成。")
    status = colony.get_status()
    print(f"当前状态：步数 {status['step_counter']}，词元数 {status['lexicon_size']}，"
          f"连接数 {status['connection_count']}，总资源 {status['total_resource']:.2f}")


def main():
    # 解析命令行参数
    if len(sys.argv) > 1:
        folder_path = sys.argv[1]
    else:
        # 默认文件夹
        folder_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "feeding")

    # 确保文件夹存在，如果不存在则自动创建
    if not os.path.exists(folder_path):
        os.makedirs(folder_path, exist_ok=True)
        print(f"已创建默认喂养文件夹: {folder_path}")
        print("请将文本文件放入该文件夹后重新运行脚本。")
        return

    # 初始化基因群
    live_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "colonies", "live_state.sym")

    colony = SymbiogenColony()
    if os.path.exists(live_path):
        print(f"加载现有状态: {live_path}")
        colony.load(live_path)
        print(f"已加载，当前步数: {colony.step_counter}")
    else:
        print("未发现现有状态，从白噪声初始化。")

    # 执行喂养
    feed_folder(colony, folder_path)

    # 保存状态
    os.makedirs(os.path.dirname(live_path), exist_ok=True)
    colony.save(live_path)
    print(f"状态已保存至: {live_path}")


if __name__ == "__main__":
    main()