def select_best(individuals, survival_ratio=0.3):
    """
    选择适应度最高的个体。

    参数:
        individuals: 候选个体列表
        survival_ratio: 存活比例（保留用于接口一致性）

    返回:
        SymbiogenColony: 最优个体
    """
    if not individuals:
        return None

    sorted_inds = sorted(individuals, key=lambda x: x.fitness_score, reverse=True)
    return sorted_inds[0]


def select_top_k(individuals, k):
    """
    选择适应度最高的 k 个个体。

    参数:
        individuals: 候选个体列表
        k: 选择数量

    返回:
        list: 适应度最高的 k 个个体
    """
    if not individuals:
        return []
    sorted_inds = sorted(individuals, key=lambda x: x.fitness_score, reverse=True)
    return sorted_inds[:k]