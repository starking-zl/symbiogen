"""
第零层：语义骨架层

本层是共生基因群的静态根基，定义了：
- 语义类型系统 (e, t, s 及其组合)
- 通用语义原子集 (约65个)
- 合法组合规则 (函项应用、谓词修饰等)

本层在系统初始化后不可变，为上层提供类型查询和组合合法性验证。
"""

from .category import Category
from .types import TypeSystem, SemanticType
from .primitives import SemanticPrimitives
from .composition import Composer
from .validator import Validator

__all__ = [
    "Category",
    "TypeSystem",
    "SemanticType",
    "SemanticPrimitives",
    "Composer",
    "Validator"
]