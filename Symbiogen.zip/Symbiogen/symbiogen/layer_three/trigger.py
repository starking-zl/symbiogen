"""
顺应触发器

监测失谐度的连续模式，决定是否向第四层发送顺应请求。
采用连续触发计数、滑动窗口频率检查和冷却机制，避免过度顺应。
"""

import time
import numpy as np
from collections import deque

class AdaptationTrigger:
    """顺应触发引擎"""
    
    def __init__(self, 
                 consecutive_threshold=3,
                 cooldown_steps=50,
                 max_trigger_rate=0.1,
                 window_size=100):
        """
        参数:
            consecutive_threshold: 连续超过阈值的次数要求
            cooldown_steps: 触发后的冷却步数
            max_trigger_rate: 滑动窗口内的最大触发频率
            window_size: 滑动窗口大小 (步数)
        """
        self.consecutive_threshold = consecutive_threshold
        self.cooldown_steps = cooldown_steps
        self.max_trigger_rate = max_trigger_rate
        self.window_size = window_size
        
        # 状态变量
        self.consecutive_count = 0          # 连续超过阈值的次数
        self.steps_since_last_trigger = 0   # 上次触发后经过的步数
        self.total_triggers = 0             # 总触发次数 (仅用于统计)
        self.total_steps = 0                # 总交互步数
        
        # 滑动窗口触发记录：记录最近 window_size 步内每步是否触发
        self.trigger_window = deque(maxlen=window_size)
        
        # 历史失谐度 (用于趋势分析)
        self.dissonance_history = []
        
        # 上次触发时间
        self.last_trigger_time = time.time()
    
    def update(self, dissonance, threshold):
        """
        更新状态并判断是否触发顺应
        
        参数:
            dissonance: 当前失谐度
            threshold: 当前阈值
        
        返回:
            should_trigger: 是否应触发顺应
            trigger_info: 触发信息字典 (若触发)
        """
        self.total_steps += 1
        self.steps_since_last_trigger += 1
        
        # 记录历史
        self.dissonance_history.append(dissonance)
        if len(self.dissonance_history) > 100:
            self.dissonance_history = self.dissonance_history[-50:]
        
        # 检查是否超过阈值
        triggered_this_step = False
        if dissonance > threshold:
            self.consecutive_count += 1
        else:
            self.consecutive_count = 0
        
        # 判断是否满足触发条件
        should_trigger = False
        trigger_info = None
        
        if self._meets_trigger_conditions():
            should_trigger = True
            triggered_this_step = True
            trigger_info = self._prepare_trigger_info(dissonance, threshold)
            self._reset_after_trigger()
        
        # 无论是否触发，都将本步的触发状态记录到滑动窗口
        self.trigger_window.append(1 if triggered_this_step else 0)
        
        return should_trigger, trigger_info
    
    def _meets_trigger_conditions(self):
        """检查是否满足所有触发条件"""
        # 条件1：连续超过阈值次数达标
        if self.consecutive_count < self.consecutive_threshold:
            return False
        
        # 条件2：冷却期已过
        if self.steps_since_last_trigger < self.cooldown_steps:
            return False
        
        # 条件3：滑动窗口内的触发频率未超过上限
        if len(self.trigger_window) > 0:
            recent_triggers = sum(self.trigger_window)
            recent_rate = recent_triggers / len(self.trigger_window)
            if recent_rate >= self.max_trigger_rate:
                return False
        
        return True
    
    def _prepare_trigger_info(self, dissonance, threshold):
        """准备触发信息"""
        # 计算失谐度的趋势
        trend = self._compute_dissonance_trend()
        
        # 计算严重程度
        severity = min(1.0, dissonance / (threshold + 1e-6) - 1.0)
        
        return {
            "dissonance": dissonance,
            "threshold": threshold,
            "severity": severity,
            "trend": trend,
            "consecutive_count": self.consecutive_count,
            "timestamp": time.time()
        }
    
    def _compute_dissonance_trend(self):
        """计算失谐度的近期趋势"""
        if len(self.dissonance_history) < 5:
            return "stable"
        
        recent = self.dissonance_history[-5:]
        # 简单线性回归斜率
        x = np.arange(len(recent))
        slope = np.polyfit(x, recent, 1)[0]
        
        if slope > 0.01:
            return "increasing"
        elif slope < -0.01:
            return "decreasing"
        else:
            return "stable"
    
    def _reset_after_trigger(self):
        """触发后重置状态"""
        self.consecutive_count = 0
        self.steps_since_last_trigger = 0
        self.total_triggers += 1
        self.last_trigger_time = time.time()
    
    def force_trigger(self, dissonance, threshold):
        """强制触发 (用于外部干预)"""
        trigger_info = self._prepare_trigger_info(dissonance, threshold)
        self._reset_after_trigger()
        self.trigger_window.append(1)  # 记录本次强制触发
        return trigger_info
    
    def get_statistics(self):
        """获取触发统计信息"""
        recent_triggers = sum(self.trigger_window) if self.trigger_window else 0
        recent_rate = recent_triggers / len(self.trigger_window) if self.trigger_window else 0.0
        
        return {
            "total_triggers": self.total_triggers,
            "total_steps": self.total_steps,
            "global_trigger_rate": self.total_triggers / max(1, self.total_steps),
            "recent_trigger_rate": recent_rate,
            "window_size": len(self.trigger_window),
            "consecutive_count": self.consecutive_count,
            "steps_since_last": self.steps_since_last_trigger,
            "dissonance_mean": np.mean(self.dissonance_history) if self.dissonance_history else 0.0
        }
    
    def to_dict(self):
        """序列化"""
        return {
            "consecutive_threshold": self.consecutive_threshold,
            "cooldown_steps": self.cooldown_steps,
            "max_trigger_rate": self.max_trigger_rate,
            "window_size": self.window_size,
            "consecutive_count": self.consecutive_count,
            "steps_since_last_trigger": self.steps_since_last_trigger,
            "total_triggers": self.total_triggers,
            "total_steps": self.total_steps,
            "trigger_window": list(self.trigger_window),
            "dissonance_history": self.dissonance_history,
            "last_trigger_time": self.last_trigger_time
        }
    
    @classmethod
    def from_dict(cls, data):
        """反序列化"""
        at = cls(
            consecutive_threshold=data["consecutive_threshold"],
            cooldown_steps=data["cooldown_steps"],
            max_trigger_rate=data["max_trigger_rate"],
            window_size=data.get("window_size", 100)
        )
        at.consecutive_count = data["consecutive_count"]
        at.steps_since_last_trigger = data["steps_since_last_trigger"]
        at.total_triggers = data["total_triggers"]
        at.total_steps = data["total_steps"]
        at.trigger_window = deque(data["trigger_window"], maxlen=at.window_size)
        at.dissonance_history = data["dissonance_history"]
        at.last_trigger_time = data["last_trigger_time"]
        return at