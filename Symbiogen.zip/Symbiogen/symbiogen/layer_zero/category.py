"""
笛卡尔闭范畴的基础设施

定义了对象（语义类型）和态射（语义运算）的抽象结构。
本实现为简化版，仅保留组合性语义学所需的核心概念。
"""

class Category:
    """
    语义骨架的范畴论模型。
    
    对象 Ob(C): 语义类型 (e, t, s 及其积和幂)
    态射 Hom(C): 语义运算 (函项应用、谓词修饰等)
    """
    
    def __init__(self):
        self._objects = set()
        self._hom = {}  # (src, tgt) -> list of morphism names
    
    def add_object(self, obj):
        """添加语义类型对象"""
        self._objects.add(obj)
    
    def has_object(self, obj):
        """检查对象是否存在"""
        return obj in self._objects
    
    def add_morphism(self, src, tgt, name):
        """添加态射（语义运算）"""
        key = (src, tgt)
        if key not in self._hom:
            self._hom[key] = []
        self._hom[key].append(name)
    
    def get_morphisms(self, src, tgt):
        """获取从 src 到 tgt 的所有态射"""
        return self._hom.get((src, tgt), [])
    
    def is_legal_composition(self, src, tgt):
        """检查是否存在从 src 到 tgt 的合法态射"""
        return (src, tgt) in self._hom
    
    def __repr__(self):
        return f"Category(objects={len(self._objects)}, morphisms={sum(len(v) for v in self._hom.values())})"