from setuptools import setup, find_packages

setup(
    name="symbiogen",
    version="1.0.0-alpha",
    author="Symbiogen Contributors",
    description="共生基因群 - 一个能从群聊环境中自主生长出通用语言骨架的数字生命",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/你的用户名/symbiogen",
    packages=find_packages(exclude=["tests", "scripts", "docs"]),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
    ],
)