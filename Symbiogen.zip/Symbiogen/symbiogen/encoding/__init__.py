"""
编码模块

将外部输入（文本、图像、音频等）转化为共生基因群可理解的证据向量，
并将内部状态解码为自然语言输出。
当前版本仅实现文本编码，解码器处于哑巴模式。
"""

from .text_encoder import TextEncoder
from .decoder import Decoder

__all__ = ["TextEncoder", "Decoder"]