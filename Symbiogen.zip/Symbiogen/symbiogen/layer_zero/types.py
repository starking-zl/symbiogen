"""
语义类型系统

定义了基本类型 e (实体)、t (真值)、s (世界-时间索引) 及其组合规则。
支持积类型 (×) 和幂类型 (→) 的构造。
"""

class SemanticType:
    """语义类型的抽象基类"""
    
    def __init__(self, name):
        self.name = name
    
    def __eq__(self, other):
        if not isinstance(other, SemanticType):
            return False
        return self.name == other.name
    
    def __hash__(self):
        return hash(self.name)
    
    def __repr__(self):
        return self.name


class AtomicType(SemanticType):
    """原子类型：e, t, s"""
    pass


class ProductType(SemanticType):
    """积类型：A × B"""
    
    def __init__(self, left, right):
        self.left = left
        self.right = right
        super().__init__(f"({left.name}×{right.name})")


class PowerType(SemanticType):
    """幂类型：A → B (函数类型)"""
    
    def __init__(self, domain, codomain):
        self.domain = domain
        self.codomain = codomain
        super().__init__(f"({domain.name}→{codomain.name})")


class TypeSystem:
    """
    类型系统管理器
    
    维护所有合法类型，并提供类型构造与查询功能。
    """
    
    # 三个原子类型
    TYPE_E = AtomicType("e")   # 实体
    TYPE_T = AtomicType("t")   # 真值
    TYPE_S = AtomicType("s")   # 世界-时间索引
    
    def __init__(self):
        self._types = set()
        self._register_atomic_types()
    
    def _register_atomic_types(self):
        """注册原子类型"""
        self._types.add(self.TYPE_E)
        self._types.add(self.TYPE_T)
        self._types.add(self.TYPE_S)
    
    def make_product(self, type_a, type_b):
        """构造积类型 A × B"""
        prod = ProductType(type_a, type_b)
        self._types.add(prod)
        return prod
    
    def make_power(self, domain, codomain):
        """构造幂类型 A → B (函数类型)"""
        power = PowerType(domain, codomain)
        self._types.add(power)
        return power
    
    def is_valid_type(self, t):
        """检查类型是否合法"""
        return t in self._types
    
    def get_atomic_types(self):
        """返回所有原子类型"""
        return [self.TYPE_E, self.TYPE_T, self.TYPE_S]
    
    def get_type_by_name(self, name):
        """根据名称查找类型"""
        for t in self._types:
            if t.name == name:
                return t
        return None