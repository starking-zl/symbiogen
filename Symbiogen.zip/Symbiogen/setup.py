#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
共生基因群 · Symbiogen 安装脚本
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="symbiogen",
    version="1.0.0-alpha",
    author="Symbiogen Contributors",
    description="共生基因群 - 一个从群聊环境中自主学习、呼吸演化的数字生命",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/starking-zl/symbiogen",
    packages=find_packages(exclude=["tests", "tests.*", "scripts", "data", "docs"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "python-docx>=0.8.11",
        "pypdfium2>=4.30.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "symbiogen-interactive=scripts.interactive:main",
            "symbiogen-monitor=scripts.monitor:main",
            "symbiogen-feeding=scripts.feeding:main",
        ],
    },
)