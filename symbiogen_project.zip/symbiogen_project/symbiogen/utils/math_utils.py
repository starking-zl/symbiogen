import numpy as np

def compute_distance(coord1, coord2):
    """计算两点间欧氏距离"""
    return np.linalg.norm(np.array(coord1) - np.array(coord2))

def compute_laplacian(field, particle_id):
    """计算粒子在曲率场上的离散拉普拉斯"""
    particle = field.particles.get(particle_id)
    if not particle:
        return 0.0
    
    neighbors = field.get_neighbors(particle_id)
    if not neighbors:
        return 0.0
    
    neighbor_curvatures = []
    for nid in neighbors:
        neighbor = field.particles.get(nid)
        if neighbor:
            neighbor_curvatures.append(neighbor.curvature)
    
    if not neighbor_curvatures:
        return 0.0
    
    return np.mean(neighbor_curvatures) - particle.curvature

def normalize_vector(vec):
    """向量归一化"""
    norm = np.linalg.norm(vec)
    if norm == 0:
        return vec
    return vec / norm

def cosine_similarity(vec1, vec2):
    """余弦相似度"""
    v1 = np.array(vec1)
    v2 = np.array(vec2)
    norm1 = np.linalg.norm(v1)
    norm2 = np.linalg.norm(v2)
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return np.dot(v1, v2) / (norm1 * norm2)