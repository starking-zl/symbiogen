"""
熵监控器

监控系统的全局熵产生，评估系统是否处于健康状态。
基于信息熵和热力学熵的混合度量。
"""

import numpy as np
import time

class EntropyMonitor:
    """熵监控引擎"""
    
    def __init__(self, window_size=100):
        """
        参数:
            window_size: 滑动窗口大小（用于计算熵产生率）
        """
        self.window_size = window_size
        
        # 历史记录
        self.total_entropy_history = []
        self.internal_entropy_history = []
        self.external_entropy_history = []
        self.timestamps = []
        
        # 统计
        self.alert_count = 0
        self.last_alert_time = None
    
    def compute_lexicon_entropy(self, lexicon):
        """
        计算词元集合的信息熵
        
        熵 S = -Σ p_i log p_i，对所有词元的概率云取平均
        """
        if not lexicon:
            return 0.0
        
        total_entropy = 0.0
        for lex in lexicon.values():
            p = lex.p
            # 计算该词元的熵
            ent = -np.sum(p * np.log(p + 1e-12))
            total_entropy += ent
        
        return total_entropy / len(lexicon)
    
    def compute_structural_entropy(self, groupoid):
        """
        计算结构熵：基于连接分布的熵
        
        结构熵反映连接模式的复杂程度。
        """
        connections = groupoid.get_all_connections(include_dormant=False)
        if not connections:
            return 0.0
        
        # 统计每个词元的出度分布
        out_degrees = {}
        for conn in connections:
            out_degrees[conn.source_id] = out_degrees.get(conn.source_id, 0) + 1
        
        if not out_degrees:
            return 0.0
        
        # 计算度分布的熵
        degrees = list(out_degrees.values())
        degree_counts = {}
        for d in degrees:
            degree_counts[d] = degree_counts.get(d, 0) + 1
        
        total = len(degrees)
        ent = 0.0
        for count in degree_counts.values():
            p = count / total
            ent -= p * np.log(p)
        
        return ent
    
    def compute_internal_entropy_production(self, lexicon, groupoid):
        """
        估算内部熵产生 d_iS
        
        基于词元离散度的变化率和连接的新陈代谢。
        """
        # 简化模型：内部熵产生正比于平均离散度
        if not lexicon:
            return 0.0
        
        avg_sigma = np.mean([lex.sigma for lex in lexicon.values()])
        
        # 活跃连接数的影响
        active_conns = groupoid.total_connections(include_dormant=False)
        total_conns = groupoid.total_connections(include_dormant=True)
        if total_conns > 0:
            dormancy_ratio = 1.0 - (active_conns / total_conns)
        else:
            dormancy_ratio = 0.0
        
        # 内部熵产生 = 基础代谢 + 结构维护成本
        diS = avg_sigma * 0.5 + dormancy_ratio * 0.3
        
        return diS
    
    def compute_external_entropy_flow(self, recent_dissonance):
        """
        估算外部熵流 d_eS
        
        基于近期的平均失谐度。失谐度高意味着负熵流入不足。
        """
        # 负熵流入 = -失谐度（失谐度越高，负熵流入越少）
        deS = -recent_dissonance * 0.8
        return deS
    
    def update(self, lexicon, groupoid, recent_dissonance):
        """
        更新熵状态
        
        参数:
            lexicon: 词元词典
            groupoid: 群胚管理器
            recent_dissonance: 近期的平均失谐度
        
        返回:
            entropy_report: 熵状态报告
        """
        # 计算各项熵
        info_entropy = self.compute_lexicon_entropy(lexicon)
        struct_entropy = self.compute_structural_entropy(groupoid)
        diS = self.compute_internal_entropy_production(lexicon, groupoid)
        deS = self.compute_external_entropy_flow(recent_dissonance)
        dS_total = diS + deS
        
        # 记录历史
        current_time = time.time()
        self.total_entropy_history.append(dS_total)
        self.internal_entropy_history.append(diS)
        self.external_entropy_history.append(deS)
        self.timestamps.append(current_time)
        
        # 限制历史长度
        if len(self.total_entropy_history) > self.window_size:
            self.total_entropy_history = self.total_entropy_history[-self.window_size:]
            self.internal_entropy_history = self.internal_entropy_history[-self.window_size:]
            self.external_entropy_history = self.external_entropy_history[-self.window_size:]
            self.timestamps = self.timestamps[-self.window_size:]
        
        # 判断是否需要警报
        alert = self._check_alert(dS_total, diS, deS)
        if alert:
            self.alert_count += 1
            self.last_alert_time = current_time
        
        return {
            "info_entropy": info_entropy,
            "structural_entropy": struct_entropy,
            "internal_entropy": diS,
            "external_entropy": deS,
            "total_entropy_change": dS_total,
            "alert": alert,
            "alert_level": self._alert_level(dS_total)
        }
    
    def _check_alert(self, dS_total, diS, deS):
        """检查是否需要警报"""
        # 警报条件1：总熵持续增长
        if len(self.total_entropy_history) >= 10:
            recent_trend = np.mean(self.total_entropy_history[-10:])
            if recent_trend > 0.05:
                return True
        
        # 警报条件2：内部熵产生过高
        if diS > 0.7:
            return True
        
        # 警报条件3：外部负熵流入严重不足
        if deS > 0.3:
            return True
        
        return False
    
    def _alert_level(self, dS_total):
        """判断警报级别"""
        if dS_total > 0.1:
            return "high"
        elif dS_total > 0.05:
            return "medium"
        elif dS_total > 0:
            return "low"
        else:
            return "none"
    
    def get_trend(self):
        """获取熵变化趋势"""
        if len(self.total_entropy_history) < 5:
            return "stable"
        
        recent = self.total_entropy_history[-5:]
        x = np.arange(len(recent))
        slope = np.polyfit(x, recent, 1)[0]
        
        if slope > 0.01:
            return "increasing"
        elif slope < -0.01:
            return "decreasing"
        else:
            return "stable"
    
    def get_statistics(self):
        """获取统计信息"""
        return {
            "mean_total_entropy": np.mean(self.total_entropy_history) if self.total_entropy_history else 0.0,
            "mean_internal_entropy": np.mean(self.internal_entropy_history) if self.internal_entropy_history else 0.0,
            "mean_external_entropy": np.mean(self.external_entropy_history) if self.external_entropy_history else 0.0,
            "trend": self.get_trend(),
            "alert_count": self.alert_count
        }