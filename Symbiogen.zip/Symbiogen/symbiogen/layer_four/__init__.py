"""
第四层：顺应执行层

本层负责：
- 接收失谐感知层的顺应触发信号
- 在失谐区域附近生成试探性变异（新词元、新指向、倾向区间调整）
- 评估变异是否“成功”（是否降低了后续失谐度）
- 将成功的变异固化为永久结构

本层依赖第一层的词元管理、第二层的群胚管理，并为第五层报告结构变更。
"""

from .variation import VariationGenerator
from .evaluate import VariationEvaluator
from .solidify import VariationSolidifier
from .adaptation_engine import AdaptationEngine

__all__ = [
    "VariationGenerator",
    "VariationEvaluator", 
    "VariationSolidifier",
    "AdaptationEngine"
]