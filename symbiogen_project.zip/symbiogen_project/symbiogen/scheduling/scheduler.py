from symbiogen.scheduling.phase_clock import PhaseClock

class Scheduler:
    """时间调度器：协调五层在对应相位执行"""
    
    def __init__(self, field, layers_config=None):
        self.field = field
        self.clock = PhaseClock()
        
        # 导入各层
        from symbiogen.layers.etching import EtchingLayer
        from symbiogen.layers.diffusion import DiffusionLayer
        from symbiogen.layers.regression import RegressionLayer
        from symbiogen.layers.fluctuation import FluctuationLayer
        from symbiogen.layers.time_layer import TimeLayer
        
        config = layers_config or {}
        
        self.etching_layer = EtchingLayer(field, config.get("etching"))
        self.diffusion_layer = DiffusionLayer(field, config.get("diffusion"))
        self.regression_layer = RegressionLayer(field, config.get("regression"))
        self.fluctuation_layer = FluctuationLayer(field, config.get("fluctuation"))
        self.time_layer = TimeLayer(field, config.get("time_layer"))
    
    def step(self, delta=0.05):
        """执行一个时间步"""
        self.clock.tick(delta)
        phase_name = self.clock.get_current_phase_name()
        
        if phase_name == "etching":
            self.etching_layer.run()
        elif phase_name == "diffusion_1":
            self.diffusion_layer.run()
        elif phase_name == "fluctuation":
            self.fluctuation_layer.run()
        elif phase_name == "diffusion_2":
            self.diffusion_layer.run()
        elif phase_name == "regression":
            self.regression_layer.run()
        elif phase_name == "time_layer":
            return self.time_layer.run()
        
        return None
    
    def run_full_cycle(self):
        """运行一个完整周期（0.0 到 1.0）"""
        steps = int(1.0 / 0.05)
        results = []
        for _ in range(steps):
            result = self.step()
            if result:
                results.append(result)
        return results