"""
变异生成器

在失谐区域附近生成试探性变异：
- 创建新词元（当失谐无法被任何已有词元吸收时）
- 创建新指向（当两个词元需要建立新的组合关系时）
- 调整倾向区间（当已有指向需要改变权重时）
"""

import numpy as np

class VariationGenerator:
    """变异生成引擎"""
    
    def __init__(self, variation_rate=0.1, max_variations_per_trigger=5):
        """
        参数:
            variation_rate: 变异率，控制变异的幅度
            max_variations_per_trigger: 每次触发最多生成的变异数量
        """
        self.variation_rate = variation_rate
        self.max_variations_per_trigger = max_variations_per_trigger
        
    def generate_variations(self, trigger_info, lexicon, groupoid, dissonance_calculator, 
                           affected_lexions=None, evidence_vector=None):
        """
        根据触发信息生成试探性变异
        
        参数:
            trigger_info: 来自第三层的触发信息字典
            lexicon: 词元词典 {name: Lexion}
            groupoid: 群胚管理器
            dissonance_calculator: 失谐度计算器（用于评估变异）
            affected_lexions: 受影响的词元名称列表（若为None则自动识别）
            evidence_vector: 触发顺应的环境证据向量
        
        返回:
            variations: 变异列表，每个变异是一个字典
        """
        variations = []
        
        # 识别受影响的词元
        if affected_lexions is None:
            affected_lexions = self._identify_affected_lexions(lexicon, evidence_vector)
        
        # 根据失谐严重程度决定变异强度
        severity = trigger_info.get("severity", 0.5)
        
        # 生成变异
        for lex_name in affected_lexions[:self.max_variations_per_trigger]:
            if lex_name not in lexicon:
                continue
                
            lex = lexicon[lex_name]
            
            # 变异类型1：创建新词元（如果失谐严重）
            if severity > 0.5 and evidence_vector is not None:
                new_lex_variation = self._create_new_lexion_variation(
                    lex, evidence_vector, severity
                )
                if new_lex_variation:
                    variations.append(new_lex_variation)
            
            # 变异类型2：创建新指向
            connection_variations = self._create_connection_variations(
                lex, lexicon, groupoid, severity
            )
            variations.extend(connection_variations)
            
            # 变异类型3：调整已有指向的倾向区间
            adjustment_variations = self._adjust_existing_connections(
                lex, groupoid, severity
            )
            variations.extend(adjustment_variations)
        
        # 限制变异总数
        return variations[:self.max_variations_per_trigger]
    
    def _identify_affected_lexions(self, lexicon, evidence_vector):
        """识别受环境输入影响最大的词元"""
        if not lexicon:
            return []
            
        # 若没有证据向量，返回所有词元中离散度较低（较为确定）的词元
        if evidence_vector is None:
            sorted_lex = sorted(lexicon.items(), key=lambda x: x[1].sigma)
            return [name for name, _ in sorted_lex[:5]]
        
        # 计算每个词元与证据向量的相似度
        similarities = {}
        for name, lex in lexicon.items():
            sim = np.dot(evidence_vector, lex.p) / (np.linalg.norm(evidence_vector) * 
                                                    np.linalg.norm(lex.p) + 1e-8)
            similarities[name] = sim
        
        # 返回相似度最高的几个词元
        sorted_names = sorted(similarities.keys(), key=lambda n: similarities[n], reverse=True)
        return sorted_names[:5]
    
    def _create_new_lexion_variation(self, parent_lex, evidence_vector, severity):
        """生成创建新词元的变异"""
        # 检查是否真的需要新词元（证据与父词元的差异足够大）
        similarity = np.dot(evidence_vector, parent_lex.p) / (np.linalg.norm(evidence_vector) * 
                                                               np.linalg.norm(parent_lex.p) + 1e-8)
        if similarity > 0.7:  # 已经足够相似，不需要新词元
            return None
        
        # 新词元的概率云：父词元与证据向量的加权平均
        alpha = self.variation_rate * severity
        new_p = (1 - alpha) * parent_lex.p + alpha * evidence_vector
        new_p = new_p / np.sum(new_p)
        
        return {
            "type": "new_lexion",
            "parent_name": parent_lex.name,
            "new_p": new_p,
            "initial_sigma": 0.6,  # 新词元初始离散度较高
            "severity": severity
        }
    
    def _create_connection_variations(self, lex, lexicon, groupoid, severity):
        """生成创建新连接的变异"""
        variations = []
        
        # 找出与当前词元可能相关的其他词元
        candidates = []
        for other_name, other_lex in lexicon.items():
            if other_name == lex.name:
                continue
            
            # 检查是否已存在连接
            existing = groupoid.get_connection(lex.name, other_name)
            if existing is not None:
                continue
            
            # 计算潜在相关性（概率云的相似度）
            similarity = np.dot(lex.p, other_lex.p) / (np.linalg.norm(lex.p) * 
                                                       np.linalg.norm(other_lex.p) + 1e-8)
            if similarity > 0.3:
                candidates.append((other_name, similarity))
        
        # 按相似度排序，取前几个
        candidates.sort(key=lambda x: x[1], reverse=True)
        for other_name, sim in candidates[:3]:
            variations.append({
                "type": "new_connection",
                "source_name": lex.name,
                "target_name": other_name,
                "initial_mu": sim * self.variation_rate * severity,
                "initial_sigma": 0.5,
                "connection_type": "association"
            })
        
        return variations
    
    def _adjust_existing_connections(self, lex, groupoid, severity):
        """生成调整已有连接的变异"""
        variations = []
        
        # 获取该词元的所有出向连接
        outgoing = groupoid.get_outgoing(lex.name, include_dormant=False)
        
        for conn in outgoing[:3]:  # 最多调整3条连接
            # 调整倾向中心：向绝对值增大的方向微移（强化现有倾向）
            # 使用 1 - |mu| 确保无论正负，都向极值方向调整
            delta_mu = self.variation_rate * severity * (1.0 - abs(conn.mu))
            # 调整离散度：略微收缩
            delta_sigma = -0.01 * severity * conn.sigma
            
            variations.append({
                "type": "adjust_connection",
                "connection": conn,
                "delta_mu": delta_mu,
                "delta_sigma": delta_sigma,
                "severity": severity
            })
        
        return variations