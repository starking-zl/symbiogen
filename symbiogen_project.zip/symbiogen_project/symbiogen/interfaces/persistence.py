import os
import pickle
from datetime import datetime

def save_colony(colony, filepath):
    """保存共生基因群完整状态"""
    colony.field.save(filepath)

def load_colony(filepath):
    """加载共生基因群状态"""
    from symbiogen.colony import SymbiogenColony
    colony = SymbiogenColony()
    colony.field.load(filepath)
    return colony

def save_blueprint(colony, filepath):
    """单独保存蓝图场（基因组种子）"""
    with open(filepath, 'wb') as f:
        pickle.dump(colony.field.blueprint.to_dict(), f)

def load_blueprint(filepath):
    """加载蓝图场"""
    from symbiogen.data.blueprint import Blueprint
    with open(filepath, 'rb') as f:
        data = pickle.load(f)
    return Blueprint.from_dict(data)