"""通用工具模块"""
from .metrics import (
    total_resource, particle_count, module_count,
    curvature_variance, blueprint_fidelity, novelty_responsiveness,
    compute_fitness, get_vital_signs
)
from .config import load_config, save_config

__all__ = [
    "total_resource", "particle_count", "module_count",
    "curvature_variance", "blueprint_fidelity", "novelty_responsiveness",
    "compute_fitness", "get_vital_signs",
    "load_config", "save_config"
]