class Layer:
    """五层架构的抽象基类"""
    
    def __init__(self, field, config=None):
        self.field = field
        self.config = config or {}
        self.name = self.__class__.__name__
    
    def run(self, **kwargs):
        """执行层的主要逻辑，子类必须实现"""
        raise NotImplementedError