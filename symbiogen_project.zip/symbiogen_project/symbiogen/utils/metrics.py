import numpy as np


def total_resource(field):
    """总资源"""
    return sum(p.resource for p in field.particles.values())


def particle_count(field):
    """粒子数"""
    return len(field.particles)


def module_count(field):
    """模块数（连通分量数量）"""
    if not field.particles:
        return 0

    visited = set()
    modules = 0

    def dfs(pid):
        stack = [pid]
        while stack:
            curr = stack.pop()
            if curr in visited:
                continue
            visited.add(curr)
            for nid in field.get_neighbors(curr):
                if nid not in visited:
                    stack.append(nid)

    for pid in field.particles:
        if pid not in visited:
            dfs(pid)
            modules += 1

    return modules


def curvature_variance(field):
    """平均曲率方差"""
    if not field.particles:
        return 0.0
    curvatures = [p.curvature for p in field.particles.values()]
    return np.var(curvatures)


def blueprint_fidelity(field):
    """蓝图吻合度"""
    if not field.particles:
        return 1.0

    total_diff = 0.0
    for p in field.particles.values():
        target = field.blueprint.query(p.coordinate)
        total_diff += abs(p.curvature - target)

    avg_diff = total_diff / len(field.particles)
    return max(0.0, 1.0 - avg_diff)


def novelty_responsiveness(field):
    """新奇响应度（基于激活方差）"""
    if not field.particles:
        return 0.0
    return np.mean([p.activation_var for p in field.particles.values()])


def get_vital_signs(field):
    """获取所有生命体征"""
    return {
        "total_resource": total_resource(field),
        "particle_count": particle_count(field),
        "module_count": module_count(field),
        "curvature_variance": curvature_variance(field),
        "blueprint_fidelity": blueprint_fidelity(field),
        "novelty_responsiveness": novelty_responsiveness(field),
    }


def compute_fitness(vital_signs):
    """
    计算适应度分数。

    适应度综合评估个体的：结构稳定性、资源效率、模块化程度。
    分数范围 0.0 ~ 1.0。

    参数:
        vital_signs: get_vital_signs() 返回的字典

    返回:
        float: 适应度分数
    """
    weights = {
        "blueprint_fidelity": 0.35,
        "module_count": 0.25,
        "curvature_variance": 0.20,
        "novelty_responsiveness": 0.20,
    }

    normalized = {
        "blueprint_fidelity": vital_signs.get("blueprint_fidelity", 0.5),
        "module_count": min(vital_signs.get("module_count", 5) / 20.0, 1.0),
        "curvature_variance": min(vital_signs.get("curvature_variance", 0.1) / 0.5, 1.0),
        "novelty_responsiveness": min(vital_signs.get("novelty_responsiveness", 0.1) / 0.3, 1.0),
    }

    fitness = sum(weights[k] * normalized[k] for k in weights)
    return min(max(fitness, 0.0), 1.0)