"""
混沌边缘调节器

动态调整系统参数，使系统维持在混沌边缘——秩序与混沌的最佳平衡点。
调节对象包括：自由演化的扩散强度(alpha)、涨落强度(gamma)、顺应敏感度等。
"""

import numpy as np

class ChaosRegulator:
    """混沌边缘调节引擎"""
    
    def __init__(self, 
                 target_entropy_range=(0.3, 0.6),
                 target_sigma_range=(0.3, 0.5),
                 adjustment_rate=0.05):
        """
        参数:
            target_entropy_range: 目标信息熵范围（过低=僵化，过高=混乱）
            target_sigma_range: 目标平均离散度范围
            adjustment_rate: 参数调整速率
        """
        self.target_entropy_range = target_entropy_range
        self.target_sigma_range = target_sigma_range
        self.adjustment_rate = adjustment_rate
        
        # 当前调节参数
        self.alpha = 0.01   # 扩散强度
        self.gamma = 0.001  # 涨落强度
        self.beta = 0.005   # 自指强度
        
        # 历史
        self.adjustment_history = []
    
    def regulate(self, info_entropy, avg_sigma, trend):
        """
        根据当前状态调节参数
        
        参数:
            info_entropy: 当前信息熵
            avg_sigma: 当前平均离散度
            trend: 熵变化趋势
        
        返回:
            adjustments: 本次调整记录
        """
        adjustments = {}
        
        # 1. 根据信息熵调节
        if info_entropy < self.target_entropy_range[0]:
            # 熵过低：系统过于有序，需要增加涨落和扩散
            self.gamma *= (1 + self.adjustment_rate)
            self.alpha *= (1 + self.adjustment_rate * 0.5)
            adjustments["gamma"] = self.gamma
            adjustments["alpha"] = self.alpha
            adjustments["reason"] = "entropy_too_low"
        elif info_entropy > self.target_entropy_range[1]:
            # 熵过高：系统过于混沌，需要减少涨落，增强自指
            self.gamma *= (1 - self.adjustment_rate * 0.5)
            self.beta *= (1 + self.adjustment_rate * 0.3)
            adjustments["gamma"] = self.gamma
            adjustments["beta"] = self.beta
            adjustments["reason"] = "entropy_too_high"
        
        # 2. 根据离散度微调
        if avg_sigma < self.target_sigma_range[0]:
            # 离散度过低：过于确定，需要增加探索
            self.gamma *= (1 + self.adjustment_rate * 0.3)
            adjustments["gamma"] = self.gamma
            if "reason" not in adjustments:
                adjustments["reason"] = "sigma_too_low"
        elif avg_sigma > self.target_sigma_range[1]:
            # 离散度过高：过于不确定，需要增强秩序
            self.beta *= (1 + self.adjustment_rate * 0.2)
            self.alpha *= (1 - self.adjustment_rate * 0.1)
            adjustments["beta"] = self.beta
            adjustments["alpha"] = self.alpha
            if "reason" not in adjustments:
                adjustments["reason"] = "sigma_too_high"
        
        # 3. 趋势预判
        if trend == "increasing" and info_entropy > self.target_entropy_range[0] * 1.2:
            # 熵正在上升且已偏高，提前干预
            self.beta *= (1 + self.adjustment_rate * 0.2)
            adjustments["beta"] = self.beta
            adjustments["preemptive"] = True
        
        # 限制参数范围
        self.alpha = max(0.001, min(0.1, self.alpha))
        self.gamma = max(0.0001, min(0.01, self.gamma))
        self.beta = max(0.001, min(0.05, self.beta))
        
        if adjustments:
            self.adjustment_history.append({
                "info_entropy": info_entropy,
                "avg_sigma": avg_sigma,
                "adjustments": adjustments.copy()
            })
            if len(self.adjustment_history) > 50:
                self.adjustment_history = self.adjustment_history[-30:]
        
        return adjustments
    
    def get_parameters(self):
        """获取当前参数"""
        return {
            "alpha": self.alpha,
            "beta": self.beta,
            "gamma": self.gamma
        }
    
    def set_parameters(self, alpha=None, beta=None, gamma=None):
        """手动设置参数"""
        if alpha is not None:
            self.alpha = max(0.001, min(0.1, alpha))
        if beta is not None:
            self.beta = max(0.001, min(0.05, beta))
        if gamma is not None:
            self.gamma = max(0.0001, min(0.01, gamma))
    
    def is_in_chaos_edge(self, info_entropy, avg_sigma):
        """判断系统是否处于混沌边缘"""
        entropy_ok = self.target_entropy_range[0] <= info_entropy <= self.target_entropy_range[1]
        sigma_ok = self.target_sigma_range[0] <= avg_sigma <= self.target_sigma_range[1]
        return entropy_ok and sigma_ok
    
    def get_statistics(self):
        """获取统计信息"""
        return {
            "current_parameters": self.get_parameters(),
            "adjustment_count": len(self.adjustment_history),
            "target_entropy_range": self.target_entropy_range,
            "target_sigma_range": self.target_sigma_range
        }