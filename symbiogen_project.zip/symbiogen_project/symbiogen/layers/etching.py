from symbiogen.layers.base import Layer
from symbiogen.primitives.etch import etch
from collections import deque

class EtchingLayer(Layer):
    """刻蚀层：接收环境输入，施加 J⊗J 刻蚀应力"""
    
    def __init__(self, field, config=None):
        if config is None: config = {}
        super().__init__(field, config)
        self.input_queue = deque(maxlen=config.get("queue_size", 100))
        self.top_k = config.get("top_k", 5)
        self.strength = config.get("strength", 1.0)
    
    def enqueue(self, input_vector):
        """将输入向量加入队列"""
        self.input_queue.append(input_vector)
    
    def run(self, **kwargs):
        """处理队列中的所有输入"""
        processed = 0
        while self.input_queue:
            input_vector = self.input_queue.popleft()
            etch(self.field, input_vector, strength=self.strength, top_k=self.top_k)
            processed += 1
        return processed