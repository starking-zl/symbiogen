import numpy as np
import hashlib

class TextEncoder:
    """轻量级文本编码器：将文本转换为固定维度的信息向量"""
    
    def __init__(self, dimension=256):
        self.dimension = dimension
        self.vocab = {}
        self.next_id = 0
    
    def _tokenize(self, text):
        """简单的中文分词（按字符）"""
        return list(text)
    
    def _hash_to_vector(self, token):
        """将词元哈希映射到向量空间"""
        if token not in self.vocab:
            self.vocab[token] = self.next_id
            self.next_id += 1
        
        # 使用词元ID作为随机种子，生成稳定的随机向量
        seed = self.vocab[token]
        np.random.seed(seed)
        return np.random.randn(self.dimension) * 0.1
    
    def encode(self, text):
        """将文本编码为信息向量 J"""
        if not text:
            return np.zeros(self.dimension, dtype=np.float32)
        
        tokens = self._tokenize(text)
        if not tokens:
            return np.zeros(self.dimension, dtype=np.float32)
        
        # 所有词元向量的平均
        vectors = [self._hash_to_vector(t) for t in tokens]
        result = np.mean(vectors, axis=0)
        
        # 归一化
        norm = np.linalg.norm(result)
        if norm > 0:
            result = result / norm
        
        return result.astype(np.float32)