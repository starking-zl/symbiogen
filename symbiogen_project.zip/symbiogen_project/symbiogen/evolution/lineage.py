import json
from datetime import datetime


class LineageTracker:
    """谱系追踪器：记录进化树和世代统计"""

    def __init__(self):
        self.individuals = {}
        self.generations = []
        self.start_time = datetime.now().isoformat()

    def add_individual(self, colony, parent_id=None):
        """记录一个新个体"""
        self.individuals[colony.colony_id] = {
            "id": colony.colony_id,
            "parent_id": parent_id or colony.parent_id,
            "generation": colony.generation,
            "birth_time": colony.birth_time,
            "fitness": colony.fitness_score,
            "particle_count": colony.field.get_field_summary()["particle_count"]
        }

    def record_generation_best(self, gen, colony_id, fitness):
        """记录一代中的最优个体"""
        self.generations.append({
            "generation": gen,
            "best_id": colony_id,
            "best_fitness": fitness,
            "timestamp": datetime.now().isoformat()
        })

    def get_lineage_tree(self, root_id):
        """获取指定个体的谱系树（递归结构）"""
        tree = {"id": root_id, "children": []}
        for cid, info in self.individuals.items():
            if info.get("parent_id") == root_id:
                tree["children"].append(self.get_lineage_tree(cid))
        return tree

    def get_statistics(self):
        """获取进化统计信息"""
        if not self.generations:
            return {"generations": 0, "max_fitness": 0.0, "avg_fitness": 0.0}
        fitnesses = [g["best_fitness"] for g in self.generations]
        return {
            "generations": len(self.generations),
            "max_fitness": max(fitnesses),
            "avg_fitness": sum(fitnesses) / len(fitnesses),
            "total_individuals": len(self.individuals)
        }

    def save(self, filepath):
        """保存谱系记录"""
        data = {
            "individuals": self.individuals,
            "generations": self.generations,
            "start_time": self.start_time
        }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def load(self, filepath):
        """加载谱系记录"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.individuals = data["individuals"]
        self.generations = data["generations"]
        self.start_time = data["start_time"]