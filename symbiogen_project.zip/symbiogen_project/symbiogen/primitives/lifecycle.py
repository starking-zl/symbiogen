import numpy as np

def apply_resource_decay(field, epsilon=0.001):
    """全局资源衰减"""
    for p in field.particles.values():
        p.resource *= (1.0 - epsilon)
    
    for s in field.synapses:
        s.resource *= (1.0 - epsilon)

def prune_low_resource_particles(field, threshold=0.1):
    """修剪资源过低的粒子"""
    to_remove = [pid for pid, p in field.particles.items() if p.resource < threshold]
    for pid in to_remove:
        field.remove_particle(pid)
    return len(to_remove)

def grow_new_particles(field, threshold=2.0, max_new=5):
    """在资源富集的区域生长新粒子"""
    rich_particles = [(pid, p) for pid, p in field.particles.items() if p.resource > threshold]
    rich_particles.sort(key=lambda x: x[1].resource, reverse=True)
    
    new_count = 0
    for pid, p in rich_particles[:max_new]:
        if p.resource > threshold:
            # 在父粒子附近生成新粒子
            new_coord = p.coordinate + np.random.randn(field.dimension) * 0.1
            new_id = field.add_particle(new_coord)
            
            # 继承部分资源
            field.particles[new_id].resource = p.resource * 0.3
            p.resource *= 0.7
            
            # 建立连接
            field.add_synapse(pid, new_id, weight=np.random.randn() * 0.1)
            
            new_count += 1
    
    return new_count

def age_particles(field):
    """增加所有粒子的年龄"""
    for p in field.particles.values():
        p.age += 1