class PhaseClock:
    """相位时钟：0.0 到 1.0 循环"""
    
    def __init__(self, phase=0.0):
        self.phase = phase
    
    def tick(self, delta=0.05):
        """推进相位"""
        self.phase = (self.phase + delta) % 1.0
        return self.phase
    
    def is_in_range(self, start, end):
        """判断当前相位是否在指定区间"""
        if start <= end:
            return start <= self.phase < end
        else:
            return self.phase >= start or self.phase < end
    
    def get_current_phase_name(self):
        """获取当前相位名称"""
        if self.is_in_range(0.0, 0.2):
            return "etching"
        elif self.is_in_range(0.2, 0.5):
            return "diffusion_1"
        elif self.is_in_range(0.5, 0.6):
            return "fluctuation"
        elif self.is_in_range(0.6, 0.8):
            return "diffusion_2"
        elif self.is_in_range(0.8, 0.9):
            return "regression"
        else:
            return "time_layer"