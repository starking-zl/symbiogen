"""
动态阈值管理器

阈值 θ 不是固定的，而是根据系统的全局离散度动态调整。
- 当系统整体离散度高 (混沌强) 时，阈值应较高，避免过度敏感
- 当系统整体离散度低 (秩序强) 时，阈值应较低，更容易触发顺应
"""

import numpy as np

class ThresholdManager:
    """动态阈值管理引擎"""
    
    def __init__(self, 
                 base_threshold=0.3,
                 min_threshold=0.1,
                 max_threshold=0.8,
                 smoothing_factor=0.1):
        """
        参数:
            base_threshold: 基础阈值
            min_threshold: 最小阈值
            max_threshold: 最大阈值
            smoothing_factor: 平滑因子 (用于更新)
        """
        self.base_threshold = base_threshold
        self.min_threshold = min_threshold
        self.max_threshold = max_threshold
        self.smoothing_factor = smoothing_factor
        
        # 当前有效阈值
        self.current_threshold = base_threshold
        
        # 历史阈值记录
        self.threshold_history = []
    
    def compute_global_sigma(self, lexicon):
        """
        计算词元集合的全局平均离散度
        
        参数:
            lexicon: 词元词典
        
        返回:
            avg_sigma: 平均离散度
        """
        if not lexicon:
            return 0.5
        
        sigmas = [lex.sigma for lex in lexicon.values()]
        return np.mean(sigmas)
    
    def update_threshold(self, lexicon):
        """
        根据当前词元集合的全局离散度更新阈值
        
        规则：
        - 全局离散度越高，阈值越高 (系统混沌，需更强信号才触发顺应)
        - 全局离散度越低，阈值越低 (系统有序，对小失谐更敏感)
        
        参数:
            lexicon: 词元词典
        
        返回:
            new_threshold: 更新后的阈值
        """
        avg_sigma = self.compute_global_sigma(lexicon)
        
        # 将平均离散度映射到阈值区间
        # avg_sigma ∈ [0, 1] → target_threshold ∈ [min_threshold, max_threshold]
        target_threshold = self.min_threshold + avg_sigma * (self.max_threshold - self.min_threshold)
        
        # 指数平滑更新
        self.current_threshold = (self.smoothing_factor * target_threshold + 
                                  (1 - self.smoothing_factor) * self.current_threshold)
        
        # 记录历史
        self.threshold_history.append(self.current_threshold)
        if len(self.threshold_history) > 100:
            self.threshold_history = self.threshold_history[-50:]
        
        return self.current_threshold
    
    def get_threshold(self):
        """获取当前阈值"""
        return self.current_threshold
    
    def set_threshold_manual(self, value):
        """手动设置阈值 (用于调试或外部干预)"""
        self.current_threshold = max(self.min_threshold, min(self.max_threshold, value))
    
    def get_threshold_statistics(self):
        """获取阈值统计信息"""
        if not self.threshold_history:
            return {"mean": self.current_threshold, "std": 0.0}
        return {
            "mean": np.mean(self.threshold_history),
            "std": np.std(self.threshold_history),
            "min": np.min(self.threshold_history),
            "max": np.max(self.threshold_history),
            "current": self.current_threshold
        }
    
    def is_above_threshold(self, dissonance):
        """判断失谐度是否超过当前阈值"""
        return dissonance > self.current_threshold
    
    def to_dict(self):
        """序列化"""
        return {
            "base_threshold": self.base_threshold,
            "min_threshold": self.min_threshold,
            "max_threshold": self.max_threshold,
            "smoothing_factor": self.smoothing_factor,
            "current_threshold": self.current_threshold,
            "threshold_history": self.threshold_history
        }
    
    @classmethod
    def from_dict(cls, data):
        """反序列化"""
        tm = cls(
            base_threshold=data["base_threshold"],
            min_threshold=data["min_threshold"],
            max_threshold=data["max_threshold"],
            smoothing_factor=data["smoothing_factor"]
        )
        tm.current_threshold = data["current_threshold"]
        tm.threshold_history = data["threshold_history"]
        return tm