import numpy as np

class Blueprint:
    """蓝图场 R₀ —— 共生基因群的遗传物质"""
    
    def __init__(self, dimension=256):
        self.dimension = dimension
        self.anchors = []  # 每个锚点: {"coordinate": array, "target_curvature": float, "strength": float}
        
    def add_anchor(self, coordinate, target_curvature, strength=1.0):
        """添加或强化一个蓝图锚点"""
        # 检查是否已存在相近锚点
        for anchor in self.anchors:
            dist = np.linalg.norm(coordinate - anchor["coordinate"])
            if dist < 0.5:
                # 更新已有锚点
                anchor["target_curvature"] = (anchor["target_curvature"] * anchor["strength"] + 
                                              target_curvature * strength) / (anchor["strength"] + strength)
                anchor["strength"] += strength
                return
        
        # 新增锚点
        self.anchors.append({
            "coordinate": coordinate.copy(),
            "target_curvature": target_curvature,
            "strength": strength
        })
    
    def query(self, coordinate):
        """查询指定位置的目标曲率（距离加权平均）"""
        if not self.anchors:
            return 0.0
        
        total_weight = 0.0
        weighted_curvature = 0.0
        
        for anchor in self.anchors:
            dist = np.linalg.norm(coordinate - anchor["coordinate"])
            weight = anchor["strength"] * np.exp(-dist)
            total_weight += weight
            weighted_curvature += weight * anchor["target_curvature"]
        
        if total_weight == 0:
            return 0.0
        
        return weighted_curvature / total_weight
    
    def to_dict(self):
        return {
            "dimension": self.dimension,
            "anchors": [
                {
                    "coordinate": a["coordinate"].tolist(),
                    "target_curvature": a["target_curvature"],
                    "strength": a["strength"]
                }
                for a in self.anchors
            ]
        }
    
    @classmethod
    def from_dict(cls, data):
        bp = cls(dimension=data["dimension"])
        for a in data["anchors"]:
            bp.anchors.append({
                "coordinate": np.array(a["coordinate"], dtype=np.float32),
                "target_curvature": a["target_curvature"],
                "strength": a["strength"]
            })
        return bp