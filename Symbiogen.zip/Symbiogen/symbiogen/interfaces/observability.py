"""可观测性接口"""
def export_vital_signs(colony):
    return colony.export_vital_signs()