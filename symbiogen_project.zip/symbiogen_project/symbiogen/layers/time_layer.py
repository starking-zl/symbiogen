from symbiogen.layers.base import Layer
from symbiogen.primitives.lifecycle import (
    apply_resource_decay, prune_low_resource_particles,
    grow_new_particles, age_particles
)

class TimeLayer(Layer):
    """时间层：管理生命周期、出芽检测、蓝图沉淀"""
    
    def __init__(self, field, config=None):
        if config is None: config = {}
        super().__init__(field, config)
        self.epsilon = config.get("epsilon", 0.001)
        self.prune_threshold = config.get("prune_threshold", 0.1)
        self.grow_threshold = config.get("grow_threshold", 2.0)
        self.max_new = config.get("max_new", 5)
    
    def run(self, **kwargs):
        age_particles(self.field)
        apply_resource_decay(self.field, epsilon=self.epsilon)
        pruned = prune_low_resource_particles(self.field, threshold=self.prune_threshold)
        grown = grow_new_particles(self.field, threshold=self.grow_threshold, max_new=self.max_new)
        return {"pruned": pruned, "grown": grown}