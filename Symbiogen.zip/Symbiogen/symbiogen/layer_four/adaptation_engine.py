"""
顺应引擎

整合变异生成、评估和固化流程，作为第四层的统一入口。
"""

import numpy as np

class AdaptationEngine:
    """顺应执行总引擎"""
    
    def __init__(self, variation_rate=0.1, max_variations=5, success_threshold=0.3):
        """
        参数:
            variation_rate: 变异率
            max_variations: 每次最多生成的变异数
            success_threshold: 成功判定阈值
        """
        self.generator = VariationGenerator(
            variation_rate=variation_rate,
            max_variations_per_trigger=max_variations
        )
        self.evaluator = VariationEvaluator(success_threshold=success_threshold)
        self.solidifier = VariationSolidifier()
        
        # 统计
        self.total_adaptations = 0
        self.successful_adaptations = 0
    
    def adapt(self, trigger_info, lexicon, groupoid, lexicon_initializer,
              dissonance_calculator, evidence_vector=None, original_dissonance=None):
        """
        执行一次完整的顺应过程
        
        参数:
            trigger_info: 来自第三层的触发信息
            lexicon: 词元词典
            groupoid: 群胚管理器
            lexicon_initializer: 词元初始化器
            dissonance_calculator: 失谐度计算器
            evidence_vector: 环境证据向量
            original_dissonance: 变异前的失谐度
        
        返回:
            adaptation_result: 顺应结果摘要
        """
        self.total_adaptations += 1
        
        # 1. 生成试探性变异
        variations = self.generator.generate_variations(
            trigger_info, lexicon, groupoid, dissonance_calculator,
            evidence_vector=evidence_vector
        )
        
        if not variations:
            return {
                "success": False,
                "reason": "no_variations_generated",
                "variations_tried": 0,
                "variations_kept": 0
            }
        
        # 2. 评估变异
        evaluated = self.evaluator.evaluate_batch(
            variations, lexicon, groupoid, dissonance_calculator,
            evidence_vector, original_dissonance
        )
        
        # 3. 固化成功的变异
        solidified_results = self.solidifier.solidify_batch(
            evaluated, lexicon, groupoid, lexicon_initializer, max_to_solidify=3
        )
        
        # 统计成功数
        success_count = sum(1 for r in solidified_results if r.get("success", False))
        if success_count > 0:
            self.successful_adaptations += 1
        
        return {
            "success": success_count > 0,
            "trigger_severity": trigger_info.get("severity", 0.0),
            "variations_generated": len(variations),
            "variations_evaluated": len(evaluated),
            "variations_solidified": success_count,
            "solidified_details": solidified_results,
            "adaptation_id": self.total_adaptations
        }
    
    def get_statistics(self):
        """获取顺应统计"""
        return {
            "total_adaptations": self.total_adaptations,
            "successful_adaptations": self.successful_adaptations,
            "success_rate": self.successful_adaptations / max(1, self.total_adaptations),
            "generator_stats": {
                "variation_rate": self.generator.variation_rate
            },
            "evaluator_stats": {
                "success_threshold": self.evaluator.success_threshold
            },
            "solidifier_stats": self.solidifier.get_statistics()
        }