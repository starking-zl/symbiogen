"""
组合执行器

执行实际的语义组合运算：
- 函项应用 (Function Application)
- 谓词修饰 (Predicate Modification)
- 关联组合 (Association)
"""

import numpy as np

class CompositionEngine:
    """组合执行引擎"""
    
    def __init__(self, type_system=None, validator=None):
        """
        参数:
            type_system: 第零层的类型系统
            validator: 第零层的验证器
        """
        self.ts = type_system
        self.validator = validator
    
    def compose(self, source_lexion, target_lexion, connection, composition_type=None):
        """
        执行两个词元的组合
        
        参数:
            source_lexion: 源词元 (函数/谓词)
            target_lexion: 目标词元 (参数/被修饰词)
            connection: 连接对象
            composition_type: 组合类型，若为None则从connection推断
        
        返回:
            result_vector: 组合结果的概率向量
            confidence: 组合置信度
            success: 是否成功
        """
        comp_type = composition_type or connection.conn_type
        
        if comp_type == Connection.TYPE_APPLICATION:
            return self._function_application(source_lexion, target_lexion, connection)
        elif comp_type == Connection.TYPE_MODIFICATION:
            return self._predicate_modification(source_lexion, target_lexion, connection)
        else:
            return self._associative_compose(source_lexion, target_lexion, connection)
    
    def _function_application(self, fun_lex, arg_lex, connection):
        """
        函项应用: fun(arg) -> result
        
        将函数词元的概率云视为一个线性变换，作用于参数词元的概率云。
        采用简化模型：函数词元的概率云经过SVD分解后，取主成分作为变换矩阵。
        """
        # 获取采样权重
        weight = connection.mu
        
        # 由于概率云是高维向量，我们采用如下简化：
        # 将函数词元的概率云视为一个对角矩阵，其对角线元素即为概率值。
        # 然后与参数词元的概率云相乘，得到新的向量。
        # 这种简化保留了“函数作用于参数”的直觉，同时计算高效。
        diag_matrix = np.diag(fun_lex.p)
        result = np.dot(diag_matrix, arg_lex.p)
        
        # 归一化
        result_sum = np.sum(result)
        if result_sum > 1e-12:
            result = result / result_sum
        else:
            result = np.ones_like(result) / len(result)
        
        # 置信度：正比于函数和参数的确定性
        confidence = (1.0 - fun_lex.sigma) * (1.0 - arg_lex.sigma) * abs(weight)
        confidence = min(1.0, max(0.0, confidence))
        
        success = confidence > 0.3
        
        return result, confidence, success
    
    def _predicate_modification(self, pred1_lex, pred2_lex, connection):
        """
        谓词修饰: 两个谓词的交集
        
        两个谓词的概率云进行逐元素乘，表示同时满足两个谓词。
        """
        # 逐元素乘
        result = pred1_lex.p * pred2_lex.p
        
        # 归一化
        result_sum = np.sum(result)
        if result_sum > 1e-12:
            result = result / result_sum
        else:
            result = np.ones_like(result) / len(result)
        
        # 置信度
        weight = connection.mu
        confidence = (1.0 - pred1_lex.sigma) * (1.0 - pred2_lex.sigma) * abs(weight)
        confidence = min(1.0, max(0.0, confidence))
        
        success = confidence > 0.3
        
        return result, confidence, success
    
    def _associative_compose(self, lex1, lex2, connection):
        """
        一般关联组合
        
        将两个词元的概率云按权重加权平均。
        """
        weight = connection.mu
        # 将权重映射到 [0,1] 区间
        alpha = 1.0 / (1.0 + np.exp(-weight))  # sigmoid
        
        result = alpha * lex1.p + (1.0 - alpha) * lex2.p
        result = result / np.sum(result)
        
        confidence = (1.0 - lex1.sigma) * (1.0 - lex2.sigma) * abs(weight)
        confidence = min(1.0, max(0.0, confidence))
        
        success = confidence > 0.2
        
        return result, confidence, success
    
    def compose_path(self, path, lexicon, groupoid):
        """
        沿路径组合多个词元
        
        参数:
            path: 词元ID列表
            lexicon: 词元词典
            groupoid: 群胚管理器
        
        返回:
            final_vector: 最终组合结果
            total_confidence: 总置信度
            success: 是否完全成功
        """
        if len(path) < 2:
            if len(path) == 1 and path[0] in lexicon:
                return lexicon[path[0]].p, 1.0, True
            return None, 0.0, False
        
        # 逐步组合
        current_vector = lexicon[path[0]].p
        total_confidence = 1.0
        
        for i in range(len(path) - 1):
            src = path[i]
            tgt = path[i + 1]
            
            conn = groupoid.get_connection(src, tgt)
            if conn is None:
                return current_vector, total_confidence, False
            
            src_lex = lexicon[src]
            tgt_lex = lexicon[tgt]
            
            # 创建临时源词元用于组合，其概率云为当前累积向量
            # 使用第一层的Lexion类
            from symbiogen.layer_one.lexion import Lexion
            temp_src = Lexion(name="__temp__", dimension=src_lex.dimension)
            temp_src.p = current_vector
            temp_src.sigma = src_lex.sigma
            
            result, conf, success = self.compose(temp_src, tgt_lex, conn)
            
            if not success:
                return current_vector, total_confidence, False
            
            current_vector = result
            total_confidence *= conf
        
        return current_vector, total_confidence, True
    
    def create_result_lexion(self, result_vector, source_lex, target_lex, lexicon_initializer):
        """
        将组合结果固化为新词元
        
        当组合结果足够新颖且置信度高时，创建新词元。
        """
        # 检查是否与现有词元高度重叠
        for name, lex in lexicon_initializer.get_all_lexions().items():
            similarity = np.dot(result_vector, lex.p)
            if similarity > 0.9:
                # 已存在高度相似的词元，不创建新的
                return lex
        
        # 生成新名称
        new_name = f"{source_lex.name}+{target_lex.name}"
        if len(new_name) > 50:
            new_name = new_name[:50]
        
        # 创建新词元
        new_lex = lexicon_initializer.create_new_lexion(new_name)
        new_lex.p = result_vector
        new_lex.sigma = (source_lex.sigma + target_lex.sigma) / 2.0  # 初始中等离散度
        
        return new_lex