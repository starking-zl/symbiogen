"""
自由演化

在没有环境输入时，词元概率云进行自主演化：
- 扩散项 (∇²p)：趋向最大熵，使概率分布扁平化
- 自指势能项 (V_self)：受其他词元纠缠影响，趋向秩序
- 退相干项：离散度自然回归

演化方程 (离散形式)：
p(t+1) = p(t) + α * L(p) + β * V(p) + γ * ξ
其中 L 是离散拉普拉斯算子，V 是自指势能梯度，ξ 是噪声
"""

import numpy as np

class FreeEvolution:
    """自由演化引擎"""
    
    def __init__(self, alpha=0.01, beta=0.005, gamma=0.001):
        """
        参数:
            alpha: 扩散强度 (无为项)
            beta: 自指强度 (无不为项)
            gamma: 涨落强度 (可能性项)
        """
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
    
    def diffusion_step(self, lexion):
        """
        扩散项：离散拉普拉斯算子
        
        将概率质量向邻近维度扩散，趋向均匀分布。
        使用环形边界条件 (语义空间的周期性)。
        """
        p = lexion.p
        n = len(p)
        laplacian = np.zeros(n)
        
        # 一维环形拉普拉斯: L(p)[i] = p[i-1] + p[i+1] - 2*p[i]
        for i in range(n):
            left = p[(i - 1) % n]
            right = p[(i + 1) % n]
            laplacian[i] = left + right - 2 * p[i]
        
        return laplacian
    
    def self_potential_gradient(self, lexion, connections):
        """
        自指势能项：来自与其他词元的纠缠
        
        势能 V(p) 正比于与关联词元的相位中心的距离。
        梯度指向关联词元相位中心的加权平均方向。
        
        参数:
            lexion: 当前词元
            connections: 该词元的所有出向连接，每条连接包含 target_lexion 和 weight
        """
        if not connections:
            return np.zeros(lexion.dimension)
        
        # 加权平均目标方向
        weighted_target = np.zeros(lexion.dimension)
        total_weight = 0
        
        for conn in connections:
            target = conn.target_lexion
            weight = conn.weight
            weighted_target += weight * target.mu
            total_weight += abs(weight)
        
        if total_weight == 0:
            return np.zeros(lexion.dimension)
        
        weighted_target /= total_weight
        
        # 梯度指向目标方向，大小正比于当前概率分布与目标方向的差异
        current_proj = np.dot(lexion.p, weighted_target)
        gradient = (1 - current_proj) * (weighted_target - lexion.p)
        
        return gradient
    
    def evolve(self, lexion, connections=None, apply_noise=True):
        """
        执行一步自由演化
        
        参数:
            lexion: 要演化的词元
            connections: 该词元的出向连接列表 (用于自指势能)
            apply_noise: 是否施加涨落噪声
        
        返回:
            演化后的概率向量 (原地修改)
        """
        # 扩散项
        diffusion = self.alpha * self.diffusion_step(lexion)
        
        # 自指势能项
        if connections:
            potential = self.beta * self.self_potential_gradient(lexion, connections)
        else:
            potential = np.zeros(lexion.dimension)
        
        # 涨落项
        if apply_noise:
            noise = self.gamma * np.random.randn(lexion.dimension)
            # 确保噪声不破坏概率和为1的约束 (后续会归一化)
        else:
            noise = np.zeros(lexion.dimension)
        
        # 更新概率
        lexion.p = lexion.p + diffusion + potential + noise
        
        # 确保非负
        lexion.p = np.maximum(lexion.p, 1e-12)
        
        # 归一化
        lexion.p = lexion.p / np.sum(lexion.p)
        
        # 更新相位中心 (概率云的重心)
        lexion.mu = self._compute_phase_center(lexion.p)
        
        # 离散度自然回归 (向0.5回归，代表中等不确定)
        lexion.sigma = 0.99 * lexion.sigma + 0.01 * 0.5
        
        # 相干性自然衰减
        lexion.phi = 0.98 * lexion.phi
        
        return lexion.p
    
    def _compute_phase_center(self, p):
        """计算概率云的相位中心 (加权平均方向)"""
        n = len(p)
        # 将概率向量视为环形上的分布，计算其“重心”方向
        angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
        x = np.sum(p * np.cos(angles))
        y = np.sum(p * np.sin(angles))
        
        # 返回单位向量方向
        vec = np.zeros(n)
        if x != 0 or y != 0:
            # 找到最接近该角度的维度
            target_angle = np.arctan2(y, x)
            if target_angle < 0:
                target_angle += 2 * np.pi
            idx = int(target_angle / (2 * np.pi) * n) % n
            vec[idx] = 1.0
        else:
            vec[0] = 1.0
        
        return vec
    
    def update_parameters(self, alpha=None, beta=None, gamma=None):
        """动态调整演化参数"""
        if alpha is not None:
            self.alpha = alpha
        if beta is not None:
            self.beta = beta
        if gamma is not None:
            self.gamma = gamma