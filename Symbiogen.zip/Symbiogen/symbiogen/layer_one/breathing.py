"""
离散度呼吸

离散度 σ 决定了词元输出的随机性：
- σ 小：概率云尖锐，输出确定性高 (秩序强)
- σ 大：概率云扁平，输出随机性高 (混沌强)

呼吸规则：
- 确认信号 (confidence > threshold)：σ 收缩 (趋向秩序)
- 否定信号 (失谐或低置信)：σ 扩张 (趋向混沌)
- 沉默 (长期未激活)：σ 缓慢扩张
"""

import numpy as np

class DiscreteBreathing:
    """离散度呼吸引擎"""
    
    def __init__(self, 
                 contract_rate=0.05,      # 收缩速率
                 expand_rate=0.03,        # 扩张速率
                 silent_expand_rate=0.001,# 沉默扩张速率
                 min_sigma=0.01,          # 最小离散度 (永不归零)
                 max_sigma=0.99):         # 最大离散度
        self.contract_rate = contract_rate
        self.expand_rate = expand_rate
        self.silent_expand_rate = silent_expand_rate
        self.min_sigma = min_sigma
        self.max_sigma = max_sigma
    
    def on_confirmation(self, lexion, confidence):
        """
        确认信号：收缩离散度
        
        置信度越高，收缩越快。
        """
        # 收缩量正比于置信度和当前离散度
        delta = self.contract_rate * confidence * lexion.sigma
        lexion.sigma = max(self.min_sigma, lexion.sigma - delta)
        
        # 确认也增加相干性
        lexion.phi = min(1.0, lexion.phi + 0.05 * confidence)
        
        return lexion.sigma
    
    def on_negation(self, lexion, dissonance):
        """
        否定信号：扩张离散度
        
        失谐度越高，扩张越快。
        """
        # 扩张量正比于失谐度
        delta = self.expand_rate * dissonance * (1 - lexion.sigma)
        lexion.sigma = min(self.max_sigma, lexion.sigma + delta)
        
        # 否定降低相干性
        lexion.phi = max(0.0, lexion.phi - 0.03 * dissonance)
        
        return lexion.sigma
    
    def on_silence(self, lexion, silent_steps):
        """
        沉默：缓慢扩张离散度
        
        长期未被激活的词元，其离散度逐渐扩大，
        进入“休眠”状态，但仍保留可能性。
        """
        # 扩张量与沉默时长成正比 (有上限)
        effective_steps = min(silent_steps, 100)
        delta = self.silent_expand_rate * effective_steps * (1 - lexion.sigma)
        lexion.sigma = min(self.max_sigma, lexion.sigma + delta)
        
        # 长期沉默降低相干性
        lexion.phi = max(0.0, lexion.phi - 0.001 * silent_steps)
        
        return lexion.sigma
    
    def update(self, lexion, signal_type, signal_value=0.5):
        """
        统一的呼吸更新接口
        
        参数:
            lexion: 要更新的词元
            signal_type: "confirmation", "negation", "silence"
            signal_value: 信号强度 (置信度、失谐度、或沉默步数)
        """
        if signal_type == "confirmation":
            return self.on_confirmation(lexion, signal_value)
        elif signal_type == "negation":
            return self.on_negation(lexion, signal_value)
        elif signal_type == "silence":
            return self.on_silence(lexion, signal_value)
        else:
            raise ValueError(f"Unknown signal_type: {signal_type}")
    
    def is_dormant(self, lexion, dormancy_threshold=0.8):
        """判断词元是否进入休眠态"""
        return lexion.sigma >= dormancy_threshold
    
    def is_active(self, lexion, activity_threshold=0.3):
        """判断词元是否处于活跃态"""
        return lexion.sigma <= activity_threshold