"""
第三层：失谐感知层

本层负责：
- 计算当前词元状态与环境输入之间的失谐度 (KL散度)
- 管理动态阈值 θ，根据全局离散度自动调整
- 当失谐度连续多次超过阈值时，触发顺应请求

本层依赖第一层的词元概率云状态和坍缩结果。
"""

from .dissonance import DissonanceCalculator
from .threshold import ThresholdManager
from .trigger import AdaptationTrigger

__all__ = [
    "DissonanceCalculator",
    "ThresholdManager",
    "AdaptationTrigger"
]