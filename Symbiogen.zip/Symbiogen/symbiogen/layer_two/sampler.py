"""
倾向采样器

从连接的倾向区间 (mu, sigma) 中采样，生成瞬时的组合权重。
"""

import numpy as np

class TendencySampler:
    """倾向区间采样器"""
    
    def __init__(self, temperature=0.1):
        """
        参数:
            temperature: 采样温度，控制采样的随机性
                         温度越高，采样越分散 (更随机)
        """
        self.temperature = temperature
    
    def sample_weight(self, connection):
        """
        从连接的倾向区间采样一个瞬时权重
        
        使用截断正态分布，中心为 mu，标准差为 sigma * temperature。
        权重范围限制在 [-1, 1]。
        """
        if connection.dormant:
            return 0.0
        
        mu = connection.mu
        sigma = connection.sigma * self.temperature
        
        # 从正态分布采样
        weight = np.random.normal(mu, sigma)
        
        # 截断到 [-1, 1]
        weight = max(-1.0, min(1.0, weight))
        
        return weight
    
    def sample_top_k(self, connections, k=3):
        """
        从多个连接中采样并选出权重最高的 k 个
        
        参数:
            connections: 连接列表
            k: 返回的连接数
        
        返回:
            [(connection, weight), ...] 按权重降序排列
        """
        if not connections:
            return []
        
        sampled = []
        for conn in connections:
            w = self.sample_weight(conn)
            if abs(w) > 0.01:  # 过滤过弱的连接
                sampled.append((conn, w))
        
        # 按权重绝对值降序排序
        sampled.sort(key=lambda x: abs(x[1]), reverse=True)
        
        return sampled[:k]
    
    def sample_combination_path(self, start_id, groupoid, max_depth=5, beam_width=3):
        """
        采样一条组合路径 (用于生成输出)
        
        从起始词元开始，每一步根据连接权重采样下一个词元，
        直到达到最大深度或没有可用的连接。
        
        参数:
            start_id: 起始词元ID
            groupoid: 群胚管理器
            max_depth: 最大组合深度
            beam_width: 每步保留的候选连接数
        
        返回:
            [lexion_id1, lexion_id2, ...] 组合路径
        """
        path = [start_id]
        current = start_id
        
        for _ in range(max_depth):
            connections = groupoid.get_outgoing(current, include_dormant=False)
            if not connections:
                break
            
            # 采样并选出 top-k
            candidates = self.sample_top_k(connections, k=beam_width)
            if not candidates:
                break
            
            # 按权重概率选择下一步 (权重越高被选中概率越大)
            weights = [abs(w) for _, w in candidates]
            total = sum(weights)
            if total == 0:
                break
            
            probs = [w / total for w in weights]
            chosen_idx = np.random.choice(len(candidates), p=probs)
            chosen_conn, _ = candidates[chosen_idx]
            
            current = chosen_conn.target_id
            path.append(current)
        
        return path