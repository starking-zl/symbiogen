"""
组合合法性验证器

为上层提供快速的类型检查和组合路径验证。
"""

class Validator:
    """
    验证器
    
    封装类型系统、原子集和组合器，提供统一的验证接口。
    """
    
    def __init__(self, type_system, primitives, composer):
        self.ts = type_system
        self.primitives = primitives
        self.composer = composer
    
    def validate_type(self, t):
        """验证类型是否合法"""
        return self.ts.is_valid_type(t)
    
    def validate_primitive(self, name):
        """验证名称是否为语义原子"""
        return self.primitives.is_primitive(name)
    
    def validate_application(self, fun_type, arg_type):
        """验证函项应用是否合法"""
        if not isinstance(fun_type, PowerType):
            return False, "第一个表达式不是函数类型"
        if fun_type.domain != arg_type:
            return False, f"类型不匹配：函数期望 {fun_type.domain}，参数为 {arg_type}"
        return True, fun_type.codomain
    
    def validate_predicate_modification(self, pred1_type, pred2_type):
        """验证谓词修饰是否合法"""
        expected = self.ts.make_power(self.ts.TYPE_E, self.ts.TYPE_T)
        if pred1_type != expected:
            return False, f"第一个谓词类型应为 {expected}，实际为 {pred1_type}"
        if pred2_type != expected:
            return False, f"第二个谓词类型应为 {expected}，实际为 {pred2_type}"
        return True, expected
    
    def get_primitive_type(self, name):
        """获取语义原子的类型"""
        return self.primitives.get_primitive_type(name)
    
    def list_all_primitives(self):
        """列出所有语义原子"""
        return self.primitives.get_all_primitives()
    
    def list_primitives_by_category(self, category):
        """按范畴列出语义原子"""
        return self.primitives.get_primitives_by_category(category)