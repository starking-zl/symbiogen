"""
全局优化调度器

周期性触发第五层的各项优化任务：
- 连接修剪/唤醒
- 熵状态更新
- 混沌边缘参数调节

并将调节后的参数同步到第一层和第二层。
"""

import time
import numpy as np

class GlobalOptimizationScheduler:
    """全局优化调度引擎"""
    
    def __init__(self, 
                 pruning_interval=1000,
                 entropy_update_interval=500,
                 chaos_regulate_interval=2000,
                 temperature_base=0.05,
                 temperature_gamma_factor=50.0):
        """
        参数:
            pruning_interval: 连接修剪的间隔步数
            entropy_update_interval: 熵状态更新的间隔步数
            chaos_regulate_interval: 混沌边缘调节的间隔步数
            temperature_base: 采样温度的基础值
            temperature_gamma_factor: 采样温度与gamma的关联系数
        """
        self.pruning_interval = pruning_interval
        self.entropy_update_interval = entropy_update_interval
        self.chaos_regulate_interval = chaos_regulate_interval
        self.temperature_base = temperature_base
        self.temperature_gamma_factor = temperature_gamma_factor
        
        # 子引擎
        self.pruner = ConnectionPruner()
        self.entropy_monitor = EntropyMonitor()
        self.chaos_regulator = ChaosRegulator()
        
        # 状态
        self.step_counter = 0
        self.last_pruning_step = 0
        self.last_entropy_step = 0
        self.last_chaos_step = 0
        
        # 最近的失谐度缓存（由第三层提供）
        self.dissonance_buffer = []
        
        # 统计
        self.optimization_history = []
    
    def record_dissonance(self, dissonance):
        """记录每次交互的失谐度（由第三层调用）"""
        self.dissonance_buffer.append(dissonance)
        if len(self.dissonance_buffer) > 500:
            self.dissonance_buffer = self.dissonance_buffer[-200:]
    
    def step(self, lexicon, groupoid, force=False):
        """
        执行一步调度（由主循环每次交互后调用）
        
        参数:
            lexicon: 词元词典
            groupoid: 群胚管理器
            force: 是否强制执行所有任务（用于手动触发）
        
        返回:
            report: 本次执行的任务报告
        """
        self.step_counter += 1
        report = {"tasks": [], "step": self.step_counter}
        
        # 1. 连接修剪
        if force or (self.step_counter - self.last_pruning_step >= self.pruning_interval):
            pruned, details = self.pruner.prune(groupoid, lexicon)
            woken = self.pruner.wake(groupoid)
            report["tasks"].append({
                "type": "pruning",
                "pruned": pruned,
                "woken": woken
            })
            self.last_pruning_step = self.step_counter
        
        # 2. 熵状态更新
        if force or (self.step_counter - self.last_entropy_step >= self.entropy_update_interval):
            recent_dissonance = np.mean(self.dissonance_buffer) if self.dissonance_buffer else 0.0
            entropy_report = self.entropy_monitor.update(lexicon, groupoid, recent_dissonance)
            report["tasks"].append({
                "type": "entropy",
                "report": entropy_report
            })
            self.last_entropy_step = self.step_counter
        
        # 3. 混沌边缘调节
        if force or (self.step_counter - self.last_chaos_step >= self.chaos_regulate_interval):
            info_entropy = self.entropy_monitor.compute_lexicon_entropy(lexicon)
            avg_sigma = np.mean([lex.sigma for lex in lexicon.values()]) if lexicon else 0.5
            trend = self.entropy_monitor.get_trend()
            adjustments = self.chaos_regulator.regulate(info_entropy, avg_sigma, trend)
            report["tasks"].append({
                "type": "chaos_regulation",
                "adjustments": adjustments,
                "info_entropy": info_entropy,
                "avg_sigma": avg_sigma
            })
            self.last_chaos_step = self.step_counter
        
        if report["tasks"]:
            self.optimization_history.append(report)
            if len(self.optimization_history) > 50:
                self.optimization_history = self.optimization_history[-30:]
        
        return report
    
    def sync_parameters(self, evolution_engine, sampler=None):
        """
        将混沌边缘调节后的参数同步到第一层和第二层
        
        参数:
            evolution_engine: 第一层的 FreeEvolution 实例
            sampler: 第二层的 TendencySampler 实例（可选）
        """
        params = self.chaos_regulator.get_parameters()
        
        if evolution_engine is not None:
            evolution_engine.update_parameters(
                alpha=params["alpha"],
                beta=params["beta"],
                gamma=params["gamma"]
            )
        
        if sampler is not None:
            # 采样温度 = 基础值 + gamma * 关联系数
            sampler.temperature = self.temperature_base + params["gamma"] * self.temperature_gamma_factor
    
    def get_status(self):
        """获取调度器状态"""
        return {
            "step_counter": self.step_counter,
            "next_pruning": self.pruning_interval - (self.step_counter - self.last_pruning_step),
            "next_entropy": self.entropy_update_interval - (self.step_counter - self.last_entropy_step),
            "next_chaos": self.chaos_regulate_interval - (self.step_counter - self.last_chaos_step),
            "pruner_stats": self.pruner.get_statistics(),
            "entropy_stats": self.entropy_monitor.get_statistics(),
            "chaos_stats": self.chaos_regulator.get_statistics()
        }
    
    def force_optimize(self, lexicon, groupoid):
        """强制执行一次完整的优化（用于调试或手动干预）"""
        return self.step(lexicon, groupoid, force=True)